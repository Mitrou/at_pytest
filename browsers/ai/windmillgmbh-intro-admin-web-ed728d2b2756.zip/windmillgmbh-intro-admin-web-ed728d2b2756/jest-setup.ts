import 'jest-preset-angular';

global['CSS'] = null;

import './jest-global-mocks';
