import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './features/auth/services/auth-guard.service';
import { ForbiddenPageComponent } from './core/fallback-pages/forbidden-page.component';
import { NotFoundPageComponent } from './core/fallback-pages/not-found-page.component';

export const routes: Routes = [
  {path: '', redirectTo: '/dashboard', pathMatch: 'full'},
  {
    path: 'dashboard',
    loadChildren: './features/dashboard/dashboard.module#DashboardModule',
    canActivate: [AuthGuard],
  },
  {
    path: 'holidays',
    loadChildren: './features/holidays/holidays.module#HolidaysModule',
    canActivate: [AuthGuard],
  },
  {
    path: 'universities',
    loadChildren: './features/universities/universities.module#UniversitiesModule',
    canActivate: [AuthGuard],
  },
  {
    path: 'users',
    loadChildren: './features/users/users.module#UsersModule',
    canActivate: [AuthGuard],
  },
  {
    path: 'get-togethers',
    loadChildren: './features/get-together/get-together.module#GetTogethersModule',
    canActivate: [AuthGuard],
  },
  {
    path: 'meeting-spot',
    loadChildren: './features/meeting-spots/meeting-spots.module#MeetingSpotsModule',
    canActivate: [AuthGuard],
  },
  {path: '**', component: NotFoundPageComponent},
  {path: '404', component: NotFoundPageComponent},
  {path: 'forbidden', component: ForbiddenPageComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule],
})
export class AppRoutingModule {
}
