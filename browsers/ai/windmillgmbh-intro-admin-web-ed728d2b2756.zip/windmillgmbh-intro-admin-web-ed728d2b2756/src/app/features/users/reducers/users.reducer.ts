import { EntityState, createEntityAdapter } from '@ngrx/entity';

import { UserActionsUnion, UserActionTypes } from '../actions';

import { User } from '@shared/models/user';

export interface State extends EntityState<User> {
  error: string | null;
  pending: boolean;
  count: number;
  offset: number;
  limit: number;
}

export const userEntityAdapter = createEntityAdapter<User>({
  selectId: (user: User) => user.id,
  sortComparer: false,
});

export const initialState: State = userEntityAdapter.getInitialState({
  error: null,
  pending: false,
  count: 0,
  offset: 0,
  limit: 10
});

export function reducer(state = initialState, action: UserActionsUnion): State {
  switch (action.type) {
    case UserActionTypes.LoadUsers: {
      return {
        ...state,
        error: null,
        pending: true,
        offset: action.payload.pageInfo.offset,
        limit: action.payload.pageInfo.limit,
      };
    }

    case UserActionTypes.LoadUsersSuccess: {
      return userEntityAdapter.addAll(action.payload.data, {
        ...state,
        error: null,
        pending: false,
        count: action.payload.count
      });
    }

    case UserActionTypes.LoadUsersFailure: {
      return {
        ...state,
        error: action.payload,
        pending: false,
        count: 0,
        offset: 0,
      };
    }

    default: {
      return state;
    }
  }
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getCount = (state: State) => state.count;
export const getOffset = (state: State) => state.offset;
export const getLimit = (state: State) => state.limit;
