import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseService } from '@shared/services/base.service';

import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';
import { User } from '@shared/models/user';
import { Filters } from 'src/app/core/types/filters';


@Injectable({
  providedIn: 'root'
})
export class UserService extends BaseService {
  normalizeFilters(filters: Filters): Filters {
    if (!filters) {
      return null;
    }

    let status = filters.get('status');
    if (status) {
      status = status instanceof Array
      ? (status as Array<String>).map(value => value.toUpperCase())
      : (status as String).toUpperCase();

      filters.set('status', status);
    }

    return filters;
  }

  loadUsers({ pageInfo, sortInfo, filters }: LoadListPayload):
  Observable<LoadListSuccessPayload<User>> {
    return this.gridRequest<User>(`/api/user`,
      pageInfo.offset + 1, pageInfo.limit,
      sortInfo.prop, sortInfo.dir,
      this.normalizeFilters(filters)
    ).pipe(
      map(payload => {
        payload.data = payload.data.map(user => new User(user));
        return payload;
      })
    );
  }

  loadUser(id: string | number): Observable<User> {
    return this.http.get<User>('/api/user/' + String(id));
  }

}
