import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UsersPageComponent, UserDetailsPageComponent } from './containers';

import { OpenDrawerGuard } from '../../core/services/open-drawer-guard.service';
import { CloseDrawerGuard } from '../../core/services/close-drawer-guard.service';

import { UserDetailsGuard } from './services/user-details.guard';


export const routes: Routes = [
  {
    path: '',
    component: UsersPageComponent,
    children: [
      {
        path: ':userId/details',
        component: UserDetailsPageComponent,
        canActivate: [UserDetailsGuard, OpenDrawerGuard],
        canDeactivate: [CloseDrawerGuard],
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UsersRoutingModule {
}
