import { Component, OnInit } from '@angular/core';

import { Store, select } from '@ngrx/store';

import * as fromUsers from '../../reducers';

@Component({
  selector: 'wml-user-details-page',
  templateUrl: './user-details-page.component.html'
})
export class UserDetailsPageComponent implements OnInit {
  user$ = this.store.select(fromUsers.getSelectedUser);
  error$ = this.store.select(fromUsers.getUserDetailsError);
  pending$ = this.store.select(fromUsers.getUserDetailsPending);

  constructor(private store: Store<fromUsers.State>) {}

  ngOnInit() {}
}
