import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnChanges
} from '@angular/core';
import { ThemePalette } from '@angular/material';

import { Participation } from '@shared/models/user';

export interface ParticipationStyleObject {
  value: number;
  color: ThemePalette;
}

@Component({
  selector: 'wml-user-participation',
  templateUrl: './user-participation.component.html',
  styleUrls: ['./user-participation.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserParticipationComponent implements OnChanges {
  @Input() participation: Participation;

  styleObj: ParticipationStyleObject = {
    value: 0,
    color: 'warn'
  };

  ngOnChanges(): void {
    this.styleObj = this.determineBarStyle(this.participation);
  }

  determineBarStyle(participation: Participation): ParticipationStyleObject {
    switch (participation) {
      case Participation.HIGH:
        return {
          color: 'primary',
          value: 90
        };
      case Participation.FULL:
        return {
          color: 'primary',
          value: 100
        };
      case Participation.LOW:
        return {
          color: 'warn',
          value: 25
        };
      case Participation.MODERATE:
      case Participation.MEDIUM:
        return {
          color: 'accent',
          value: 60
        };
      default:
        return {
          color: 'warn',
          value: 0
        };
    }
  }
}
