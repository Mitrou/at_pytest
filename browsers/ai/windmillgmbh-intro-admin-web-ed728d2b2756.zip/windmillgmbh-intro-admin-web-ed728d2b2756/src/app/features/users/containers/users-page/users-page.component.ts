import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromUsers from '../../reducers';
import * as UsersActions from '../../actions/user.actions';
import * as fromRoot from '../../../../reducers';

import { LoadListPayload } from '@shared/models/list';
import { User } from '@shared/models/user';

@Component({
  selector: 'wml-users-page',
  templateUrl: './users-page.component.html'
})
export class UsersPageComponent implements OnInit {
  users$ = this.store.pipe(select(fromUsers.getAllUsers));
  pending$ = this.store.pipe(select(fromUsers.getUsersPending));
  count$ = this.store.pipe(select(fromUsers.getUsersCount));
  offset$ = this.store.pipe(select(fromUsers.getUsersOffset));
  limit$ = this.store.pipe(select(fromUsers.getUsersLimit));
  drawerOpened$ = this.store.pipe(select(fromRoot.getDrawerOpened));

  selectedUsers: User[];

  constructor(private store: Store<fromUsers.State>) {}

  ngOnInit() {
    this.store.dispatch(new UsersActions.LoadUsers());
  }

  onReloadGrid($event: LoadListPayload) {
    this.store.dispatch(new UsersActions.LoadUsers(new LoadListPayload($event)));
  }

  onSelectItem($event: User) {
    this.store.dispatch(new UsersActions.NavigateToDetailsPage($event.id));
  }

  onMultiSelectItem($event: User[]) {
    this.selectedUsers = $event;
  }
}
