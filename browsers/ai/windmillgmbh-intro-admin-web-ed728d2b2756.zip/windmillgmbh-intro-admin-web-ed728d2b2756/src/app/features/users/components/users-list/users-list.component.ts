import {
  Component,
  ChangeDetectionStrategy,
  Input,
  Output,
  EventEmitter
} from '@angular/core';

import { SelectionType } from '@swimlane/ngx-datatable';

import { LoadListPayload } from '@shared/models/list';
import { User } from '@shared/models/user';
import { Status } from '@shared/models/status';
import { toTitleCase } from '@shared/utils/title-case.helper';
import {
  ColumnFilterType,
  GridOptions,
  ColumnType
} from '@shared/components/grid/grid.configs';

@Component({
  selector: 'wml-users-list',
  templateUrl: './users-list.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UsersListComponent {
  @Input() users: User[] = [];
  @Input() pending: boolean;
  @Input() error: string | null;
  @Input() count: number;
  @Input() offset: number;
  @Input() limit: number;
  @Input() drawerOpened = false;

  @Output() reloadGrid = new EventEmitter<LoadListPayload>();
  @Output() selectItem = new EventEmitter<User>();
  @Output() multiSelectItem = new EventEmitter<User[]>();

  options: GridOptions = {
    actions: [],
    columns: [
      {
        columnType: ColumnType.Checkbox,
        checkboxable: true,
        headerCheckboxable: true,
        filterable: false,
        resizeable: false,
        width: 30,
        canAutoResize: false
      },
      {
        name: 'Name',
        prop: 'name',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        name: 'Status',
        prop: 'status',
        columnType: ColumnType.Status,
        filterable: true,
        filterType: ColumnFilterType.Select,
        filterData: Object.keys(Status).filter(key => isNaN(Number(key))).map(
          status => ({ title: toTitleCase(status) })
        ),
        width: 130,
        canAutoResize: false
      },
      {
        name: 'Participation',
        prop: 'participation',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text,
        canAutoResize: false
      },
      {
        name: 'Type',
        prop: 'type',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text,
        canAutoResize: false
      },
      {
        name: 'Location',
        prop: 'location',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        name: 'Email',
        prop: 'email',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text,
        hideOnDrawerOpened: true
      },
      {
        name: 'Interests',
        prop: 'interestsLength',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text,
        hideOnDrawerOpened: true,
        width: 70,
        canAutoResize: false
      },
      {
        name: 'Avg Rating',
        prop: 'avgReting',
        columnType: ColumnType.Rating,
        filterable: true,
        filterType: ColumnFilterType.Text,
        hideOnDrawerOpened: true
      },
      {
        name: 'Last Active',
        prop: 'lastActive',
        columnType: ColumnType.Date,
        dateFormat: 'dd MMM yyyy, HH:mm',
        filterable: true,
        filterType: ColumnFilterType.DatePicker,
        hideOnDrawerOpened: true
      }
    ],
    selectionType: SelectionType.checkbox
  };

  undefineSelected() {
    (this as any)._selected = null;
  }
}
