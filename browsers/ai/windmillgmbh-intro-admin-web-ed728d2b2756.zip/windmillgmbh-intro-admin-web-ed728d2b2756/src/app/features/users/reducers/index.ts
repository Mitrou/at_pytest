import {
  createSelector,
  createFeatureSelector,
  ActionReducerMap
} from '@ngrx/store';

import * as fromRoot from '../../../reducers';
import * as fromUsers from './users.reducer';
import * as fromUserDetails from './user-details.reducer';

export interface UsersState {
  users: fromUsers.State;
  userDetails: fromUserDetails.State;
}

export interface State extends fromRoot.State {
  users: UsersState;
}

export const reducers: ActionReducerMap<UsersState> = {
  users: fromUsers.reducer,
  userDetails: fromUserDetails.reducer
};

export const getUsersState = createFeatureSelector<
  State, UsersState
>('users');

export const getUsersEntitiesState = createSelector( // TODO: fix namings
  getUsersState,
  state => state.users
);

export const getUsersError = createSelector(
  getUsersEntitiesState,
  fromUsers.getError
);

export const getUsersPending = createSelector(
  getUsersEntitiesState,
  fromUsers.getPending
);

export const getUsersCount = createSelector(
  getUsersEntitiesState,
  fromUsers.getCount
);

export const getUsersOffset = createSelector(
  getUsersEntitiesState,
  fromUsers.getOffset
);

export const getUsersLimit = createSelector(
  getUsersEntitiesState,
  fromUsers.getLimit
);

export const {
  selectEntities: getUsersEntities,
  selectAll: getAllUsers,
} = fromUsers.userEntityAdapter.getSelectors(getUsersEntitiesState);


export const getUserDetailsState = createSelector(
  getUsersState,
  state => state.userDetails
);

export const getSelectedUser = createSelector(
  getUserDetailsState,
  fromUserDetails.getUser
);

export const getUserDetailsPending = createSelector(
  getUserDetailsState,
  fromUserDetails.getPending
);

export const getUserDetailsError = createSelector(
  getUserDetailsState,
  fromUserDetails.getError
);
