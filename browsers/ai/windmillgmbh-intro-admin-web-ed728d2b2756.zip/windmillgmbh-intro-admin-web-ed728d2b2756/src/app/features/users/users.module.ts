import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';

import { UsersRoutingModule } from './users-routing.module';

import { reducers } from './reducers';

import { UsersEffects } from './effects/users.effects';
import { UserService } from './services/user.service';
import { UserDetailsGuard } from './services/user-details.guard';

import { CoreModule } from '../../core/core.module';
import { SharedModule } from '@shared/shared.module';

import {
  UserDetailsComponent,
  UserParticipationComponent,
  UserSocialsComponent,
  UsersListComponent
} from './components';
import { UserDetailsPageComponent, UsersPageComponent } from './containers';

export const COMPONENTS = [
  UsersPageComponent,
  UsersListComponent,
  UserDetailsPageComponent,
  UserDetailsComponent,
  UserParticipationComponent,
  UserSocialsComponent
];

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    UsersRoutingModule,
    StoreModule.forFeature('users', reducers),
    EffectsModule.forFeature([UsersEffects]),
    CoreModule,
    SharedModule
  ],
  declarations: COMPONENTS,
  exports: COMPONENTS,
  providers: [UserService, UserDetailsGuard]
})
export class UsersModule {
}
