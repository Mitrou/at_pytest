import { Action } from '@ngrx/store';

import { User } from '@shared/models/user';
import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';

export enum UserActionTypes {
  LoadUsers = '[Users] Load Users',
  LoadUsersSuccess = '[Users] Load Users Success',
  LoadUsersFailure = '[Users] Load Users Failure',
  NavigateToDetailsPage = '[Users] Navigate to Details Page',
  LoadUser = '[Users] Load User',
  LoadUserSuccess = '[Users] Load User Success',
  LoadUserFailure = '[Users] Load User Failure',
  SelectUser = '[Users] Select User'
}

export class LoadUsers implements Action {
  readonly type = UserActionTypes.LoadUsers;

  constructor(public payload: LoadListPayload = new LoadListPayload()) {}
}

export class LoadUsersSuccess implements Action {
  readonly type = UserActionTypes.LoadUsersSuccess;

  constructor(public payload: LoadListSuccessPayload<User>) {}
}

export class LoadUsersFailure implements Action {
  readonly type = UserActionTypes.LoadUsersFailure;

  constructor(public payload: string) {}
}

export class LoadUser implements Action {
  readonly type = UserActionTypes.LoadUser;

  constructor(public payload: number) {}
}

export class LoadUserSuccess implements Action {
  readonly type = UserActionTypes.LoadUserSuccess;

  constructor(public payload: User) {}
}

export class SelectUser implements Action {
  readonly type = UserActionTypes.SelectUser;

  constructor(public payload: User) {}
}

export class LoadUserFailure implements Action {
  readonly type = UserActionTypes.LoadUserFailure;

  constructor(public payload: string) {}
}


export class NavigateToDetailsPage implements Action {
  readonly type = UserActionTypes.NavigateToDetailsPage;

  constructor(public payload: number) {}
}

export type UserActionsUnion =
  | LoadUsers
  | LoadUsersSuccess
  | LoadUsersFailure
  | NavigateToDetailsPage
  | LoadUser
  | LoadUserSuccess
  | LoadUserFailure
  | SelectUser;
