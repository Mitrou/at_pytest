import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { select, Store } from '@ngrx/store';

import { Observable, of } from 'rxjs';
import { map, switchMap, take, tap, withLatestFrom } from 'rxjs/operators';

import * as fromUsers from '../reducers';
import { SelectUser, LoadUser, LoadUserSuccess } from '../actions';
import { User } from '@shared/models/user';

@Injectable({
  providedIn: 'root',
})
export class UserDetailsGuard implements CanActivate {
  constructor(
    private store: Store<fromUsers.State>,
  ) {
  }

  hasUserInStore(id: number): Observable<User> {
    return this.store.pipe(
      select(fromUsers.getAllUsers),
      map(users => users.find(user => user.id === id)),
      take(1)
    );
  }

  hasUser(id: number): Observable<boolean> {
    return this.hasUserInStore(id).pipe(
      tap(user => {
        if (!user) {
          this.store.dispatch(new LoadUser(id));
        } else {
          this.store.dispatch(new SelectUser(user));
        }
      }),
      switchMap(() => {
        return of(true);
      })
    );
  }

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.hasUser(Number(route.params['userId']));
  }
}
