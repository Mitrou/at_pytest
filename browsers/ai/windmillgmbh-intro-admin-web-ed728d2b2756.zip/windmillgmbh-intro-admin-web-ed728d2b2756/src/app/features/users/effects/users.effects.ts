import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import { Observable, of } from 'rxjs';
import { map, switchMap, catchError, tap, debounceTime } from 'rxjs/operators';

import {
  UserActionTypes,
  LoadUsers,
  LoadUsersSuccess,
  LoadUsersFailure,
  LoadUser,
  LoadUserSuccess,
  LoadUserFailure,
  NavigateToDetailsPage
} from '../actions';

import { UserService } from '../services/user.service';

import { User } from '@shared/models/user';
import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';

@Injectable()
export class UsersEffects {
  @Effect()
  loadUsers$: Observable<Action> = this.actions$.pipe(
    ofType<LoadUsers>(UserActionTypes.LoadUsers),
    debounceTime(300),
    map((action) => action.payload),
    switchMap((params: LoadListPayload) =>
      this.userService.loadUsers(params)
        .pipe(
          map((payload: LoadListSuccessPayload<User>) =>
            new LoadUsersSuccess(payload)
          ),
          catchError((e: HttpErrorResponse) => of(
            new LoadUsersFailure(e.message)
          ))
        )
    )
  );

  @Effect({ dispatch: false })
  navigateToUserDetails$: Observable<any> = this.actions$.pipe(
    ofType<NavigateToDetailsPage>(UserActionTypes.NavigateToDetailsPage),
    tap(action => this.router.navigate(['users', action.payload, 'details']))
  );

  @Effect()
  loadUser$: Observable<Action> = this.actions$.pipe(
    ofType<LoadUser>(UserActionTypes.LoadUser),
    switchMap(action =>
      this.userService.loadUser(action.payload).pipe(
        map(payload => new LoadUserSuccess(new User(payload))),
        catchError((e: HttpErrorResponse) => of(
          new LoadUserFailure(e.message)
        ))
      )
    )
  );

  constructor(
    private actions$: Actions,
    private router: Router,
    private userService: UserService
  ) { }
}
