import { UserActionTypes, UserActionsUnion } from '../actions';

import { User } from '@shared/models/user';

export interface State {
  user: User;
  error: string;
  pending: boolean;
}

export const initialState: State = {
  user: null,
  error: null,
  pending: false,
};

export function reducer(state = initialState, action: UserActionsUnion) {
  switch (action.type) {
    case UserActionTypes.LoadUser:
      return {
        ...state,
        error: null,
        pending: true
      };
    case UserActionTypes.SelectUser:
    case UserActionTypes.LoadUserSuccess:
      return {
        ...state,
        user: action.payload,
        error: null,
        pending: false,
      };
    case UserActionTypes.LoadUserFailure:
      return {
        ...state,
        error: action.payload,
        pending: false
      };
    default:
      return state;
  }
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getUser = (state: State) => state.user;
