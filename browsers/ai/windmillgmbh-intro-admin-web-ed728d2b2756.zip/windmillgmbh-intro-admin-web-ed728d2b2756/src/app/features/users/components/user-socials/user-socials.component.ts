import { Component, ChangeDetectionStrategy, Input } from '@angular/core';

import { SocialPresence } from '@shared/models/user';

@Component({
  selector: 'wml-user-socials',
  templateUrl: './user-socials.component.html',
  styleUrls: ['./user-socials.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserSocialsComponent {
  @Input() social: SocialPresence;
}
