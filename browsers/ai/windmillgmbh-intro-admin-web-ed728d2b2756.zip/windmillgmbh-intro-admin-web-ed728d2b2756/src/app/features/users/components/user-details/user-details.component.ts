import { Component, ChangeDetectionStrategy, Input, OnInit } from '@angular/core';

import { Store, select } from '@ngrx/store';

import * as fromUsers from '../../reducers';

import { User } from '@shared/models/user';

@Component({
  selector: 'wml-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserDetailsComponent implements OnInit {
  @Input() user: User;
  @Input() error: string;
  @Input() pending: boolean;

  constructor(private store: Store<fromUsers.State>) {}

  ngOnInit() {}
}
