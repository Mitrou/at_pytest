import produce from 'immer';

import { MeetingSpotActionTypes, MeetingSpotsActionsUnion } from "../actions/meeting-spots.actions";

export interface State {
  error: string | null;
  pending: boolean;
}

export const initialState: State = {
  error: null,
  pending: false,
}

export function reducer(state = initialState, action: MeetingSpotsActionsUnion): State {
  return produce(state, (draft) => {
    switch (action.type) {
      case MeetingSpotActionTypes.AddMeetingSpot: {
        draft.error = null;
        draft.pending = true;
        return;
      }

      case MeetingSpotActionTypes.AddMeetingSpotSuccess: {
        draft.error = null;
        draft.pending = false;
        return;
      }

      case MeetingSpotActionTypes.AddMeetingSpotFailure: {
        draft.error = action.payload;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
