import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select, Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';

import * as fromRoot from '../../../reducers/index';
import * as fromDepartments from '../reducers';

import { Observable, of } from 'rxjs';
import { map, exhaustMap, switchMap, withLatestFrom, catchError, tap } from 'rxjs/operators';

import {
  DepartmentActionTypes,
  LoadDepartments,
  LoadDepartmentsSuccess,
  LoadDepartmentsFailure,
  AddDepartment,
  AddDepartmentSuccess,
  AddDepartmentFailure,
  LoadDepartment,
  LoadDepartmentSuccess,
  LoadDepartmentFailure,
  UpdateDepartment,
  UpdateDepartmentSuccess,
  UpdateDepartmentFailure,
  NavigateToUpdateDepartmentPage
} from '../actions/department.actions';

import { DepartmentService } from '../services/department.service';

import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';
import { Department } from '../models/department';

@Injectable()
export class DepartmentsEffects {
  @Effect()
  loadDepartments$: Observable<Action> = this.actions$.pipe(
    ofType<LoadDepartments>(DepartmentActionTypes.LoadDepartments),
    map((action) => action.payload),
    switchMap((params: LoadListPayload) =>
      this.departmentService.loadDepartments(params)
        .pipe(
          map((payload: LoadListSuccessPayload<Department>) => new LoadDepartmentsSuccess(payload)),
          catchError((e) => of(new LoadDepartmentsFailure(e.error.error)))
        )
    )
  );

  @Effect()
  addDepartment$: Observable<Action> = this.actions$.pipe(
    ofType<AddDepartment>(DepartmentActionTypes.AddDepartment),
    map((action) => action.payload),
    exhaustMap((department: Department) =>
      this.departmentService.addDepartment(department)
        .pipe(
          map((payload: Department) => new AddDepartmentSuccess(payload)),
          catchError((e) => of(new AddDepartmentFailure(e.error.error)))
        )
    )
  );

  @Effect()
  loadDepartment$: Observable<Action> = this.actions$.pipe(
    ofType<LoadDepartment>(DepartmentActionTypes.LoadDepartment),
    withLatestFrom(
      this.store.pipe(select(fromDepartments.getSelectedDepartmentId)),
      (action, id: number) => id
    ),
    switchMap((id) =>
      this.departmentService.loadDepartment(id)
        .pipe(
          map((payload: Department) => new LoadDepartmentSuccess(payload)),
          catchError((e) => of(new LoadDepartmentFailure(e.error.error)))
        )
    )
  );

  @Effect({dispatch: false})
  loadDepartmentFailure$: Observable<any> = this.actions$.pipe(
    ofType<LoadDepartmentFailure>(DepartmentActionTypes.LoadDepartmentFailure),
    tap(() => {
      this.router.navigate(['/404']);
    })
  );

  @Effect()
  updateDepartment$: Observable<Action> = this.actions$.pipe(
    ofType<UpdateDepartment>(DepartmentActionTypes.UpdateDepartment),
    map((action) => action.payload),
    exhaustMap((department: Department) =>
      this.departmentService.updateDepartment(department)
        .pipe(
          map((payload: Department) => new UpdateDepartmentSuccess(payload)),
          catchError((e) => of(new UpdateDepartmentFailure(e.error.error)))
        )
    )
  );

  @Effect({dispatch: false})
  navigateToDepartmentsPage$: Observable<any> = this.actions$.pipe(
    ofType(
      DepartmentActionTypes.AddDepartmentSuccess,
      DepartmentActionTypes.UpdateDepartmentSuccess
    ),
    withLatestFrom(
      this.store.pipe(select(fromRoot.getRouterSerializedState)),
      (action, routerState: RouterStateUrl) => routerState.params.universityId
    ),
    tap((universityId) => {
      this.router.navigate(['/universities', universityId, 'departments']);
    })
  );

  @Effect({dispatch: false})
  navigateToUpdateDepartmentPage$: Observable<any> = this.actions$.pipe(
    ofType<NavigateToUpdateDepartmentPage>(DepartmentActionTypes.NavigateToUpdateDepartmentPage),
    withLatestFrom(
      this.store.pipe(select(fromRoot.getRouterSerializedState)),
      (action: NavigateToUpdateDepartmentPage, routerState: RouterStateUrl) => ({
        universityId: routerState.params.universityId,
        departmentId: action.payload
      })
    ),
    tap(({universityId, departmentId}) => {
      this.router.navigate(['/universities', universityId, 'departments', departmentId, 'update']);
    })
  );

  constructor(
    private actions$: Actions,
    private router: Router,
    private store: Store<fromRoot.State>,
    private departmentService: DepartmentService,
  ) {
  }
}
