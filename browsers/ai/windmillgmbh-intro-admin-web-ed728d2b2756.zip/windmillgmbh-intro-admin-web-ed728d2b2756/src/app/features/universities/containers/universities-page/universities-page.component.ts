import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromUniversities from '../../reducers/index';
import * as UniversitiesActions from '../../actions/university.actions';

import { LoadListPayload } from '@shared/models/list';
import { University } from '../../models/university';


@Component({
  selector: 'wml-universities-page',
  templateUrl: './universities-page.component.html'
})
export class UniversitiesPageComponent implements OnInit {
  universities$ = this.store.pipe(select(fromUniversities.getAllUniversities));
  pending$ = this.store.pipe(select(fromUniversities.getUniversitiesPending));
  error$ = this.store.pipe(select(fromUniversities.getUniversitiesError));
  count$ = this.store.pipe(select(fromUniversities.getUniversitiesCount));
  offset$ = this.store.pipe(select(fromUniversities.getUniversitiesOffset));
  limit$ = this.store.pipe(select(fromUniversities.getUniversitiesLimit));

  constructor(private store: Store<fromUniversities.State>) {
  }

  ngOnInit() {
  }

  onReloadGrid($event: LoadListPayload) {
    this.store.dispatch(new UniversitiesActions.LoadUniversities($event));
  }

  onItemSelected($event) {

  }

  onItemEdit($event: University) {
    this.store.dispatch(new UniversitiesActions.NavigateToUpdateUniversityPage($event.id));
  }

  onItemDelete($event) {
  }
}
