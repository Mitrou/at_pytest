import produce from 'immer';

import { UniversityActionTypes, UniversityActionsUnion } from '../actions/university.actions';

export interface State {
  error: string | null;
  pending: boolean;
}

export const initialState: State = {
  error: null,
  pending: false,
};

export function reducer(state = initialState, action: UniversityActionsUnion): State {
  return produce(state, (draft) => {
    switch (action.type) {
      case UniversityActionTypes.LoadUniversity:
      case UniversityActionTypes.UpdateUniversity: {
        draft.error = null;
        draft.pending = true;
        return;
      }

      case UniversityActionTypes.LoadUniversitySuccess:
      case UniversityActionTypes.UpdateUniversitySuccess: {
        draft.error = null;
        draft.pending = false;
        return;
      }

      case UniversityActionTypes.LoadUniversityFailure:
      case UniversityActionTypes.UpdateUniversityFailure: {
        draft.error = action.payload;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
