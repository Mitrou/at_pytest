import { Component, ChangeDetectionStrategy, Input, Output, EventEmitter } from '@angular/core';

import {
  ColumnType,
  } from '@shared/components/grid/grid.configs';

import { LoadListPayload } from '@shared/models/list';
import { Department } from '../../models/department';
import { ColumnFilterType, GridAction, GridOptions } from '@shared/components/grid/grid.configs';

@Component({
  selector: 'wml-departments-list',
  templateUrl: './departments-list.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DepartmentsListComponent {
  @Input() departments: Department[];
  @Input() pending: boolean;
  @Input() error: string | null;
  @Input() count: number;
  @Input() offset: number;
  @Input() limit: number;

  @Input() drawerOpened = false;

  @Output() reloadGrid = new EventEmitter<LoadListPayload>();
  @Output() selectItem = new EventEmitter<any>();
  @Output() editItem = new EventEmitter<any>();
  @Output() deleteItem = new EventEmitter<any>();

  options: GridOptions = {
    actions: [GridAction.Edit, GridAction.Delete],
    columns: [
      {
        name: 'Department',
        prop: 'name',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        name: 'Description',
        prop: 'description',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        name: 'Status',
        prop: 'isActive',
        columnType: ColumnType.Status,
        filterable: true,
        filterType: ColumnFilterType.Select,
        filterProp: 'isActive',
        filterData: [
          {isActive: true, title: 'Active'},
          {isActive: false, title: 'Pause'},
        ]
      }
    ]
  };
}
