import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { select, Store } from '@ngrx/store';

import { Observable, of } from 'rxjs';
import { map, switchMap, take, tap } from 'rxjs/operators';

import * as fromDepartments from '../reducers';
import { SelectDepartment, LoadDepartment } from '../actions/department.actions';

@Injectable({
  providedIn: 'root',
})
export class DepartmentInStoreGuard implements CanActivate {
  constructor(
    private store: Store<fromDepartments.State>,
  ) {
  }

  hasDepartmentInStore(id: number): Observable<boolean> {
    return this.store.pipe(
      select(fromDepartments.getDepartmentEntities),
      map(entities => !!entities[id]),
      take(1)
    );
  }

  hasDepartment(id: number): Observable<boolean> {
    return this.hasDepartmentInStore(id).pipe(
      tap(() => this.store.dispatch(new SelectDepartment(id))),
      tap((inStore) => {
        if (!inStore) {
          this.store.dispatch(new LoadDepartment());
        }
      }),
      switchMap(() => {
        return of(true);
      })
    );
  }

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.hasDepartment(Number(route.params['departmentId']));
  }
}
