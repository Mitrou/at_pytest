import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MeetingSpot } from '../../models/meeting-spot';

@Component({
  selector: 'wml-meeting-spot-form',
  templateUrl: './meeting-spot-form.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MeetingSpotFormComponent {
  @Input()
  set universityId(universityId: string) {
    if (universityId) {
      this.form.get('universityId').setValue(Number(universityId));
    }
  }

  @Input() meetingSpotId: string | null = null;

  @Input()
    set meetingSpot(meetingSpot: MeetingSpot | undefined) {
    if (meetingSpot) {
      this.form.patchValue({
        id: meetingSpot.id,
        name: meetingSpot.spot,
        status: meetingSpot.isActive,
        address: meetingSpot.campus,
        description: meetingSpot.description,
      });
    }
  }

  @Input()
    set pending(isPending: boolean) {
    this.isPending = isPending;

    if (isPending) {
      this.form.disable();
    } else {
      this.form.enable();
    }
  }

  @Input() error: string | null;

  @Output() submitted = new EventEmitter<MeetingSpot>();

  isPending: boolean;

  form: FormGroup = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', Validators.required),
    status: new FormControl(true, Validators.required),
    address: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required),
    universityId: new FormControl('', Validators.required),
  });

  constructor() {
  }

  submit() {
    if (this.form.valid) {
      this.submitted.emit(this.form.value);
    }
  }
}
