import produce from 'immer';

import { MeetingSpotActionTypes, MeetingSpotsActionsUnion } from '../actions/meeting-spots.actions';

export interface State {
  error: string | null;
  pending: boolean;
}

export const initialState: State = {
  error: null,
  pending: false,
};

export function reducer(state = initialState, action: MeetingSpotsActionsUnion): State {
  return produce(state, draftState => {
    switch (action.type) {
      case MeetingSpotActionTypes.LoadMeetingSpot:
      case MeetingSpotActionTypes.UpdateMeetingSpot: {
        draftState.error = null;
        draftState.pending = true;
        return;
      }

      case MeetingSpotActionTypes.LoadMeetingSpotSuccess:
      case MeetingSpotActionTypes.UpdateMeetingSpotSuccess: {
        draftState.error = null;
        draftState.pending = false;
        return;
      }

      case MeetingSpotActionTypes.LoadMeetingSpotFailure:
      case MeetingSpotActionTypes.UpdateMeetingSpotFailure: {
        draftState.error = action.payload;
        draftState.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
