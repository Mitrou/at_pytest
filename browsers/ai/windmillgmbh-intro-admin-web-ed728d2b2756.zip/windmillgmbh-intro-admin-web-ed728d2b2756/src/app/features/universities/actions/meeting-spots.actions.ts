import { Action } from '@ngrx/store';

import { MeetingSpot } from '../models/meeting-spot';
import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';

export enum MeetingSpotActionTypes {
  LoadMeetingSpots = '[MeetingSpots] Load Meeting Spots',
  LoadMeetingSpotsSuccess = '[MeetingSpots] Load Meeting Spots Success',
  LoadMeetingSpotsFailure = '[MeetingSpots] Load Meeting Spots Failure',
  AddMeetingSpot = '[MeetingSpots] Add Meeting Spot',
  AddMeetingSpotSuccess = '[MeetingSpots] Add Meeting Spot Success',
  AddMeetingSpotFailure = '[MeetingSpots] Add Meeting Spot Failure',
  SelectMeetingSpot = '[MeetingSpots] Select Meeting Spot',
  LoadMeetingSpot = '[MeetingSpots] Load Meeting Spot',
  LoadMeetingSpotSuccess = '[MeetingSpots] Load Meeting Spot Success',
  LoadMeetingSpotFailure = '[MeetingSpots] Load Meeting Spot Failure',
  UpdateMeetingSpot = '[MeetingSpots] Update Meeting Spot',
  UpdateMeetingSpotSuccess = '[MeetingSpots] Update Meeting Spot Success',
  UpdateMeetingSpotFailure = '[MeetingSpots] Update Meeting Spot Failure',
  NavigateToUpdateMeetingSpotPage = '[MeetingSpots] Navigate To Update Meeting Spot Page',
}

export class LoadMeetingSpots implements Action {
  readonly type = MeetingSpotActionTypes.LoadMeetingSpots;

  constructor(public payload: LoadListPayload = new LoadListPayload()) {
  }
}

export class LoadMeetingSpotsSuccess implements Action {
  readonly type = MeetingSpotActionTypes.LoadMeetingSpotsSuccess;

  constructor(public payload: LoadListSuccessPayload<MeetingSpot>) {
  }
}


export class LoadMeetingSpotsFailure implements Action {
  readonly type = MeetingSpotActionTypes.LoadMeetingSpotsFailure;

  constructor(public payload: string) {
  }
}

export class AddMeetingSpot implements Action {
  readonly type: MeetingSpotActionTypes.AddMeetingSpot;

  constructor(public payload: MeetingSpot) {
  }
}

export class AddMeetingSpotSuccess implements Action {
  readonly type = MeetingSpotActionTypes.AddMeetingSpotSuccess;

  constructor(public payload: MeetingSpot) {
  }
}

export class AddMeetingSpotFailure implements Action {
  readonly type = MeetingSpotActionTypes.AddMeetingSpotFailure;

  constructor(public payload: string) {
  }
}

export class SelectMeetingSpot implements Action {
  readonly type = MeetingSpotActionTypes.SelectMeetingSpot;

  constructor(public payload: number) {
  }
}

export class LoadMeetingSpot implements Action {
  readonly type = MeetingSpotActionTypes.LoadMeetingSpot;
}

export class LoadMeetingSpotSuccess implements Action {
  readonly type = MeetingSpotActionTypes.LoadMeetingSpotSuccess;

  constructor(public payload: MeetingSpot) {
  }
}

export class LoadMeetingSpotFailure implements Action {
  readonly type = MeetingSpotActionTypes.LoadMeetingSpotFailure;

  constructor(public payload: string) {
  }
}

export class UpdateMeetingSpot implements Action {
  readonly type = MeetingSpotActionTypes.UpdateMeetingSpot;

  constructor(public payload: MeetingSpot) {
  }
}

export class UpdateMeetingSpotSuccess implements Action {
  readonly type = MeetingSpotActionTypes.UpdateMeetingSpotSuccess;

  constructor(public payload: MeetingSpot) {
  }
}

export class UpdateMeetingSpotFailure implements Action {
  readonly type = MeetingSpotActionTypes.UpdateMeetingSpotFailure;

  constructor(public payload: string) {
  }
}

export class NavigateToUpdateMeetingSpotPage implements Action {
  readonly type = MeetingSpotActionTypes.NavigateToUpdateMeetingSpotPage;

  constructor(public payload: number) {
  }
}

export type MeetingSpotsActionsUnion =
  | LoadMeetingSpots
  | LoadMeetingSpotsSuccess
  | LoadMeetingSpotsFailure
  | AddMeetingSpot
  | AddMeetingSpotSuccess
  | AddMeetingSpotFailure
  | SelectMeetingSpot
  | LoadMeetingSpot
  | LoadMeetingSpotSuccess
  | LoadMeetingSpotFailure
  | UpdateMeetingSpot
  | UpdateMeetingSpotSuccess
  | UpdateMeetingSpotFailure
  | NavigateToUpdateMeetingSpotPage
  ;
