import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UniversityInStoreGuard } from './services/university-in-store.guard';
import { DepartmentInStoreGuard } from './services/department-in-store.guard';
import { MeetingSpotInStoreGuard } from './services/meeting-spot-in-store.guard';
import { OpenDrawerGuard } from '../../core/services/open-drawer-guard.service';
import { CloseDrawerGuard } from '../../core/services/close-drawer-guard.service';

import { UniversitiesPageComponent } from './containers/universities-page/universities-page.component';
import { AddUniversityPageComponent } from './containers/add-university-page/add-university-page.component';
import { UpdateUniversityPageComponent } from './containers/update-university-page/update-university-page.component';
import { MeetingSpotsPageComponent } from './containers/meeting-spots-page/meeting-spots-page.component';
import { MeetingSpotUpdatePanelComponent } from './containers/meeting-spot-update-panel/meeting-spot-update-panel.component';
import { DepartmentsPageComponent } from './containers/departments-page/departments-page.component';
import { DepartmentUpdatePanelComponent } from './containers/department-update-panel/department-update-panel.component';
import { AddDepartmentPageComponent } from './containers/add-department-page/add-department-page.component';

export const routes: Routes = [
  {path: '', component: UniversitiesPageComponent},
  {path: 'add', component: AddUniversityPageComponent},
  {path: 'add', component: AddUniversityPageComponent},
  {
    path: ':universityId/update',
    component: UpdateUniversityPageComponent,
    canActivate: [UniversityInStoreGuard],
  },
  {
    path: ':universityId/meeting-spots', component: MeetingSpotsPageComponent, children: [
      {
        path: ':meetingSpotId/update',
        component: MeetingSpotUpdatePanelComponent,
        canActivate: [MeetingSpotInStoreGuard, OpenDrawerGuard],
        canDeactivate: [CloseDrawerGuard],
      }
    ]
  },
  {
    path: ':universityId/departments', component: DepartmentsPageComponent, children: [
      {
        path: ':departmentId/update',
        component: DepartmentUpdatePanelComponent,
        canActivate: [DepartmentInStoreGuard, OpenDrawerGuard],
        canDeactivate: [CloseDrawerGuard],
      }
    ]
  },
  {path: ':universityId/departments/add', component: AddDepartmentPageComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UniversitiesRoutingModule {
}
