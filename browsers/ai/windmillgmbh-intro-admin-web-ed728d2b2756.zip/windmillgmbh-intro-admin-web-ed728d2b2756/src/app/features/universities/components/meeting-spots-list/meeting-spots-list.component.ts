import { Component, ChangeDetectionStrategy, Input, Output, EventEmitter } from '@angular/core';

import {
  GridAction,
  GridOptions,
  ColumnType,
  ColumnFilterType,
} from '@shared/components/grid/grid.configs';

import { LoadListPayload } from '@shared/models/list';
import { MeetingSpot } from '../../models/meeting-spot';

@Component({
  selector: 'wml-meeting-spots-list',
  templateUrl: './meeting-spots-list.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MeetingSpotsListComponent {
  @Input() meetingSpots: MeetingSpot[];
  @Input() pending: boolean;
  @Input() error: string | null;
  @Input() count: number;
  @Input() offset: number;
  @Input() limit: number;

  @Output() reloadGrid = new EventEmitter<LoadListPayload>();
  @Output() selectItem = new EventEmitter<any>();
  @Output() editItem = new EventEmitter<any>();
  @Output() deleteItem = new EventEmitter<any>();

  options: GridOptions = {
    actions: [GridAction.Edit, GridAction.Delete],
    columns: [
      {
        name: 'Spot Name',
        prop: 'spot',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        name: 'Status',
        prop: 'isActive',
        columnType: ColumnType.Status,
        filterable: true,
        filterType: ColumnFilterType.Select,
        filterProp: 'isActive',
        filterData: [
          {isActive: true, title: 'Active'},
          {isActive: false, title: 'Pause'},
        ]
      },
      {
        name: 'Adress',
        prop: 'campus',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        name: 'Type',
        prop: 'description',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      }
    ]
  };
}
