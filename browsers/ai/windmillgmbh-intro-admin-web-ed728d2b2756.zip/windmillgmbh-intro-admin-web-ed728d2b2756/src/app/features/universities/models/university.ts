export interface University {
  id?: number;
  name: string;
  city: string;
  country: string;
  campusName: string;
  startTime: string;
  endTime: string;
  timeZone: string;
  emailDomain: string;
  isActive: boolean;
}
