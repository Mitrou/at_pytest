import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { select, Store } from '@ngrx/store';

import { Observable, of } from 'rxjs';
import { map, switchMap, take, tap } from 'rxjs/internal/operators';

import * as fromUniversityMeetingSpots from '../reducers';
import { SelectMeetingSpot, LoadMeetingSpot } from '../actions/meeting-spots.actions';

@Injectable({
  providedIn: 'root',
})
export class MeetingSpotInStoreGuard implements CanActivate {
  constructor(private store: Store<fromUniversityMeetingSpots.State>) {
  }

  hasMeetingSpotInStore(id: number): Observable<boolean> {
    return this.store.pipe(
      select(fromUniversityMeetingSpots.getMeetingSpotEntities),
      map(entities => !!entities[id]),
      take(1)
    );
  }

  hasMeetingSpot(id: number): Observable<boolean> {
    return this.hasMeetingSpotInStore(id).pipe(
      tap(() => this.store.dispatch(new SelectMeetingSpot(id))),
      tap((inStore) => {
        if (!inStore) {
          this.store.dispatch(new LoadMeetingSpot());
        }
      }),
      switchMap(() => {
        return of(true);
      })
    );
  }

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.hasMeetingSpot(Number(route.params['meetingSpotId']));
  }
}
