import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { select, Store } from '@ngrx/store';

import { Observable, of } from 'rxjs';
import { map, switchMap, take, tap } from 'rxjs/operators';

import * as fromUniversities from '../reducers';
import { SelectUniversity, LoadUniversity } from '../actions/university.actions';

@Injectable({
  providedIn: 'root',
})
export class UniversityInStoreGuard implements CanActivate {
  constructor(
    private store: Store<fromUniversities.State>,
  ) {
  }

  hasUniversityInStore(id: number): Observable<boolean> {
    return this.store.pipe(
      select(fromUniversities.getUniversityEntities),
      map(entities => !!entities[id]),
      take(1)
    );
  }

  hasUniversity(id: number): Observable<boolean> {
    return this.hasUniversityInStore(id).pipe(
      tap(() => this.store.dispatch(new SelectUniversity(id))),
      tap((inStore) => {
        if (!inStore) {
          this.store.dispatch(new LoadUniversity());
        }
      }),
      switchMap(() => {
        return of(true);
      })
    );
  }

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.hasUniversity(Number(route.params['universityId']));
  }
}
