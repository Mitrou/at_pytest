import { Component } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from '../../../../reducers';
import * as fromUniversities from '../../reducers';
import * as UniversitiesActions from '../../actions/university.actions';

import { map } from 'rxjs/operators';

import { University } from '../../models/university';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';

@Component({
  selector: 'wml-universities-page',
  templateUrl: './update-university-page.component.html'
})
export class UpdateUniversityPageComponent {
  universityId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.universityId)
  );
  university$ = this.store.pipe(select(fromUniversities.getSelectedUniversity));
  pending$ = this.store.pipe(select(fromUniversities.getUpdateUniversityPagePending));
  error$ = this.store.pipe(select(fromUniversities.getUpdateUniversityPageError));

  constructor(private store: Store<fromUniversities.State>) {
  }

  onSubmit($event: University) {
    this.store.dispatch(new UniversitiesActions.UpdateUniversity($event));
  }
}
