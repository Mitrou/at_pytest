import { Component } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from '../../../../reducers';
import * as fromDepartments from '../../reducers/index';
import * as DepartmentsActions from '../../actions/department.actions';

import { map } from 'rxjs/operators';

import { Department } from '../../models/department';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';

@Component({
  selector: 'wml-add-department-page',
  templateUrl: './add-department-page.component.html'
})
export class AddDepartmentPageComponent {
  universityId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.universityId)
  );
  pending$ = this.store.pipe(select(fromDepartments.getAddDepartmentPagePending));
  error$ = this.store.pipe(select(fromDepartments.getAddDepartmentPageError));

  constructor(private store: Store<fromDepartments.State>) {
  }

  onSubmit($event: Department) {
    this.store.dispatch(new DepartmentsActions.AddDepartment($event));
  }
}
