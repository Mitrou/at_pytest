import {
  createSelector,
  createFeatureSelector,
  ActionReducerMap,
} from '@ngrx/store';

import * as fromRoot from '../../../reducers';
import * as fromUniversities from './universities.reducer';
import * as fromAddUniversityPage from './add-university-page.reducer';
import * as fromUpdateUniversityPage from './update-university-page.reducer';
import * as fromDepartmentUpdatePanel from './department-update-panel.reducer';
import * as fromAddDepartmentPage from './add-department-page.reducer';
import * as fromMeetingSpotUpdatePanel from './meeting-spot-update-panel.reducer';
import * as fromAddMeetingSpotPage from './add-meeting-spot-page.redicer';

import * as fromDepartments from './departments.reducer';

import * as fromSpots from './meeting-spots.reducer';


export interface UniversitiesState {
  universities: fromUniversities.State;
  addUniversityPage: fromAddUniversityPage.State;
  updateUniversityPage: fromUpdateUniversityPage.State;
  departments: fromDepartments.State;
  departmentUpdatePanel: fromDepartmentUpdatePanel.State;
  addDepartmentPage: fromAddDepartmentPage.State;
  meetingSpots: fromSpots.State;
  meetingSpotUpdatePanel: fromMeetingSpotUpdatePanel.State;
  addMeetingSpotPage: fromAddMeetingSpotPage.State;
}

export interface State extends fromRoot.State {
  universities: UniversitiesState;
}

export const reducers: ActionReducerMap<UniversitiesState> = {
  universities: fromUniversities.reducer,
  addUniversityPage: fromAddUniversityPage.reducer,
  updateUniversityPage: fromUpdateUniversityPage.reducer,
  departments: fromDepartments.reducer,
  departmentUpdatePanel: fromDepartmentUpdatePanel.reducer,
  addDepartmentPage: fromAddDepartmentPage.reducer,
  meetingSpots: fromSpots.reducer,
  meetingSpotUpdatePanel: fromMeetingSpotUpdatePanel.reducer,
  addMeetingSpotPage: fromAddMeetingSpotPage.reducer,
};

export const getUniversitiesState = createFeatureSelector<State, UniversitiesState>('universities');

// universities selectors
export const getUniversityEntitiesState = createSelector(
  getUniversitiesState,
  state => state.universities
);
export const getSelectedUniversityId = createSelector(
  getUniversityEntitiesState,
  fromUniversities.getSelectedUniversityId
);
export const getUniversitiesError = createSelector(
  getUniversityEntitiesState,
  fromUniversities.getError
);
export const getUniversitiesPending = createSelector(
  getUniversityEntitiesState,
  fromUniversities.getPending
);
export const getUniversitiesCount = createSelector(
  getUniversityEntitiesState,
  fromUniversities.getCount
);
export const getUniversitiesOffset = createSelector(
  getUniversityEntitiesState,
  fromUniversities.getOffset
);
export const getUniversitiesLimit = createSelector(
  getUniversityEntitiesState,
  fromUniversities.getLimit
);

/**
 * Adapters created with @ngrx/entity generate
 * commonly used selector functions including
 * getting all ids in the record set, a dictionary
 * of the records by id, an array of records and
 * the total number of records. This reduces boilerplate
 * in selecting records from the entity state.
 */
export const {
  selectEntities: getUniversityEntities,
  selectAll: getAllUniversities,
} = fromUniversities.universityEntityAdapter.getSelectors(getUniversityEntitiesState);

export const getSelectedUniversity = createSelector(
  getUniversityEntities,
  getSelectedUniversityId,
  (entities, selectedId) => {
    return selectedId !== null && entities[selectedId];
  }
);

// addUniversityPage selectors
export const selectAddUniversityPageState = createSelector(
  getUniversitiesState,
  (state: UniversitiesState) => state.addUniversityPage
);
export const getAddUniversityPageError = createSelector(
  selectAddUniversityPageState,
  fromAddUniversityPage.getError
);
export const getAddUniversityPagePending = createSelector(
  selectAddUniversityPageState,
  fromAddUniversityPage.getPending
);

// updateUniversityPage selectors
export const selectUpdateUniversityPageState = createSelector(
  getUniversitiesState,
  (state: UniversitiesState) => state.updateUniversityPage
);
export const getUpdateUniversityPageError = createSelector(
  selectUpdateUniversityPageState,
  fromUpdateUniversityPage.getError
);
export const getUpdateUniversityPagePending = createSelector(
  selectUpdateUniversityPageState,
  fromUpdateUniversityPage.getPending
);

// departments selectors
export const getDepartmentEntitiesState = createSelector(
  getUniversitiesState,
  state => state.departments
);
export const getSelectedDepartmentId = createSelector(
  getDepartmentEntitiesState,
  fromDepartments.getSelectedDepartmentId
);
export const getDepartmentsError = createSelector(
  getDepartmentEntitiesState,
  fromDepartments.getError
);
export const getDepartmentsPending = createSelector(
  getDepartmentEntitiesState,
  fromDepartments.getPending
);
export const getDepartmentsCount = createSelector(
  getDepartmentEntitiesState,
  fromDepartments.getCount
);
export const getDepartmentsOffset = createSelector(
  getDepartmentEntitiesState,
  fromDepartments.getOffset
);
export const getDepartmentsLimit = createSelector(
  getDepartmentEntitiesState,
  fromDepartments.getLimit
);


/**
 * Adapters created with @ngrx/entity generate
 * commonly used selector functions including
 * getting all ids in the record set, a dictionary
 * of the records by id, an array of records and
 * the total number of records. This reduces boilerplate
 * in selecting records from the entity state.
 */
export const {
  selectEntities: getDepartmentEntities,
  selectAll: getAllDepartments,
} = fromDepartments.departmentEntityAdapter.getSelectors(getDepartmentEntitiesState);

export const getSelectedDepartment = createSelector(
  getDepartmentEntities,
  getSelectedDepartmentId,
  (entities, selectedId) => {
    return selectedId !== null && entities[selectedId];
  }
);

// departmentUpdatePanel selectors
export const selectDepartmentUpdatePanelState = createSelector(
  getUniversitiesState,
  (state: UniversitiesState) => state.departmentUpdatePanel
);
export const getDepartmentUpdatePanelError = createSelector(
  selectDepartmentUpdatePanelState,
  fromDepartmentUpdatePanel.getError
);
export const getDepartmentUpdatePanelPending = createSelector(
  selectDepartmentUpdatePanelState,
  fromDepartmentUpdatePanel.getPending
);

// addDepartmentPage selectors
export const selectAddDepartmentPageState = createSelector(
  getUniversitiesState,
  (state: UniversitiesState) => state.addDepartmentPage
);
export const getAddDepartmentPageError = createSelector(
  selectAddDepartmentPageState,
  fromAddDepartmentPage.getError
);
export const getAddDepartmentPagePending = createSelector(
  selectAddDepartmentPageState,
  fromAddDepartmentPage.getPending
);


// meetingSpots selectors
export const getMeetingSpotsEntitiesState = createSelector(
  getUniversitiesState,
  state => state.meetingSpots
);
export const getSelectedMeetingSpotsId = createSelector(
  getMeetingSpotsEntitiesState,
  fromSpots.getSelectedMeetingSpotId
);
export const getMeetingSpotsError = createSelector(
  getMeetingSpotsEntitiesState,
  fromSpots.getError
);
export const getMeetingSpotsPending = createSelector(
  getMeetingSpotsEntitiesState,
  fromSpots.getPending
);
export const getMeetingSpotsCount = createSelector(
  getMeetingSpotsEntitiesState,
  fromSpots.getCount
);
export const getMeetingSpotsOffset = createSelector(
  getMeetingSpotsEntitiesState,
  fromSpots.getOffset
);
export const getMeetingSpotsLimit = createSelector(
  getMeetingSpotsEntitiesState,
  fromSpots.getLimit
);

export const {
  selectEntities: getMeetingSpotEntities,
  selectAll: getAllMeetingSpots,
} = fromSpots.meetingSpotEntityAdapter.getSelectors(getMeetingSpotsEntitiesState);

export const getSelectedMeetingSpot = createSelector(
  getMeetingSpotEntities,
  getSelectedMeetingSpotsId,
  (entities, selectedId) => {
    return selectedId !== null && entities[selectedId];
  }
);

// meetingSpotUpdatePanel selectors
export const selectMeetingSpotUpdatePanelState = createSelector(
  getUniversitiesState,
  (state: UniversitiesState) => state.meetingSpotUpdatePanel
);
export  const getMeetingSpotUpdatePanelError = createSelector(
  selectMeetingSpotUpdatePanelState,
  fromMeetingSpotUpdatePanel.getError
);
export const getMeetingSpotUpdatePanelPending = createSelector(
  selectMeetingSpotUpdatePanelState,
  fromMeetingSpotUpdatePanel.getPending
);

// addMeetingSpotPage selectors
export const selectAddMeetingSpotPageState = createSelector(
  getUniversitiesState,
  (state: UniversitiesState) => state.addMeetingSpotPage
);
export const getMeetingSpotPageError = createSelector(
  selectAddMeetingSpotPageState,
  fromAddMeetingSpotPage.getError
);
export const getAddMeetingSpotPagePending = createSelector(
  selectAddMeetingSpotPageState,
  fromAddMeetingSpotPage.getPending
);

