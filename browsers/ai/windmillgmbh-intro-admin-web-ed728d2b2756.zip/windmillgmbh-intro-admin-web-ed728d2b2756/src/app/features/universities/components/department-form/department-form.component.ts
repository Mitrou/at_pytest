import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { Department } from '../../models/department';

@Component({
  selector: 'wml-department-form',
  templateUrl: './department-form.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DepartmentFormComponent {
  @Input()
  set universityId(universityId: string) {
    if (universityId) {
      this.form.get('universityId').setValue(Number(universityId));
    }
  }

  @Input() departmentId: string | null = null;

  @Input()
  set department(department: Department | undefined) {
    if (department) {
      this.form.patchValue({
        id: department.id,
        name: department.name,
        description: department.description,
        isActive: department.isActive,
      });
    }
  }

  @Input()
  set pending(isPending: boolean) {
    this.isPending = isPending;

    if (isPending) {
      this.form.disable();
    } else {
      this.form.enable();
    }
  }

  @Input() error: string | null;

  @Output() submitted = new EventEmitter<Department>();

  isPending: boolean;

  form: FormGroup = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required),
    isActive: new FormControl(true, Validators.required),
    universityId: new FormControl('', Validators.required),
  });

  constructor() {
  }

  submit() {
    if (this.form.valid) {
      this.submitted.emit(this.form.value);
    }
  }
}
