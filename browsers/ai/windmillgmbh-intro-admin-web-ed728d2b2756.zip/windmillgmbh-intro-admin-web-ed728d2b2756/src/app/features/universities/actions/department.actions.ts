import { Action } from '@ngrx/store';

import { Department } from '../models/department';
import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';

export enum DepartmentActionTypes {
  LoadDepartments = '[Departments] Load Departments',
  LoadDepartmentsSuccess = '[Departments] Load Departments Success',
  LoadDepartmentsFailure = '[Departments] Load Departments Failure',
  AddDepartment = '[Departments] Add Department',
  AddDepartmentSuccess = '[Departments] Add Department Success',
  AddDepartmentFailure = '[Departments] Add Department Failure',
  SelectDepartment = '[Departments] Select Department',
  LoadDepartment = '[Departments] Load Department',
  LoadDepartmentSuccess = '[Departments] Load Department Success',
  LoadDepartmentFailure = '[Departments] Load Department Failure',
  UpdateDepartment = '[Departments] Update Department',
  UpdateDepartmentSuccess = '[Departments] Update Department Success',
  UpdateDepartmentFailure = '[Departments] Update Department Failure',
  NavigateToUpdateDepartmentPage = '[Departments] Navigate To Update Department Page',
}

export class LoadDepartments implements Action {
  readonly type = DepartmentActionTypes.LoadDepartments;

  constructor(public payload: LoadListPayload = new LoadListPayload()) {
  }
}

export class LoadDepartmentsSuccess implements Action {
  readonly type = DepartmentActionTypes.LoadDepartmentsSuccess;

  constructor(public payload: LoadListSuccessPayload<Department>) {
  }
}

export class LoadDepartmentsFailure implements Action {
  readonly type = DepartmentActionTypes.LoadDepartmentsFailure;

  constructor(public payload: string) {
  }
}

export class AddDepartment implements Action {
  readonly type = DepartmentActionTypes.AddDepartment;

  constructor(public payload: Department) {
  }
}

export class AddDepartmentSuccess implements Action {
  readonly type = DepartmentActionTypes.AddDepartmentSuccess;

  constructor(public payload: Department) {
  }
}

export class AddDepartmentFailure implements Action {
  readonly type = DepartmentActionTypes.AddDepartmentFailure;

  constructor(public payload: string) {
  }
}

export class SelectDepartment implements Action {
  readonly type = DepartmentActionTypes.SelectDepartment;

  constructor(public payload: number) {
  }
}

export class LoadDepartment implements Action {
  readonly type = DepartmentActionTypes.LoadDepartment;
}

export class LoadDepartmentSuccess implements Action {
  readonly type = DepartmentActionTypes.LoadDepartmentSuccess;

  constructor(public payload: Department) {
  }
}

export class LoadDepartmentFailure implements Action {
  readonly type = DepartmentActionTypes.LoadDepartmentFailure;

  constructor(public payload: string) {
  }
}

export class UpdateDepartment implements Action {
  readonly type = DepartmentActionTypes.UpdateDepartment;

  constructor(public payload: Department) {
  }
}

export class UpdateDepartmentSuccess implements Action {
  readonly type = DepartmentActionTypes.UpdateDepartmentSuccess;

  constructor(public payload: Department) {
  }
}

export class UpdateDepartmentFailure implements Action {
  readonly type = DepartmentActionTypes.UpdateDepartmentFailure;

  constructor(public payload: string) {
  }
}

export class NavigateToUpdateDepartmentPage implements Action {
  readonly type = DepartmentActionTypes.NavigateToUpdateDepartmentPage;

  constructor(public payload: number) {
  }
}

export type DepartmentActionsUnion =
  | LoadDepartments
  | LoadDepartmentsSuccess
  | LoadDepartmentsFailure
  | AddDepartment
  | AddDepartmentSuccess
  | AddDepartmentFailure
  | SelectDepartment
  | LoadDepartment
  | LoadDepartmentSuccess
  | LoadDepartmentFailure
  | UpdateDepartment
  | UpdateDepartmentSuccess
  | UpdateDepartmentFailure
  | NavigateToUpdateDepartmentPage
  ;
