import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';

import { DepartmentActionsUnion, DepartmentActionTypes } from '../actions/department.actions';

import { Department } from '../models/department';

export interface State extends EntityState<Department> {
  // additional entities state properties
  error: string | null;
  pending: boolean;
  count: number;
  offset: number;
  limit: number;
  selectedDepartmentId: number | null;
}

export const departmentEntityAdapter: EntityAdapter<Department> = createEntityAdapter<Department>({
  selectId: (department: Department) => department.id,
  sortComparer: false,
});

export const initialState: State = departmentEntityAdapter.getInitialState({
  // additional entity state properties
  error: null,
  pending: false,
  count: 0,
  offset: 0,
  limit: 10,
  selectedDepartmentId: null,
});

export function reducer(state = initialState, action: DepartmentActionsUnion): State {
  switch (action.type) {
    case DepartmentActionTypes.LoadDepartments: {
      return {
        ...state,
        error: null,
        pending: true,
        offset: action.payload.pageInfo.offset,
        limit: action.payload.pageInfo.limit,
      };
    }

    case DepartmentActionTypes.LoadDepartmentsSuccess: {
      return departmentEntityAdapter.addAll(action.payload.data, {
        ...state,
        error: null,
        pending: false,
        count: action.payload.count
      });
    }

    case DepartmentActionTypes.LoadDepartmentsFailure: {
      return {
        ...state,
        error: action.payload,
        pending: false,
        count: 0,
        offset: 0,
      };
    }

    case DepartmentActionTypes.AddDepartmentSuccess:
    case DepartmentActionTypes.LoadDepartmentSuccess: {
      return departmentEntityAdapter.addOne(action.payload, state);
    }

    case DepartmentActionTypes.UpdateDepartmentSuccess: {
      return departmentEntityAdapter.upsertOne(action.payload, state);
    }

    case DepartmentActionTypes.SelectDepartment: {
      return {
        ...state,
        selectedDepartmentId: action.payload,
      };
    }

    default: {
      return state;
    }
  }
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getCount = (state: State) => state.count;
export const getOffset = (state: State) => state.offset;
export const getLimit = (state: State) => state.limit;
export const getSelectedDepartmentId = (state: State) => state.selectedDepartmentId;
