import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select, Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';

import * as fromRoot from '../../../reducers/index';
import * as fromUniversities from '../reducers';

import { Observable, of } from 'rxjs';
import { map, exhaustMap, switchMap, withLatestFrom, catchError, tap } from 'rxjs/operators';

import {
  MeetingSpotActionTypes,
  LoadMeetingSpots,
  LoadMeetingSpotsSuccess,
  LoadMeetingSpotsFailure,
  AddMeetingSpot,
  AddMeetingSpotSuccess,
  AddMeetingSpotFailure,
  LoadMeetingSpot,
  LoadMeetingSpotSuccess,
  LoadMeetingSpotFailure,
  UpdateMeetingSpot,
  UpdateMeetingSpotSuccess,
  UpdateMeetingSpotFailure,
  NavigateToUpdateMeetingSpotPage
} from '../actions/meeting-spots.actions';

import { MeetingSpotService } from '../services/meeting-spot.service';

import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';
import { MeetingSpot } from '../models/meeting-spot';

@Injectable()
export class MeetingSpotEffects {
  @Effect()
  loadMeetingSpots$: Observable<Action> = this.actions$.pipe(
    ofType<LoadMeetingSpots>(MeetingSpotActionTypes.LoadMeetingSpots),
    map((action) => action.payload),
    switchMap((params: LoadListPayload) =>
      this.meetingSpotService.loadMeetingSpots(params)
        .pipe(
          map((payload: LoadListSuccessPayload<MeetingSpot>) => new LoadMeetingSpotsSuccess(payload)),
          catchError((e) => of(new LoadMeetingSpotsFailure(e.error.error)))
        )
    )
  );

  @Effect()
  addMeetingSpot$: Observable<Action> = this.actions$.pipe(
    ofType<AddMeetingSpot>(MeetingSpotActionTypes.AddMeetingSpot),
    map((action) => action.payload),
    exhaustMap((meetingSpot: MeetingSpot) => this.meetingSpotService.addMeetingSpot(meetingSpot)
      .pipe(
        map((payload: MeetingSpot) => new AddMeetingSpotSuccess(payload)),
        catchError((e) => of(new AddMeetingSpotFailure(e.error.error)))
      )
    )
  );

  @Effect()
  LoadMeetingSpot$: Observable<Action> = this.actions$.pipe(
    ofType<LoadMeetingSpot>(MeetingSpotActionTypes.LoadMeetingSpot),
    withLatestFrom(
      this.store.pipe(select(fromUniversities.getSelectedMeetingSpotsId)),
      (action, id: number) => id
    ),
    switchMap((id) =>
      this.meetingSpotService.loadMeetingSpot(id)
        .pipe(
          map((payload: MeetingSpot) => new LoadMeetingSpotSuccess(payload)),
          catchError((e) => of(new LoadMeetingSpotSuccess(e.error.error)))
        )
    )
  );

  @Effect({dispatch: false})
  loadMeetingSpotFailure$: Observable<any> = this.actions$.pipe(
    ofType<LoadMeetingSpotFailure>(MeetingSpotActionTypes.LoadMeetingSpotFailure),
    tap(() => {
      this.router.navigate(['404']);
    })
  );

  @Effect()
  updateMeetingSpot$: Observable<Action> = this.actions$.pipe(
    ofType<UpdateMeetingSpot>(MeetingSpotActionTypes.UpdateMeetingSpot),
    map((action) => action.payload),
    exhaustMap((meetingSpot: MeetingSpot) => this.meetingSpotService.updateMeetingSpot(meetingSpot)
      .pipe(
        map((payload: MeetingSpot) => new UpdateMeetingSpotSuccess(payload)),
        catchError((e) => of(new UpdateMeetingSpotFailure(e.error.error)))
      )
    )
  );

  @Effect({dispatch: false})
  navigateToMeetingSpotPage$: Observable<any> = this.actions$.pipe(
    ofType(
      MeetingSpotActionTypes.AddMeetingSpotSuccess,
      MeetingSpotActionTypes.UpdateMeetingSpotSuccess
    ),
    withLatestFrom(
      this.store.pipe(select(fromRoot.getRouterSerializedState)),
      (action, routerState: RouterStateUrl) => routerState.params.universityId
    ),
    tap((universityId) => {
      this.router.navigate(['/universities', universityId, 'meeting-spots']);
    })
  );

  @Effect({dispatch: false})
  navigateToUpdateMeetingSpotPage$: Observable<any> = this.actions$.pipe(
    ofType<NavigateToUpdateMeetingSpotPage>(MeetingSpotActionTypes.NavigateToUpdateMeetingSpotPage),
    withLatestFrom(
      this.store.pipe(select(fromRoot.getRouterSerializedState)),
      (action: NavigateToUpdateMeetingSpotPage, routerState: RouterStateUrl) => ({
        universityId: routerState.params.universityId,
        meetingSpotId: action.payload
      })
    ),
    tap(({universityId, meetingSpotId}) => {
      this.router.navigate(['/universities', universityId, 'meeting-spots', meetingSpotId, 'update']);
    })
  );

  constructor(
    private actions$: Actions,
    private router: Router,
    private store: Store<fromRoot.State>,
    private meetingSpotService: MeetingSpotService
  ) {
  }
}

























