import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from '../../../../reducers/index';
import * as fromUniversities from '../../reducers/index';
import * as MeetingSpotsActions from '../../actions/meeting-spots.actions';

import { map } from 'rxjs/operators';

import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';
import { LoadListPayload } from '@shared/models/list';
import {MeetingSpot} from '../../models/meeting-spot';

@Component({
  selector: 'wml-meeting-spots-page',
  templateUrl: './meeting-spots-page.component.html'
})
export class MeetingSpotsPageComponent implements OnInit {
  universityId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.universityId)
  );
  meetingSpots$ = this.store.pipe(select(fromUniversities.getAllMeetingSpots));
  pending$ = this.store.pipe(select(fromUniversities.getMeetingSpotsPending));
  error$ = this.store.pipe(select(fromUniversities.getMeetingSpotsError));
  count$ = this.store.pipe(select(fromUniversities.getMeetingSpotsCount));
  offset$ = this.store.pipe(select(fromUniversities.getMeetingSpotsOffset));
  limit$ = this.store.pipe(select(fromUniversities.getMeetingSpotsLimit));

  constructor(private store: Store<fromUniversities.State>) {
  }

  ngOnInit() {
    this.store.dispatch(new MeetingSpotsActions.LoadMeetingSpots());
  }

  onReloadGrid($event: LoadListPayload) {
    this.store.dispatch(new MeetingSpotsActions.LoadMeetingSpots($event));
  }

  onItemSelected($event) {

  }

  onItemEdit($event: MeetingSpot) {
    this.store.dispatch(new MeetingSpotsActions.NavigateToUpdateMeetingSpotPage($event.id));
  }

  onItemDelete($event) {

  }
}
