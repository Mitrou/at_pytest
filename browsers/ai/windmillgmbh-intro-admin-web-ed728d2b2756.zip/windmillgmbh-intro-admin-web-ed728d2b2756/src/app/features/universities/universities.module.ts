import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { CoreModule } from '../../core/core.module';
import { SharedModule } from '@shared/shared.module';
import { UniversitiesRoutingModule } from './universities-routing.module';

import { reducers } from './reducers';
import { UniversitiesEffects } from './effects/universities.effects';
import { DepartmentsEffects } from './effects/departments.effects';

import { UniversityService } from './services/university.service';
import { DepartmentService } from './services/department.service';
import { MeetingSpotService } from './services/meeting-spot.service';
import { UniversityInStoreGuard } from './services/university-in-store.guard';
import { DepartmentInStoreGuard } from './services/department-in-store.guard';

import { UniversitiesPageComponent } from './containers/universities-page/universities-page.component';
import { UniversitiesListComponent } from './components/universities-list/universities-list.component';
import { UniversityFormComponent } from './components/university-form/university-form.component';
import { UniversityNavigationComponent } from './components/university-navigation/university-navigation.component';
import { AddUniversityPageComponent } from './containers/add-university-page/add-university-page.component';
import { UpdateUniversityPageComponent } from './containers/update-university-page/update-university-page.component';
import { MeetingSpotsPageComponent } from './containers/meeting-spots-page/meeting-spots-page.component';
import { MeetingSpotsListComponent } from './components/meeting-spots-list/meeting-spots-list.component';
import { MeetingSpotUpdatePanelComponent } from './containers/meeting-spot-update-panel/meeting-spot-update-panel.component';
import { MeetingSpotFormComponent } from './components/meeting-spot-form/meeting-spot-form.component';
import { MeetingSpotInStoreGuard } from './services/meeting-spot-in-store.guard';
import { DepartmentsPageComponent } from './containers/departments-page/departments-page.component';
import { DepartmentsListComponent } from './components/departments-list/departments-list.component';
import { DepartmentUpdatePanelComponent } from './containers/department-update-panel/department-update-panel.component';
import { DepartmentFormComponent } from './components/department-form/department-form.component';
import { AddDepartmentPageComponent } from './containers/add-department-page/add-department-page.component';
import {MeetingSpotEffects} from './effects/meeting-spot.effects';

export const COMPONENTS = [
  UniversitiesPageComponent,
  UniversitiesListComponent,
  UniversityFormComponent,
  UniversityNavigationComponent,
  AddUniversityPageComponent,
  UpdateUniversityPageComponent,
  MeetingSpotsPageComponent,
  MeetingSpotsListComponent,
  MeetingSpotUpdatePanelComponent,
  MeetingSpotFormComponent,
  DepartmentsPageComponent,
  DepartmentsListComponent,
  DepartmentUpdatePanelComponent,
  AddDepartmentPageComponent,
  DepartmentFormComponent,
];

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    UniversitiesRoutingModule,

    /**
     * StoreModule.forFeature is used for composing state
     * from feature modules. These modules can be loaded
     * eagerly or lazily and will be dynamically added to
     * the existing state.
     */
    StoreModule.forFeature('universities', reducers),

    /**
     * Effects.forFeature is used to universities effects
     * from feature modules. Effects can be loaded
     * eagerly or lazily and will be started immediately.
     *
     * All Effects will only be instantiated once regardless of
     * whether they are registered once or multiple times.
     */
    EffectsModule.forFeature([
      UniversitiesEffects,
      DepartmentsEffects,
      MeetingSpotEffects
    ]),

    CoreModule,
    SharedModule
  ],
  declarations: COMPONENTS,
  exports: COMPONENTS,
  providers: [
    UniversityService,
    DepartmentService,
    MeetingSpotService,
    UniversityInStoreGuard,
    DepartmentInStoreGuard,
    MeetingSpotInStoreGuard,
  ]
})
export class UniversitiesModule {
}
