export interface Department {
  id?: number;
  name: string;
  description: string;
  universityId: number;
  isActive: boolean;
}
