import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { University } from '../../models/university';

@Component({
  selector: 'wml-university-form',
  templateUrl: './university-form.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UniversityFormComponent {
  @Input() universityId: string | null = null;

  @Input()
  set university(university: University | undefined) {
    if (university) {
      this.form.reset();
      this.form.patchValue(university);
    }
  }

  @Input()
  set pending(isPending: boolean) {
    this.isPending = isPending;

    if (isPending) {
      this.form.disable();
    } else {
      this.form.enable();
    }
  }

  @Input() error: string | null;

  @Output() submitted = new EventEmitter<University>();

  isPending: boolean;

  form: FormGroup = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', Validators.required),
    campusName: new FormControl('', Validators.required),
    isActive: new FormControl(true, Validators.required),
    city: new FormControl('', Validators.required),
    country: new FormControl('', Validators.required),
    startTime: new FormControl('', Validators.required),
    endTime: new FormControl('', Validators.required),
    timeZone: new FormControl('', Validators.required),
    emailDomain: new FormControl('', Validators.required),
  });

  constructor() {
  }

  submit() {
    if (this.form.valid) {
      this.submitted.emit(this.form.value);
    }
  }
}
