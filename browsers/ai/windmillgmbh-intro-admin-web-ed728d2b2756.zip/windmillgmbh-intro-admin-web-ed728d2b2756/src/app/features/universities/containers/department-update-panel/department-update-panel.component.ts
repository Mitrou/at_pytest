import { Component } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from '../../../../reducers';
import * as fromDepartments from '../../reducers/index';
import * as DepartmentsActions from '../../actions/department.actions';

import { map } from 'rxjs/operators';

import { Department } from '../../models/department';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';

@Component({
  selector: 'wml-department-update-panel',
  templateUrl: './department-update-panel.component.html'
})
export class DepartmentUpdatePanelComponent {
  universityId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.universityId)
  );
  departmentId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.departmentId)
  );
  department$ = this.store.pipe(select(fromDepartments.getSelectedDepartment));
  pending$ = this.store.pipe(select(fromDepartments.getDepartmentUpdatePanelPending));
  error$ = this.store.pipe(select(fromDepartments.getDepartmentUpdatePanelError));

  constructor(private store: Store<fromDepartments.State>) {
  }

  onSubmit($event: Department) {
    this.store.dispatch(new DepartmentsActions.UpdateDepartment($event));
  }
}
