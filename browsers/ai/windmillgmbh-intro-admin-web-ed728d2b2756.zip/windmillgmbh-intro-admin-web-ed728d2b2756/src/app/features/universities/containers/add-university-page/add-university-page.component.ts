import { Component } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromUniversities from '../../reducers/index';
import * as UniversitiesActions from '../../actions/university.actions';

import { University } from '../../models/university';

@Component({
  selector: 'wml-universities-page',
  templateUrl: './add-university-page.component.html'
})
export class AddUniversityPageComponent {
  pending$ = this.store.pipe(select(fromUniversities.getAddUniversityPagePending));
  error$ = this.store.pipe(select(fromUniversities.getAddUniversityPageError));

  constructor(private store: Store<fromUniversities.State>) {
  }

  onSubmit($event: University) {
    this.store.dispatch(new UniversitiesActions.AddUniversity($event));
  }
}
