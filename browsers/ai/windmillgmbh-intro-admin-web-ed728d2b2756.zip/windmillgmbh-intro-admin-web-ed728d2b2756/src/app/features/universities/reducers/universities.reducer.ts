import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';

import { UniversityActionsUnion, UniversityActionTypes } from '../actions/university.actions';

import { University } from '../models/university';

export interface State extends EntityState<University> {
  // additional entities state properties
  error: string | null;
  pending: boolean;
  count: number;
  offset: number;
  limit: number;
  selectedUniversityId: number | null;
}

export const universityEntityAdapter: EntityAdapter<University> = createEntityAdapter<University>({
  selectId: (university: University) => university.id,
  sortComparer: false,
});

export const initialState: State = universityEntityAdapter.getInitialState({
  // additional entity state properties
  error: null,
  pending: false,
  count: 0,
  offset: 0,
  limit: 10,
  selectedUniversityId: null,
});

export function reducer(state = initialState, action: UniversityActionsUnion): State {
  switch (action.type) {
    case UniversityActionTypes.LoadUniversities: {
      return {
        ...state,
        error: null,
        pending: true,
        offset: action.payload.pageInfo.offset,
        limit: action.payload.pageInfo.limit,
      };
    }

    case UniversityActionTypes.LoadUniversitiesSuccess: {
      return universityEntityAdapter.addAll(action.payload.data, {
        ...state,
        error: null,
        pending: false,
        count: action.payload.count
      });
    }

    case UniversityActionTypes.LoadUniversitiesFailure: {
      return {
        ...state,
        error: action.payload,
        pending: false,
        count: 0,
        offset: 0,
      };
    }

    case UniversityActionTypes.AddUniversitySuccess:
    case UniversityActionTypes.LoadUniversitySuccess: {
      return universityEntityAdapter.addOne(action.payload, state);
    }

    case UniversityActionTypes.UpdateUniversitySuccess: {
      return universityEntityAdapter.upsertOne(action.payload, state);
    }

    case UniversityActionTypes.SelectUniversity: {
      return {
        ...state,
        selectedUniversityId: action.payload,
      };
    }

    default: {
      return state;
    }
  }
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getCount = (state: State) => state.count;
export const getOffset = (state: State) => state.offset;
export const getLimit = (state: State) => state.limit;
export const getSelectedUniversityId = (state: State) => state.selectedUniversityId;
