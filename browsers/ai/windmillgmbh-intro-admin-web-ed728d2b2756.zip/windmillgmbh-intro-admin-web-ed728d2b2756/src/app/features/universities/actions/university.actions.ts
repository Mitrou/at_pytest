import { Action } from '@ngrx/store';

import { University } from '../models/university';
import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';

export enum UniversityActionTypes {
  LoadUniversities = '[Universities] Load Universities',
  LoadUniversitiesSuccess = '[Universities] Load Universities Success',
  LoadUniversitiesFailure = '[Universities] Load Universities Failure',
  AddUniversity = '[Universities] Add University',
  AddUniversitySuccess = '[Universities] Add University Success',
  AddUniversityFailure = '[Universities] Add University Failure',
  SelectUniversity = '[Universities] Select University',
  LoadUniversity = '[Universities] Load University',
  LoadUniversitySuccess = '[Universities] Load University Success',
  LoadUniversityFailure = '[Universities] Load University Failure',
  UpdateUniversity = '[Universities] Update University',
  UpdateUniversitySuccess = '[Universities] Update University Success',
  UpdateUniversityFailure = '[Universities] Update University Failure',
  NavigateToUpdateUniversityPage = '[Universities] Navigate To Update University Page',
}

export class LoadUniversities implements Action {
  readonly type = UniversityActionTypes.LoadUniversities;

  constructor(public payload: LoadListPayload = new LoadListPayload()) {
  }
}

export class LoadUniversitiesSuccess implements Action {
  readonly type = UniversityActionTypes.LoadUniversitiesSuccess;

  constructor(public payload: LoadListSuccessPayload<University>) {
  }
}

export class LoadUniversitiesFailure implements Action {
  readonly type = UniversityActionTypes.LoadUniversitiesFailure;

  constructor(public payload: string) {
  }
}

export class AddUniversity implements Action {
  readonly type = UniversityActionTypes.AddUniversity;

  constructor(public payload: University) {
  }
}

export class AddUniversitySuccess implements Action {
  readonly type = UniversityActionTypes.AddUniversitySuccess;

  constructor(public payload: University) {
  }
}

export class AddUniversityFailure implements Action {
  readonly type = UniversityActionTypes.AddUniversityFailure;

  constructor(public payload: string) {
  }
}

export class SelectUniversity implements Action {
  readonly type = UniversityActionTypes.SelectUniversity;

  constructor(public payload: number) {
  }
}

export class LoadUniversity implements Action {
  readonly type = UniversityActionTypes.LoadUniversity;
}

export class LoadUniversitySuccess implements Action {
  readonly type = UniversityActionTypes.LoadUniversitySuccess;

  constructor(public payload: University) {
  }
}

export class LoadUniversityFailure implements Action {
  readonly type = UniversityActionTypes.LoadUniversityFailure;

  constructor(public payload: string) {
  }
}

export class UpdateUniversity implements Action {
  readonly type = UniversityActionTypes.UpdateUniversity;

  constructor(public payload: University) {
  }
}

export class UpdateUniversitySuccess implements Action {
  readonly type = UniversityActionTypes.UpdateUniversitySuccess;

  constructor(public payload: University) {
  }
}

export class UpdateUniversityFailure implements Action {
  readonly type = UniversityActionTypes.UpdateUniversityFailure;

  constructor(public payload: string) {
  }
}

export class NavigateToUpdateUniversityPage implements Action {
  readonly type = UniversityActionTypes.NavigateToUpdateUniversityPage;

  constructor(public payload: number) {
  }
}

export type UniversityActionsUnion =
  | LoadUniversities
  | LoadUniversitiesSuccess
  | LoadUniversitiesFailure
  | AddUniversity
  | AddUniversitySuccess
  | AddUniversityFailure
  | SelectUniversity
  | LoadUniversity
  | LoadUniversitySuccess
  | LoadUniversityFailure
  | UpdateUniversity
  | UpdateUniversitySuccess
  | UpdateUniversityFailure
  | NavigateToUpdateUniversityPage
  ;
