export interface MeetingSpot {
  id?: number;
  spot: string;
  description: string;
  universityId: number;
  campus: string;
  isActive: boolean;
}
