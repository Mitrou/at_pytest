import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseService } from '@shared/services/base.service';

import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';
import { MeetingSpot } from '../models/meeting-spot';

@Injectable({
  providedIn: 'root',
})
export class MeetingSpotService extends BaseService {
  loadMeetingSpots({pageInfo, sortInfo, filters}: LoadListPayload): Observable<LoadListSuccessPayload<MeetingSpot>> {
    return this.http.get<MeetingSpot[]>(`/api/meeting-spot`, {
      observe: 'response',
      params: {
        _page: (pageInfo.offset + 1).toString(),
        _limit: pageInfo.limit.toString(),
        _sort: sortInfo.prop,
        _order: sortInfo.dir,
        ...this.serializeFilter(filters)
      }
    }).pipe(
      map((response) => ({
          count: Number(response.headers.get('X-Total-Count')),
          data: response.body
        })
      )
    );
  }

  loadMeetingSpot(id: number): Observable<MeetingSpot> {
    return this.http.get<MeetingSpot>('/api/meeting-spot/' + String(id));
  }

  addMeetingSpot(payload: MeetingSpot): Observable<MeetingSpot> {
    return this.http.post<MeetingSpot>('/api/meeting-spot', payload);
  }

  updateMeetingSpot(payload: MeetingSpot): Observable<MeetingSpot> {
    return this.http.put<MeetingSpot>('/api/meeting-spot/' + String(payload.id), payload);
  }
}
