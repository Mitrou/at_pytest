import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseService } from '@shared/services/base.service';

import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';
import { Department } from '../models/department';
import { GetTogether } from '../../get-together/models/get-together';

@Injectable({
  providedIn: 'root',
})
export class DepartmentService extends BaseService {
  loadDepartments({pageInfo, sortInfo, filters}: LoadListPayload): Observable<LoadListSuccessPayload<Department>> {
    return this.gridRequest<Department>(`/api/department`,
      pageInfo.offset + 1, pageInfo.limit,
      sortInfo.prop, sortInfo.dir,
      filters
    );
  }

  loadDepartment(id: number): Observable<Department> {
    return this.http.get<Department>('/api/department/' + String(id));
  }

  addDepartment(payload: Department): Observable<Department> {
    return this.http.post<Department>('/api/department', payload);
  }

  updateDepartment(payload: Department): Observable<Department> {
    return this.http.put<Department>('/api/department/' + String(payload.id), payload);
  }
}
