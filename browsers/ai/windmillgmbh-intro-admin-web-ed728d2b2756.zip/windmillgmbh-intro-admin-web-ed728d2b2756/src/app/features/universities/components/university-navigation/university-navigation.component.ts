import { Component, ChangeDetectionStrategy, Input } from '@angular/core';

@Component({
  selector: 'wml-university-navigation',
  templateUrl: './university-navigation.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UniversityNavigationComponent {
  @Input() universityId: string;
}
