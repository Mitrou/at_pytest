import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromRoot from '../../../../reducers/index';
import * as fromDepartments from '../../reducers/index';
import * as DepartmentsActions from '../../actions/department.actions';

import { map } from 'rxjs/operators';

import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';
import { LoadListPayload } from '@shared/models/list';
import { Department } from '../../models/department';


@Component({
  selector: 'wml-departments-page',
  templateUrl: './departments-page.component.html'
})
export class DepartmentsPageComponent {
  universityId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.universityId)
  );
  drawerOpened$ = this.store.pipe(select(fromRoot.getDrawerOpened));
  departments$ = this.store.pipe(select(fromDepartments.getAllDepartments));
  pending$ = this.store.pipe(select(fromDepartments.getDepartmentsPending));
  error$ = this.store.pipe(select(fromDepartments.getDepartmentsError));
  count$ = this.store.pipe(select(fromDepartments.getDepartmentsCount));
  offset$ = this.store.pipe(select(fromDepartments.getDepartmentsOffset));
  limit$ = this.store.pipe(select(fromDepartments.getDepartmentsLimit));

  constructor(private store: Store<fromDepartments.State>) {
  }

  onReloadGrid($event: LoadListPayload) {
    this.store.dispatch(new DepartmentsActions.LoadDepartments($event));
  }

  onItemSelected($event) {

  }

  onItemEdit($event: Department) {
    this.store.dispatch(new DepartmentsActions.NavigateToUpdateDepartmentPage($event.id));
  }

  onItemDelete($event) {
  }
}
