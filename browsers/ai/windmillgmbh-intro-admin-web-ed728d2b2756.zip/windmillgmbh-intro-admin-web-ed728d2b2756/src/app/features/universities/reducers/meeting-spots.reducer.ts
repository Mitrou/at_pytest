import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';

import { MeetingSpotsActionsUnion, MeetingSpotActionTypes } from '../actions/meeting-spots.actions';

import { MeetingSpot } from '../models/meeting-spot';

export interface State extends EntityState<MeetingSpot> {
  // additional entities state properties
  error: string | null;
  pending: boolean;
  count: number;
  offset: number;
  limit: number;
  selectedSpotId: number | null;
}

export const meetingSpotEntityAdapter: EntityAdapter<MeetingSpot> =
  createEntityAdapter<MeetingSpot>( {
    selectId: (spot: MeetingSpot) => spot.id,
    sortComparer: false
});

export const initialState: State = meetingSpotEntityAdapter.getInitialState({
  // additional entity state properties
  error: null,
  pending: false,
  count: 0,
  offset: 0,
  limit: 10,
  selectedSpotId: null,
});

export function reducer(state = initialState, action: MeetingSpotsActionsUnion): State {
  switch (action.type) {
    case MeetingSpotActionTypes.LoadMeetingSpots: {
      return {
        ...state,
        error: null,
        pending: true,
        offset: action.payload.pageInfo.offset,
        limit: action.payload.pageInfo.limit,
      };
    }

    case MeetingSpotActionTypes.LoadMeetingSpotsSuccess: {
      return meetingSpotEntityAdapter.addAll(action.payload.data, {
        ...state,
        error: null,
        pending: false,
        count: action.payload.count
      });
    }

    case MeetingSpotActionTypes.LoadMeetingSpotsFailure: {
      return {
        ...state,
        error: action.payload,
        pending: false,
        count: 0,
        offset: 0,
      };
    }

    case MeetingSpotActionTypes.AddMeetingSpotSuccess:
    case MeetingSpotActionTypes.LoadMeetingSpotSuccess: {
      return meetingSpotEntityAdapter.addOne(action.payload, state);
    }

    case MeetingSpotActionTypes.UpdateMeetingSpotSuccess: {
      return meetingSpotEntityAdapter.upsertOne(action.payload, state);
    }

    case MeetingSpotActionTypes.SelectMeetingSpot: {
      return {
        ...state,
        selectedSpotId: action.payload,
      };
    }

    default: {
      return state;
    }
  }
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getCount = (state: State) => state.count;
export const getOffset = (state: State) => state.offset;
export const getLimit = (state: State) => state.limit;
export const getSelectedMeetingSpotId = (state: State) => state.selectedSpotId;
