import { Component } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromRoot from '../../../../reducers';
import * as fromUniversities from '../../reducers/index';
import * as MeetingSpotActions from '../../actions/meeting-spots.actions';

import { map } from 'rxjs/operators';

import { MeetingSpot } from '../../models/meeting-spot';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';

@Component({
  selector: 'wml-meeting-spot-update-panel',
  templateUrl: './meeting-spot-update-panel.component.html'
})
export class MeetingSpotUpdatePanelComponent {
  universityId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.universityId)
  );
  meetingSpotId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.meetingSpotId)
  );
  meetingSpot$ = this.store.pipe(select(fromUniversities.getSelectedMeetingSpot));
  pending$ = this.store.pipe(select(fromUniversities.getMeetingSpotUpdatePanelPending));
  error$ = this.store.pipe(select(fromUniversities.getMeetingSpotUpdatePanelError));

  constructor(private store: Store<fromUniversities.State>) {
  }

  onSubmit($event: MeetingSpot) {
    this.store.dispatch(new MeetingSpotActions.UpdateMeetingSpot($event));
  }
}
