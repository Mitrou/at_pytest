import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select, Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';

import * as fromUniversities from '../reducers';

import { Observable, of } from 'rxjs';
import { map, exhaustMap, switchMap, withLatestFrom, catchError, tap } from 'rxjs/operators';

import {
  UniversityActionTypes,
  LoadUniversities,
  LoadUniversitiesSuccess,
  LoadUniversitiesFailure,
  AddUniversity,
  AddUniversitySuccess,
  AddUniversityFailure,
  LoadUniversity,
  LoadUniversitySuccess,
  LoadUniversityFailure,
  UpdateUniversity,
  UpdateUniversitySuccess,
  UpdateUniversityFailure,
  NavigateToUpdateUniversityPage
} from '../actions/university.actions';

import { UniversityService } from '../services/university.service';

import { University } from '../models/university';
import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';

@Injectable()
export class UniversitiesEffects {
  @Effect()
  loadUniversities$: Observable<Action> = this.actions$.pipe(
    ofType<LoadUniversities>(UniversityActionTypes.LoadUniversities),
    map((action) => action.payload),
    switchMap((params: LoadListPayload) =>
      this.universityService.loadUniversities(params)
        .pipe(
          map((payload: LoadListSuccessPayload<University>) => new LoadUniversitiesSuccess(payload)),
          catchError((e) => of(new LoadUniversitiesFailure(e.error.error)))
        )
    )
  );

  @Effect()
  addUniversity$: Observable<Action> = this.actions$.pipe(
    ofType<AddUniversity>(UniversityActionTypes.AddUniversity),
    map((action) => action.payload),
    exhaustMap((university: University) =>
      this.universityService.addUniversity(university)
        .pipe(
          map((payload: University) => new AddUniversitySuccess(payload)),
          catchError((e) => of(new AddUniversityFailure(e.error.error)))
        )
    )
  );

  @Effect()
  loadUniversity$: Observable<Action> = this.actions$.pipe(
    ofType<LoadUniversity>(UniversityActionTypes.LoadUniversity),
    withLatestFrom(
      this.store.pipe(select(fromUniversities.getSelectedUniversityId)),
      (action, id: number) => id
    ),
    switchMap((id) =>
      this.universityService.loadUniversity(id)
        .pipe(
          map((payload: University) => new LoadUniversitySuccess(payload)),
          catchError((e) => of(new LoadUniversityFailure(e.error.error)))
        )
    )
  );

  @Effect({dispatch: false})
  loadUniversityFailure$: Observable<any> = this.actions$.pipe(
    ofType<LoadUniversityFailure>(UniversityActionTypes.LoadUniversityFailure),
    tap(() => {
      this.router.navigate(['/404']);
    })
  );

  @Effect()
  updateUniversity$: Observable<Action> = this.actions$.pipe(
    ofType<UpdateUniversity>(UniversityActionTypes.UpdateUniversity),
    map((action) => action.payload),
    exhaustMap((university: University) =>
      this.universityService.updateUniversity(university)
        .pipe(
          map((payload: University) => new UpdateUniversitySuccess(payload)),
          catchError((e) => of(new UpdateUniversityFailure(e.error.error)))
        )
    )
  );

  @Effect({dispatch: false})
  navigateToUniversitiesPage$: Observable<any> = this.actions$.pipe(
    ofType(
      UniversityActionTypes.AddUniversitySuccess,
      UniversityActionTypes.UpdateUniversitySuccess
    ),
    tap(() => {
      this.router.navigate(['/universities']);
    })
  );

  @Effect({dispatch: false})
  navigateToUpdateUniversityPage$: Observable<any> = this.actions$.pipe(
    ofType<NavigateToUpdateUniversityPage>(UniversityActionTypes.NavigateToUpdateUniversityPage),
    map((action) => action.payload),
    tap((universityId: number) => {
      this.router.navigate(['/universities', universityId, 'update']);
    })
  );

  constructor(
    private actions$: Actions,
    private router: Router,
    private store: Store<fromUniversities.State>,
    private universityService: UniversityService,
  ) {
  }
}
