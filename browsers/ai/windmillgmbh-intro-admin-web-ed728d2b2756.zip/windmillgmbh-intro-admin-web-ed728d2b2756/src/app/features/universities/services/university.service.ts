import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { BaseService } from '@shared/services/base.service';

import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';
import { University } from '../models/university';


@Injectable({
  providedIn: 'root'
})
export class UniversityService extends BaseService {
  loadUniversities({ pageInfo, sortInfo, filters }: LoadListPayload): Observable<LoadListSuccessPayload<University>> {
    return this.gridRequest<University>(`/api/university`,
      pageInfo.offset + 1, pageInfo.limit,
      sortInfo.prop, sortInfo.dir,
      filters
    );
  }

  loadUniversity(id: number): Observable<University> {
    return this.http.get<University>('/api/university/' + String(id));
  }

  addUniversity(payload: University): Observable<University> {
    return this.http.post<University>('/api/university', payload);
  }

  updateUniversity(payload: University): Observable<University> {
    return this.http.put<University>('/api/university/' + String(payload.id), payload);
  }
}
