import { GetTogether } from '../models/get-together';
import { GetTogetherActionsUnion , GetTogetherActionTypes } from '../actions/get-together.actions';
import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';


export interface State extends EntityState<GetTogether> {
  // additional entities state properties
  error: string | null;
  pending: boolean;
  count: number;
  offset: number;
  limit: number;
  selectedGetTogetherId: number | null;
}

export const getTogetherEntityAdapter: EntityAdapter<GetTogether> = createEntityAdapter<GetTogether>({
  selectId: (getTogether: GetTogether) => getTogether.id,
  sortComparer: false,
});

export const initialState: State = getTogetherEntityAdapter.getInitialState({
  // additional entity state properties
  error: null,
  pending: false,
  count: 0,
  offset: 0,
  limit: 10,
  selectedGetTogetherId: null,
});

export function reducer(state = initialState, action: GetTogetherActionsUnion): State {
  switch (action.type) {
    case GetTogetherActionTypes.LoadGetTogethers: {
      return {
        ...state,
        error: null,
        pending: true,
        offset: action.payload.pageInfo.offset,
        limit: action.payload.pageInfo.limit,
      };
    }

    case GetTogetherActionTypes.LoadGetTogethersFailure: {
      return {
        ...state,
        error: action.payload,
        pending: false,
        count: 0,
        offset: 0,
      };
    }

    case GetTogetherActionTypes.LoadGetTogethersSuccess: {
      return getTogetherEntityAdapter.addAll(action.payload.data, {
        ...state,
        error: null,
        pending: false,
        count: action.payload.count
      });
    }

    case GetTogetherActionTypes.AddGetTogetherSuccess:
    case GetTogetherActionTypes.LoadGetTogetherSuccess: {
      return getTogetherEntityAdapter.addOne(action.payload, state);
    }

    case GetTogetherActionTypes.UpdateGetTogetherSuccess: {
      return getTogetherEntityAdapter.upsertOne(action.payload, state);
    }

    case GetTogetherActionTypes.SelectGetTogether: {
      return {
        ...state,
        selectedGetTogetherId: action.payload,
      };
    }
    default: {
      return state;
    }
  }
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getCount = (state: State) => state.count;
export const getOffset = (state: State) => state.offset;
export const getLimit = (state: State) => state.limit;
export const getSelectedGetTogetherId = (state: State) => state.selectedGetTogetherId;
