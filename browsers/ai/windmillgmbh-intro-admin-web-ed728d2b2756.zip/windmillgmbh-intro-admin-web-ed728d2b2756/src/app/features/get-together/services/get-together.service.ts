import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseService } from '@shared/services/base.service';

import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';
import { GetTogether } from '../models/get-together';
import { Holiday } from '../../holidays/models/holiday.model';

@Injectable({
  providedIn: 'root',
})
export class GetTogetherService extends BaseService {
  loadGetTogethers({pageInfo, sortInfo, filters}: LoadListPayload): Observable<LoadListSuccessPayload<GetTogether>> {
    return this.gridRequest<GetTogether>(`/api/get-togethers`,
      pageInfo.offset + 1, pageInfo.limit,
      sortInfo.prop, sortInfo.dir,
      filters
    );
  }

  loadGetTogether(id: number): Observable<GetTogether> {
    return this.http.get<GetTogether>('/api/get-togethers/' + String(id));
  }

  addGetTogether(payload: GetTogether): Observable<GetTogether> {
    return this.http.post<GetTogether>('/api/university', payload);
  }

  updateUniversity(payload: GetTogether): Observable<GetTogether> {
    return this.http.put<GetTogether>('/api/university/' + String(payload.id), payload);
  }
}
