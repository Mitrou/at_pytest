import { Action } from '@ngrx/store';

import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';
import { GetTogether } from '../models/get-together';

export enum GetTogetherActionTypes {
  LoadGetTogethers = '[GetTogethers] Load GetTogethers',
  LoadGetTogethersSuccess = '[GetTogethers] Load GetTogethers Success',
  LoadGetTogethersFailure = '[GetTogethers] Load GetTogethers Failure',
  AddGetTogether = '[GetTogethers] Add GetTogether',
  AddGetTogetherSuccess = '[GetTogethers] Add GetTogether Success',
  AddGetTogetherFailure = '[GetTogethers] Add GetTogether Failure',
  SelectGetTogether = '[GetTogethers] Select GetTogether',
  LoadGetTogether = '[GetTogethers] Load GetTogether',
  LoadGetTogetherSuccess = '[GetTogethers] Load GetTogether Success',
  LoadGetTogetherFailure = '[GetTogethers] Load GetTogether Failure',
  UpdateGetTogether = '[GetTogethers] Update GetTogether',
  UpdateGetTogetherSuccess = '[GetTogethers] Update GetTogether Success',
  UpdateGetTogetherFailure = '[GetTogethers] Update GetTogether Failure',
  NavigateToUpdateGetTogetherPage = '[GetTogethers] Navigate To Update GetTogether Page',
}

export class LoadGetTogethers implements Action {
  readonly type = GetTogetherActionTypes.LoadGetTogethers;

  constructor(public payload: LoadListPayload = new LoadListPayload()) {
  }
}

export class LoadGetTogethersSuccess implements Action {
  readonly type = GetTogetherActionTypes.LoadGetTogethersSuccess;

  constructor(public payload: LoadListSuccessPayload<GetTogether>) {
  }
}
export class LoadGetTogethersFailure implements Action {
  readonly type = GetTogetherActionTypes.LoadGetTogethersFailure;

  constructor(public payload: string) {
  }
}

export class AddGetTogether implements Action {
  readonly type = GetTogetherActionTypes.AddGetTogether;

  constructor(public payload: GetTogether) {
  }
}

export class AddGetTogetherSuccess implements Action {
  readonly type = GetTogetherActionTypes.AddGetTogetherSuccess;

  constructor(public payload: GetTogether) {
  }
}

export class AddGetTogetherFailure implements Action {
  readonly type = GetTogetherActionTypes.AddGetTogetherFailure;

  constructor(public payload: string) {
  }
}

export class SelectGetTogether implements Action {
  readonly type = GetTogetherActionTypes.SelectGetTogether;

  constructor(public payload: number) {
  }
}

export class LoadGetTogether implements Action {
  readonly type = GetTogetherActionTypes.LoadGetTogether;
}

export class LoadGetTogetherSuccess implements Action {
  readonly type = GetTogetherActionTypes.LoadGetTogetherSuccess;

  constructor(public payload: GetTogether) {
  }
}

export class LoadGetTogetherFailure implements Action {
  readonly type = GetTogetherActionTypes.LoadGetTogetherFailure;

  constructor(public payload: string) {
  }
}

export class UpdateGetTogether implements Action {
  readonly type = GetTogetherActionTypes.UpdateGetTogether;

  constructor(public payload: GetTogether) {
  }
}

export class UpdateGetTogetherSuccess implements Action {
  readonly type = GetTogetherActionTypes.UpdateGetTogetherSuccess;

  constructor(public payload: GetTogether) {
  }
}

export class UpdateGetTogetherFailure implements Action {
  readonly type = GetTogetherActionTypes.UpdateGetTogetherFailure;

  constructor(public payload: string) {
  }
}

export class NavigateToUpdateGetTogetherPage implements Action {
  readonly type = GetTogetherActionTypes.NavigateToUpdateGetTogetherPage;

  constructor(public payload: number) {
  }
}

export type GetTogetherActionsUnion =
  | LoadGetTogethers
  | LoadGetTogethersSuccess
  | LoadGetTogethersFailure
  | AddGetTogether
  | AddGetTogetherSuccess
  | AddGetTogetherFailure
  | SelectGetTogether
  | LoadGetTogether
  | LoadGetTogetherSuccess
  | LoadGetTogetherFailure
  | UpdateGetTogether
  | UpdateGetTogetherSuccess
  | UpdateGetTogetherFailure
  | NavigateToUpdateGetTogetherPage
  ;
