import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select, Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';

import * as fromGetTogethers from '../reducers';

import { Observable, of } from 'rxjs';
import { map, exhaustMap, switchMap, withLatestFrom, catchError, tap } from 'rxjs/operators';

import {
  GetTogetherActionTypes,
  LoadGetTogethers,
  LoadGetTogethersSuccess,
  LoadGetTogethersFailure,
} from '../actions/get-together.actions';

import { GetTogetherService } from '../services/get-together.service';

import { GetTogether } from '../models/get-together';
import { LoadListPayload, LoadListSuccessPayload } from '@shared/models/list';

@Injectable()
export class GetTogethersEffects {
  @Effect()
  loadGetTogethers$: Observable<Action> = this.actions$.pipe(
    ofType<LoadGetTogethers>(GetTogetherActionTypes.LoadGetTogethers),
    map((action) => action.payload),
    switchMap((params: LoadListPayload) =>
      this.getTogetherService.loadGetTogethers(params)
        .pipe(
          map((payload: LoadListSuccessPayload<GetTogether>) => new LoadGetTogethersSuccess(payload)),
          catchError((e) => of(new LoadGetTogethersFailure(e.error.error)))
        )
    )
  );

  constructor(
    private actions$: Actions,
    private router: Router,
    private store: Store<fromGetTogethers.State>,
    private getTogetherService: GetTogetherService,
  ) {
  }
}
