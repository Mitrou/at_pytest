import { Component, ChangeDetectionStrategy, Input, Output, EventEmitter } from '@angular/core';

import { LoadListPayload } from '@shared/models/list';
import { GetTogether } from '../../models/get-together';
import { ColumnFilterType, ColumnType, GridAction, GridOptions } from '@shared/components/grid/grid.configs';

@Component({
  selector: 'wml-get-togethers-list',
  templateUrl: './get-togethers-list.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})

export class GetTogethersListComponent {
  @Input() getTogethers: GetTogether[];
  @Input() pending: boolean;
  @Input() error: string | null;
  @Input() count: number;
  @Input() offset: number;
  @Input() limit: number;

  @Input() drawerOpened = false;

  @Output() reloadGrid = new EventEmitter<LoadListPayload>();
  @Output() selectItem = new EventEmitter<any>();
  @Output() editItem = new EventEmitter<any>();
  @Output() deleteItem = new EventEmitter<any>();

  options: GridOptions = {
    actions: [GridAction.Edit, GridAction.Delete],
    columns: [
      {
        name: 'Id',
        prop: 'id',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        name: 'Date',
        prop: 'meetingDate',
        columnType: ColumnType.Date,
        filterable: false
      },
      {
        name: 'Time',
        prop: 'meetingStartTime',
        columnType: ColumnType.Text,
        filterable: false
      },
      {
        prop: 'status',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Select,
        filterProp: 'status',
        filterData: [
          { status: 'COMPLETED', title: 'Completed' },
          { status: 'PENDING', title: 'Pending' },
          { status: 'FEEDBACK', title: 'Feedback' },
          { status: 'DECLINED', title: 'Declined' }
        ]
      },
      {
        name: 'Location',
        prop: 'location',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        name: 'Interests',
        prop: 'interests',
        columnType: ColumnType.Text
      },
      {
        name: 'Avg Rating',
        prop: 'averageRating',
        columnType: ColumnType.Text,
        filterable: true,
        filterType: ColumnFilterType.Text
      },
    ]
  };
}
