import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OpenDrawerGuard } from '../../core/services/open-drawer-guard.service';
import { CloseDrawerGuard } from '../../core/services/close-drawer-guard.service';

import { GetTogethersPageComponent } from './containers/get-togethers-page/get-togethers-page.component';


export const routes: Routes = [
  {path: '', component: GetTogethersPageComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GetTogethersRoutingModule {
}
