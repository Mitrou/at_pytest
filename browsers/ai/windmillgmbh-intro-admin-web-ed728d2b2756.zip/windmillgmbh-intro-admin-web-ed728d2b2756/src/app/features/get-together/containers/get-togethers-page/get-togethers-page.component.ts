import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromGetTogethers from '../../reducers/index';
import * as GetTogethersActions from '../../actions/get-together.actions';

import { LoadListPayload } from '@shared/models/list';
import { GetTogether } from '../../models/get-together';
import * as fromRoot from '../../../../reducers';

@Component({
  selector: 'wml-get-togethers-page',
  templateUrl: './get-togethers-page.component.html'
})
export class GetTogethersPageComponent implements OnInit {
  getTogethers$ = this.store.pipe(select(fromGetTogethers.getAllGetTogethers));
  pending$ = this.store.pipe(
    select(fromGetTogethers.getfromGetTogethersPending)
  );
  drawerOpened$ = this.store.pipe(select(fromRoot.getDrawerOpened));
  error$ = this.store.pipe(select(fromGetTogethers.getGetTogethersError));
  count$ = this.store.pipe(select(fromGetTogethers.getfromGetTogethersCount));
  offset$ = this.store.pipe(select(fromGetTogethers.getfromGetTogethersOffset));
  limit$ = this.store.pipe(select(fromGetTogethers.getfromGetTogethersLimit));

  constructor(private store: Store<fromGetTogethers.State>) {
    this.getTogethers$ = this.store.pipe(
      select(fromGetTogethers.getAllGetTogethers)
    );
  }

  ngOnInit() {
  }

  onReloadGrid($event: LoadListPayload) {
    this.store.dispatch(new GetTogethersActions.LoadGetTogethers($event));
  }

  onItemSelected($event) {}

  onItemEdit($event: GetTogether) {
    console.log('Actiosn called');
  }

  onItemDelete($event) {}
}
