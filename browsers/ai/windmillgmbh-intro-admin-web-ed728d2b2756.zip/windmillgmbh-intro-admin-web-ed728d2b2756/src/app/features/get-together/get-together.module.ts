import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { CoreModule } from '../../core/core.module';
import { SharedModule } from '@shared/shared.module';

import { reducers } from './reducers';
import { GetTogethersPageComponent } from './containers/get-togethers-page/get-togethers-page.component';
import { GetTogethersListComponent } from './components/get-togethers-list/get-togethers-list.component';
import { GetTogethersRoutingModule } from './get-together-routing.module';
import { GetTogethersEffects } from './effects/get-togethers.effects';


export const COMPONENTS = [
  GetTogethersPageComponent,
  GetTogethersListComponent
];

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    GetTogethersRoutingModule,

    /**
     * StoreModule.forFeature is used for composing state
     * from feature modules. These modules can be loaded
     * eagerly or lazily and will be dynamically added to
     * the existing state.
     */
    StoreModule.forFeature('getTogethers', reducers),

    /**
     * Effects.forFeature is used to universities effects
     * from feature modules. Effects can be loaded
     * eagerly or lazily and will be started immediately.
     *
     * All Effects will only be instantiated once regardless of
     * whether they are registered once or multiple times.
     */

    EffectsModule.forFeature([GetTogethersEffects]),

    CoreModule,
    SharedModule
  ],
  declarations: COMPONENTS,
  exports: COMPONENTS,
})
export class GetTogethersModule {
}
