export interface GetTogether {
  id?: number;
  meetingDate: string;
  meetingStartTime: string;
  meetingEndTime: string;
  acceptedParticipents: number;
  totalParticipents: number;
  status: string;
  location: string;
  interests: number;
  averageRating: number;
}
