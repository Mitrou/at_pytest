import {
  createSelector,
  createFeatureSelector,
  ActionReducerMap,
} from '@ngrx/store';

import * as fromRoot from '../../../reducers';
import * as fromGetTogethers from './get-together.reducer';

export interface GetTogethersState {
  getTogethers: fromGetTogethers.State;
}

export interface State extends fromRoot.State {
  getTogethers: GetTogethersState;
}

export const reducers: ActionReducerMap<GetTogethersState> = {
  getTogethers: fromGetTogethers.reducer,
};

export const getGetTogethersState = createFeatureSelector<State, GetTogethersState>('getTogethers');

export const getGetTogethersEntitiesState = createSelector(
  getGetTogethersState,
  state => state.getTogethers
);

export const getSelectedGetTogethersId = createSelector(
  getGetTogethersEntitiesState,
  fromGetTogethers.getSelectedGetTogetherId
);

export const getGetTogethersError = createSelector(
  getGetTogethersEntitiesState,
  fromGetTogethers.getError
);

export const getfromGetTogethersPending = createSelector(
  getGetTogethersEntitiesState,
  fromGetTogethers.getPending
);

export const getfromGetTogethersCount = createSelector(
  getGetTogethersEntitiesState,
  fromGetTogethers.getCount
);

export const getfromGetTogethersOffset = createSelector(
  getGetTogethersEntitiesState,
  fromGetTogethers.getOffset
);

export const getfromGetTogethersLimit = createSelector(
  getGetTogethersEntitiesState,
  fromGetTogethers.getLimit
);

export const {
  selectEntities: getGetTogethersEntities,
  selectAll: getAllGetTogethers,
} = fromGetTogethers.getTogetherEntityAdapter.getSelectors(getGetTogethersEntitiesState);

export const getSelectedGetTogether = createSelector(
  getGetTogethersEntities,
  getSelectedGetTogethersId,
  (entities, selectedId) => {
    return selectedId !== null && entities[selectedId];
  }
);
