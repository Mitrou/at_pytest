export interface LoginPayload {
  username: string;
  password: string;
}

export interface LoginSuccessPayload {
  idToken: string;
}

export interface ResetPasswordInitPayload {
  mail: string;
}

export interface ResetPasswordFinishPayload {
  key: string;
  newPassword: string;
}
