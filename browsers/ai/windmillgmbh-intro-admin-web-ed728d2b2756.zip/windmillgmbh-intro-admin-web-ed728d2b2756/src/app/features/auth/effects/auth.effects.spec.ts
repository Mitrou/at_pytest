import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { Actions } from '@ngrx/effects';
import { provideMockActions } from '@ngrx/effects/testing';
import { cold, hot } from 'jasmine-marbles';
import { Observable, of } from 'rxjs';
import { LocalStorageService } from 'ngx-webstorage';

import {
  Login,
  InitialLogin,
  LoginFailure,
  LoginRedirect,
  LoginSuccess,
  ResetPasswordInit,
  ResetPasswordInitSuccess,
  ResetPasswordInitFailure,
  ResetPasswordFinish,
  ResetPasswordFinishSuccess,
  ResetPasswordFinishFailure,
  Logout,
  GetCurrentUserInit,
  GetCurrentUserSuccess,
  GetCurrentUserFailure
} from '../actions/auth.actions';

import { AuthEffects } from './auth.effects';
import { AuthService } from '../services/auth.service';

import {
  user,
  loginPayload,
  loginSuccessPayload,
  initialLoginPayload,
  resetPasswordInitPayload,
  resetPasswordFinishPayload
} from '@shared/mocks';

describe('AuthEffects', () => {
  let effects: AuthEffects;
  let authService: any;
  let actions$: Observable<any>;
  let routerService: any;
  let localStorageService: any;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthEffects,
        provideMockActions(() => actions$),
        {
          provide: Router,
          useValue: {
            navigate: jest.fn()
          }
        },
        {
          provide: AuthService,
          useValue: {
            login: jest.fn(),
            resetPasswordInit: jest.fn(),
            resetPasswordFinish: jest.fn(),
            getCurrentUser: jest.fn()
          }
        },
        {
          provide: LocalStorageService,
          useValue: {
            store: jest.fn(),
            clear: jest.fn(),
            retrieve: jest.fn()
          }
        }
      ]
    });

    effects = TestBed.get(AuthEffects);
    authService = TestBed.get(AuthService);
    actions$ = TestBed.get(Actions);
    routerService = TestBed.get(Router);
    localStorageService = TestBed.get(LocalStorageService);

    spyOn(routerService, 'navigate').and.callThrough();
  });

  describe('login$', () => {
    it(
      'should call localStorageService.store and should return ' +
        'login.LoginSuccess and login.GetCurrentUserInit actions if authService.login succeeds',
      () => {
        const action = new Login(loginPayload);
        const completionB = new LoginSuccess(loginSuccessPayload);
        const completionC = new GetCurrentUserInit();

        actions$ = hot('-a---', { a: action });
        const responseB = cold('-a|', { a: loginSuccessPayload });
        const expected = cold('--(bc)', { b: completionB, c: completionC });

        authService.login.mockReturnValue(responseB);

        expect(effects.login$).toBeObservable(expected);
      }
    );

    it('should return a new auth.GetCurrentUserSuccess if there was auth.GetCurrentUserInit', () => {
      const action = new GetCurrentUserInit();
      const completion = new GetCurrentUserSuccess(user);

      actions$ = hot('-a---', { a: action });
      const response = cold('-a|', { a: user });
      const expected = cold('--b', { b: completion });
      authService.getCurrentUser.mockReturnValue(response);

      expect(effects.getCurrentUser$).toBeObservable(expected);
    });

    it('should save user from GetCurrentUserSuccess action payload to local storage', () => {
      const action = new GetCurrentUserSuccess(user);

      actions$ = of(action);
      effects.getCurrentUserSuccess$.subscribe();

      expect(localStorageService.store).toHaveBeenCalledWith(
        'currentUser',
        user
      );
    });

    it('should return a new auth.LoginFailure if the login service throws', () => {
      const error = { error: { error: 'Invalid email or password' } };
      const action = new Login(loginPayload);
      const completion = new LoginFailure(error.error.error);

      actions$ = hot('-a---', { a: action });
      const response = cold('-#', {}, error);
      const expected = cold('--b', { b: completion });
      authService.login.mockReturnValue(response);

      expect(effects.login$).toBeObservable(expected);
    });

    it('should return a new auth.GetCurrentUserFailure if there was auth.LoginFailure', () => {
      const error = { error: { error: 'Invalid email or password' } };
      const action = new LoginFailure(error.error.error);
      const completion = new GetCurrentUserFailure(error.error.error);

      actions$ = hot('-a---', { a: action });
      const response = cold('-#', {}, error);
      const expected = cold('-b', { b: completion });
      authService.getCurrentUser.mockReturnValue(response);

      expect(effects.loginFailure$).toBeObservable(expected);
    });
  });

  describe('loginSuccess$', () => {
    it('should persist idToken dispatch a RouterNavigation action', () => {
      const action = new LoginSuccess(loginSuccessPayload);

      actions$ = of(action);
      effects.loginSuccess$.subscribe();

      expect(localStorageService.store).toHaveBeenCalledWith(
        'idToken',
        loginSuccessPayload.idToken
      );
      expect(routerService.navigate).toHaveBeenCalledWith(['/']);
    });
  });

  describe('loginRedirect$', () => {
    it('should dispatch a RouterNavigation action when auth.LoginRedirect is dispatched', () => {
      const action = new LoginRedirect();

      actions$ = of(action);
      effects.loginRedirect$.subscribe();

      expect(localStorageService.clear).toHaveBeenCalledWith('idToken');
      expect(routerService.navigate).toHaveBeenCalledWith(['/login']);
    });

    it('should dispatch a RouterNavigation action when auth.Logout is dispatched', () => {
      const action = new Logout();

      actions$ = of(action);
      effects.loginRedirect$.subscribe();

      expect(routerService.navigate).toHaveBeenCalledWith(['/login']);
    });
  });

  describe('resetPasswordInit$', () => {
    it('should return an auth.ResetPasswordInitSuccess action, with user information if resetPassword succeeds', () => {
      const action = new ResetPasswordInit(resetPasswordInitPayload);
      const completion = new ResetPasswordInitSuccess(user);

      actions$ = hot('-a---', { a: action });
      const response = cold('-a|', { a: user });
      const expected = cold('--b', { b: completion });
      authService.resetPasswordInit.mockReturnValue(response);

      expect(effects.resetPasswordInit$).toBeObservable(expected);
    });

    it('should return a new auth.ResetPasswordInitFailure if the resetPassword service throws', () => {
      const error = { error: { error: 'Invalid email' } };
      const action = new ResetPasswordInit(resetPasswordInitPayload);
      const completion = new ResetPasswordInitFailure(error.error.error);

      actions$ = hot('-a---', { a: action });
      const response = cold('-#', {}, error);
      const expected = cold('--b', { b: completion });
      authService.resetPasswordInit.mockReturnValue(response);

      expect(effects.resetPasswordInit$).toBeObservable(expected);
    });
  });

  describe('resetPasswordFinishSuccess$', () => {
    it('should dispatch a RouterNavigation action when auth.ResetPasswordFinishSuccess is dispatched', () => {
      const action = new ResetPasswordFinishSuccess(user);

      actions$ = of(action);
      effects.resetPasswordFinishSuccess$.subscribe();

      expect(routerService.navigate).toHaveBeenCalledWith(['/login']);
    });
  });

  describe('resetPasswordFinish$', () => {
    it('should return an auth.ResetPasswordFinishSuccess action, with user information if resetPassword succeeds', () => {
      const action = new ResetPasswordFinish(resetPasswordFinishPayload);
      const completion = new ResetPasswordFinishSuccess(user);

      actions$ = hot('-a---', { a: action });
      const response = cold('-a|', { a: user });
      const expected = cold('--b', { b: completion });
      authService.resetPasswordFinish.mockReturnValue(response);

      expect(effects.resetPasswordFinish$).toBeObservable(expected);
    });

    it('should return a new auth.ResetPasswordFailure if the resetPassword service throws', () => {
      const error = { error: { error: 'Invalid key' } };
      const action = new ResetPasswordFinish(resetPasswordFinishPayload);
      const completion = new ResetPasswordFinishFailure(error.error.error);

      actions$ = hot('-a---', { a: action });
      const response = cold('-#', {}, error);
      const expected = cold('--b', { b: completion });
      authService.resetPasswordFinish.mockReturnValue(response);

      expect(effects.resetPasswordFinish$).toBeObservable(expected);
    });
  });

  describe('initialLogin$', () => {
    it('should return a login.InitialLogin action', () => {
      const completion = new InitialLogin(initialLoginPayload);

      const expected = cold('(a|)', { a: completion });
      localStorageService.retrieve.mockImplementation(
        idToken => initialLoginPayload[idToken],
        currentUser => initialLoginPayload[currentUser]
      );

      expect(effects.initialLogin$).toBeObservable(expected);
    });
  });
});
