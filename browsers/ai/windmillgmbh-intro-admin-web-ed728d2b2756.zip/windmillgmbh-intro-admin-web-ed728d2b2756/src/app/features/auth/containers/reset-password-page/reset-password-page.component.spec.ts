import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { StoreModule, Store, combineReducers } from '@ngrx/store';

import { CoreModule } from '../../../../core/core.module';
import { SharedModule } from '@shared/shared.module';

import { ResetPasswordPageComponent } from './reset-password-page.component';
import { ResetPasswordFormComponent } from '../../components/reset-password-form/reset-password-form.component';

import * as AuthActions from '../../actions/auth.actions';
import * as fromAuth from '../../reducers/index';

describe('Reset Password Page', () => {
  let fixture: ComponentFixture<ResetPasswordPageComponent>;
  let store: Store<fromAuth.State>;
  let instance: ResetPasswordPageComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        StoreModule.forRoot({
          auth: combineReducers(fromAuth.reducers),
        }),
        ReactiveFormsModule,
        CoreModule,
        SharedModule
      ],
      declarations: [ResetPasswordPageComponent, ResetPasswordFormComponent],
    });

    fixture = TestBed.createComponent(ResetPasswordPageComponent);
    instance = fixture.componentInstance;
    store = TestBed.get(Store);

    spyOn(store, 'dispatch').and.callThrough();
  });

  /**
   * Container components are used as integration points for connecting
   * the store to presentational components and dispatching
   * actions to the store.
   *
   * Container methods that dispatch events are like a component's output observables.
   * Container properties that select state from store are like a component's input properties.
   * If pure components are functions of their inputs, containers are functions of state
   *
   * Traditionally you would query the components rendered template
   * to validate its state. Since the components are analogous to
   * pure functions, we take snapshots of these components for a given state
   * to validate the rendered output and verify the component's output
   * against changes in state.
   */
  it('should compile', () => {
    fixture.detectChanges();

    expect(fixture).toMatchSnapshot();
  });

  it('should dispatch a reset password init event on initResetPassword call', () => {
    const $event: any = {};
    const action = new AuthActions.ResetPasswordInit($event);

    instance.initResetPassword($event);

    expect(store.dispatch).toHaveBeenCalledWith(action);
  });

  it('should dispatch a reset password finish event on finishResetPassword call', () => {
    const $event: any = {};
    const action = new AuthActions.ResetPasswordFinish($event);

    instance.finishResetPassword($event);

    expect(store.dispatch).toHaveBeenCalledWith(action);
  });
});
