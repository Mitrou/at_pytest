import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { ResetPasswordFormComponent } from './reset-password-form.component';

import { resetPasswordInitPayload, resetPasswordFinishPayload } from '@shared/mocks/index';

describe('Reset Password Page', () => {
  let fixture: ComponentFixture<ResetPasswordFormComponent>;
  let instance: ResetPasswordFormComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule],
      declarations: [ResetPasswordFormComponent],
      schemas: [NO_ERRORS_SCHEMA],
    });

    fixture = TestBed.createComponent(ResetPasswordFormComponent);
    instance = fixture.componentInstance;
  });

  it('should compile', () => {
    fixture.detectChanges();

    /**
     * The reset password form is a presentational component, as it
     * only derives its state from inputs and communicates
     * externally through outputs. We can use snapshot
     * tests to validate the presentation state of this component
     * by changing its inputs and snapshotting the generated
     * HTML.
     *
     * We can also use this as a validation tool against changes
     * to the component's template against the currently stored
     * snapshot.
     */
    expect(fixture).toMatchSnapshot();
  });

  it('should show the initForm if step equal to 1', () => {
    instance.step = 1;

    fixture.detectChanges();

    expect(fixture).toMatchSnapshot();
  });

  it('should show the finishForm if step equal to 2', () => {
    instance.step = 2;

    fixture.detectChanges();

    expect(fixture).toMatchSnapshot();
  });

  it('should disable the initForm form if pending', () => {
    instance.step = 1;
    instance.pending = true;

    fixture.detectChanges();

    expect(fixture).toMatchSnapshot();
  });

  it('should disable the finishForm form if pending', () => {
    instance.step = 2;
    instance.pending = true;

    fixture.detectChanges();

    expect(fixture).toMatchSnapshot();
  });

  it('should display an error message in initForm if provided', () => {
    instance.step = 1;
    instance.error = 'Invalid credentials';

    fixture.detectChanges();

    expect(fixture).toMatchSnapshot();
  });

  it('should display an error message in finishForm if provided', () => {
    instance.step = 2;
    instance.error = 'Invalid credentials';

    fixture.detectChanges();

    expect(fixture).toMatchSnapshot();
  });

  it('should emit an event if the initForm is valid when submitted', () => {
    instance.initForm.setValue(resetPasswordInitPayload);

    spyOn(instance.initResetPassword, 'emit');
    instance.submitInitForm();

    expect(instance.initResetPassword.emit).toHaveBeenCalledWith(resetPasswordInitPayload);
  });

  it('should emit an event if the finishForm is valid when submitted', () => {
    instance.finishForm.setValue(resetPasswordFinishPayload);

    spyOn(instance.finishResetPassword, 'emit');
    instance.submitFinishForm();

    expect(instance.finishResetPassword.emit).toHaveBeenCalledWith(resetPasswordFinishPayload);
  });
});
