import produce from 'immer';

import { AuthActionTypes, AuthActionsUnion } from '../actions/auth.actions';
import { User } from '@shared/models/user';

export interface State {
  error: string | null;
  currentUser: User;
  pending: boolean;
}

export const initialState: State = {
  error: null,
  currentUser: null,
  pending: false
};

export function reducer(state = initialState, action: AuthActionsUnion): State {
  return produce(state, draft => {
    switch (action.type) {
      case AuthActionTypes.InitialLogin: {
        draft.error = null;
        draft.currentUser = action.payload.currentUser;
        draft.pending = false;
        return;
      }
      case AuthActionTypes.GetCurrentUserInit: {
        draft.error = null;
        draft.currentUser = null;
        draft.pending = true;
        return;
      }

      case AuthActionTypes.GetCurrentUserSuccess: {
        draft.error = null;
        draft.currentUser = action.payload;
        draft.pending = false;
        return;
      }

      case AuthActionTypes.GetCurrentUserFailure: {
        draft.error = action.payload;
        draft.currentUser = null;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getCurrentUser = (state: State) => state.currentUser;
export const getPending = (state: State) => state.pending;
