import { Component, ChangeDetectionStrategy } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromAuth from '../../reducers/index';
import * as AuthActions from '../../actions/auth.actions';

import { LoginPayload } from '../../models/auth';

@Component({
  selector: 'wml-login-page',
  templateUrl: './login-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginPageComponent {
  pending$ = this.store.pipe(select(fromAuth.getLoginPagePending));
  error$ = this.store.pipe(select(fromAuth.getLoginPageError));
  currentUser$ = this.store.pipe(select(fromAuth.getCurrentUser));

  constructor(private store: Store<fromAuth.State>) {}

  onSubmit($event: LoginPayload) {
    this.store.dispatch(new AuthActions.Login($event));
  }
}
