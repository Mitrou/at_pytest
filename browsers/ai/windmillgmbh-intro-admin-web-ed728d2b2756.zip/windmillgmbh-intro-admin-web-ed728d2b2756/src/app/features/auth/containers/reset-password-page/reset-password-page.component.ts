import { Component, ChangeDetectionStrategy } from '@angular/core';
import { Store, select } from '@ngrx/store';

import * as fromAuth from '../../reducers/index';
import * as AuthActions from '../../actions/auth.actions';

import {
  ResetPasswordInitPayload,
  ResetPasswordFinishPayload
} from '../../models/auth';

@Component({
  selector: 'wml-reset-password-page',
  templateUrl: './reset-password-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ResetPasswordPageComponent {
  step$ = this.store.pipe(select(fromAuth.getResetPasswordPageStep));
  error$ = this.store.pipe(select(fromAuth.getResetPasswordPageError));
  pending$ = this.store.pipe(select(fromAuth.getResetPasswordPagePending));

  constructor(private store: Store<fromAuth.State>) {
  }

  initResetPassword($event: ResetPasswordInitPayload) {
    this.store.dispatch(new AuthActions.ResetPasswordInit($event));
  }

  finishResetPassword($event: ResetPasswordFinishPayload) {
    this.store.dispatch(new AuthActions.ResetPasswordFinish($event));
  }
}
