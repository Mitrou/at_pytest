import {
  createSelector,
  createFeatureSelector,
  ActionReducerMap
} from '@ngrx/store';

import * as fromAuth from './auth.reducer';
import * as fromRoot from '../../../reducers';
import * as fromLoginPage from './login-page.reducer';
import * as fromCurrentUser from './current-user.reducer';
import * as fromResetPasswordPage from './reset-password-page.reducer';

export interface AuthState {
  status: fromAuth.State;
  loginPage: fromLoginPage.State;
  resetPasswordPage: fromResetPasswordPage.State;
  currentUser: fromCurrentUser.State;
}

export interface State extends fromRoot.State {
  auth: AuthState;
}

export const reducers: ActionReducerMap<AuthState> = {
  status: fromAuth.reducer,
  loginPage: fromLoginPage.reducer,
  resetPasswordPage: fromResetPasswordPage.reducer,
  currentUser: fromCurrentUser.reducer
};

export const selectAuthState = createFeatureSelector<State, AuthState>('auth');

// status selectors
export const selectAuthStatusState = createSelector(
  selectAuthState,
  (state: AuthState) => state.status
);
export const getLoggedIn = createSelector(
  selectAuthStatusState,
  fromAuth.getLoggedIn
);

// loginPage selectors
export const selectLoginPageState = createSelector(
  selectAuthState,
  (state: AuthState) => state.loginPage
);
export const getLoginPageError = createSelector(
  selectLoginPageState,
  fromLoginPage.getError
);
export const getLoginPagePending = createSelector(
  selectLoginPageState,
  fromLoginPage.getPending
);

// resetPasswordPage selectors
export const selectResetPasswordPageState = createSelector(
  selectAuthState,
  (state: AuthState) => state.resetPasswordPage
);
export const getResetPasswordPageStep = createSelector(
  selectResetPasswordPageState,
  fromResetPasswordPage.getStep
);
export const getResetPasswordPageError = createSelector(
  selectResetPasswordPageState,
  fromResetPasswordPage.getError
);
export const getResetPasswordPagePending = createSelector(
  selectResetPasswordPageState,
  fromResetPasswordPage.getPending
);

// currentUser selectors
export const selectCurrentUserState = createSelector(
  selectAuthState,
  (state: AuthState) => state.currentUser
);
export const getCurrentUser = createSelector(
  selectCurrentUserState,
  fromCurrentUser.getCurrentUser
);
export const getCurrentUserError = createSelector(
  selectCurrentUserState,
  fromCurrentUser.getError
);
export const getCurrentUserPending = createSelector(
  selectCurrentUserState,
  fromCurrentUser.getPending
);
