import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { ResetPasswordFinishPayload, ResetPasswordInitPayload } from '../../models/auth';
import { EmailValidator } from '@shared/form-validators/email.validator';

@Component({
  selector: 'wml-reset-password-form',
  templateUrl: './reset-password-form.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ResetPasswordFormComponent implements OnInit {
  @Input()
  set pending(isPending: boolean) {
    this.isPending = isPending;

    if (isPending) {
      this.initForm.disable();
      this.finishForm.disable();
    } else {
      this.initForm.enable();
      this.finishForm.enable();
    }
  }

  @Input() step: number;

  @Input() error: string | null;

  @Output() initResetPassword = new EventEmitter<ResetPasswordInitPayload>();

  @Output() finishResetPassword = new EventEmitter<ResetPasswordFinishPayload>();

  isPending: boolean;

  initForm: FormGroup = new FormGroup({
    mail: new FormControl('', Validators.compose([
      EmailValidator.validate,
      Validators.required
    ])),
  });

  finishForm: FormGroup = new FormGroup({
    key: new FormControl('', Validators.required),
    newPassword: new FormControl('', Validators.required),
  });

  constructor() {
  }

  ngOnInit() {
  }

  submitInitForm() {
    if (this.initForm.valid) {
      this.initResetPassword.emit(this.initForm.value);
    }
  }

  submitFinishForm() {
    if (this.finishForm.valid) {
      this.finishResetPassword.emit(this.finishForm.value);
    }
  }
}
