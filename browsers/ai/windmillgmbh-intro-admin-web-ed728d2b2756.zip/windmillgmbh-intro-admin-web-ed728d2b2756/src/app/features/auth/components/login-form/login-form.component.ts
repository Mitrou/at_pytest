import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { LoginPayload } from '../../models/auth';
import { EmailValidator } from '@shared/form-validators/email.validator';

@Component({
  selector: 'wml-login-form',
  templateUrl: './login-form.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginFormComponent implements OnInit {
  @Input()
  set pending(isPending: boolean) {
    this.isPending = isPending;

    if (isPending) {
      this.form.disable();
    } else {
      this.form.enable();
    }
  }

  @Input() error: string | null;

  @Output() submitted = new EventEmitter<LoginPayload>();

  isPending: boolean;

  form: FormGroup = new FormGroup({
    username: new FormControl('admin@intro.com', Validators.compose([
      EmailValidator.validate,
      Validators.required
    ])),
    password: new FormControl('admin', Validators.required),
  });

  constructor() {
  }

  ngOnInit() {
  }

  submit() {
    if (this.form.valid) {
      this.submitted.emit(this.form.value);
    }
  }
}
