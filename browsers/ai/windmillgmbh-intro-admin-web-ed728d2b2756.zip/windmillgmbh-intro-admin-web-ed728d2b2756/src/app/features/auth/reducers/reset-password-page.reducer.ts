import produce from 'immer';

import { AuthActionTypes, AuthActionsUnion } from '../actions/auth.actions';

export interface State {
  step: number;
  error: string | null;
  pending: boolean;
}

export const initialState: State = {
  step: 1,
  error: null,
  pending: false,
};

export function reducer(state = initialState, action: AuthActionsUnion): State {
  return produce(state, (draft) => {
    switch (action.type) {
      case AuthActionTypes.ResetPasswordInit:
      case AuthActionTypes.ResetPasswordFinish: {
        draft.error = null;
        draft.pending = true;
        return;
      }

      case AuthActionTypes.ResetPasswordInitSuccess: {
        draft.step = 2;
        draft.error = null;
        draft.pending = false;
        return;
      }

      case AuthActionTypes.ResetPasswordFinishSuccess: {
        Object.assign(draft, initialState);
        return;
      }

      case AuthActionTypes.ResetPasswordInitFailure:
      case AuthActionTypes.ResetPasswordFinishFailure: {
        draft.error = action.payload;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getStep = (state: State) => state.step;
export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
