import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '@shared/models/user';

import {
  LoginPayload,
  LoginSuccessPayload,
  ResetPasswordInitPayload,
  ResetPasswordFinishPayload
} from '../models/auth';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private http: HttpClient) {}

  login(payload: LoginPayload): Observable<LoginSuccessPayload> {
    return this.http.post<LoginSuccessPayload>('/api/authenticate', payload);
  }

  resetPasswordInit(payload: ResetPasswordInitPayload): Observable<any> {
    return this.http.post<any>('/api/reset-password/init', payload);
  }

  resetPasswordFinish(payload: ResetPasswordFinishPayload): Observable<any> {
    return this.http.post<any>('/api/reset-password/finish', payload);
  }

  getCurrentUser(): Observable<any> {
    return this.http.get<User>('/api/current-user').pipe(
      map(user => new User(user))
    );
  }
}
