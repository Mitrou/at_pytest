import { reducer } from './current-user.reducer';
import * as fromCurrentUser from './current-user.reducer';

import {
  GetCurrentUserInit,
  GetCurrentUserSuccess,
  GetCurrentUserFailure
} from '../actions/auth.actions';

import { user, getCurrentUserErrorStr } from '@shared/mocks';
import { User } from '@shared/models/user';

describe('GetCurrentUserReducer', () => {
  describe('null action', () => {
    it('should return the default state', () => {
      const action = {} as any;

      const result = reducer(null, action);

      /**
       * Snapshot tests are a quick way to validate
       * the state produced by a reducer since
       * its plain JavaScript object. These snapshots
       * are used to validate against the current state
       * if the functionality of the reducer ever changes.
       */
      expect(result).toMatchSnapshot();
    });
  });

  describe('[Auth] Get Current User Init', () => {
    it('should change pending to true in currentUser state', () => {
      const createAction = new GetCurrentUserInit();

      const result = reducer(fromCurrentUser.initialState, createAction);

      expect(result).toEqual({
        ...fromCurrentUser.initialState,
        pending: true
      });
    });
  });

  describe('[Auth] Get Current User Success', () => {
    it('should toggle current user state and user should be defined', () => {
      const action = new GetCurrentUserSuccess(user as User);
      const result = reducer(fromCurrentUser.initialState, action);

      expect(result).toEqual({
        ...fromCurrentUser.initialState,
        currentUser: user,
        pending: false
      });
    });
  });

  describe('[Auth] Get Current User Failure', () => {
    it('should toggle current user state and user should be null', () => {
      const action = new GetCurrentUserFailure(getCurrentUserErrorStr);
      const result = reducer(fromCurrentUser.initialState, action);

      expect(result).toEqual({
        ...fromCurrentUser.initialState,
        currentUser: null,
        error: getCurrentUserErrorStr,
        pending: false
      });
    });
  });
});
