import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Action } from '@ngrx/store';
import { Actions, Effect, ofType } from '@ngrx/effects';

import { Observable, of, defer } from 'rxjs';
import { exhaustMap, map, tap, catchError, switchMap } from 'rxjs/operators';

import {
  AuthActionTypes,
  Login,
  LoginFailure,
  LoginSuccess,
  ResetPasswordInit,
  ResetPasswordInitSuccess,
  ResetPasswordInitFailure,
  ResetPasswordFinish,
  ResetPasswordFinishSuccess,
  ResetPasswordFinishFailure,
  InitialLogin,
  GetCurrentUserInit,
  GetCurrentUserSuccess,
  GetCurrentUserFailure
} from '../actions/auth.actions';

import { LocalStorageService } from 'ngx-webstorage';
import { AuthService } from '../services/auth.service';
import { User } from '@shared/models/user';

import {
  LoginPayload,
  ResetPasswordInitPayload,
  ResetPasswordFinishPayload,
  LoginSuccessPayload
} from '../models/auth';

@Injectable()
export class AuthEffects {
  @Effect()
  login$: Observable<Action> = this.actions$.pipe(
    ofType<Login>(AuthActionTypes.Login),
    map(action => action.payload),
    exhaustMap((auth: LoginPayload) =>
      this.authService.login(auth).pipe(
        switchMap((payload: LoginSuccessPayload) => [
          new LoginSuccess(payload),
          new GetCurrentUserInit()
        ]),
        catchError(e => of(new LoginFailure(e.error.error)))
      )
    )
  );

  @Effect({ dispatch: false })
  loginSuccess$: Observable<any> = this.actions$.pipe(
    ofType<LoginSuccess>(AuthActionTypes.LoginSuccess),
    map(action => action.payload),
    tap((payload: LoginSuccessPayload) => {
      this.localStorageService.store('idToken', payload.idToken);
      this.router.navigate(['/']);
    })
  );

  @Effect()
  getCurrentUser$: Observable<Action> = this.actions$.pipe(
    ofType<GetCurrentUserInit>(AuthActionTypes.GetCurrentUserInit),
    exhaustMap(() =>
      this.authService.getCurrentUser().pipe(
        map(res => new GetCurrentUserSuccess(res)),
        catchError(e => of(new GetCurrentUserFailure(e.error.error)))
      )
    )
  );

  @Effect({ dispatch: false })
  getCurrentUserSuccess$: Observable<any> = this.actions$.pipe(
    ofType<GetCurrentUserSuccess>(AuthActionTypes.GetCurrentUserSuccess),
    map(action => action.payload),
    tap((payload: User) => {
      this.localStorageService.store('currentUser', payload);
    })
  );

  @Effect()
  loginFailure$: Observable<any> = this.actions$.pipe(
    ofType<LoginFailure>(AuthActionTypes.LoginFailure),
    map(action => new GetCurrentUserFailure(action.payload))
  );

  @Effect({ dispatch: false })
  loginRedirect$: Observable<any> = this.actions$.pipe(
    ofType(AuthActionTypes.LoginRedirect, AuthActionTypes.Logout),
    tap(() => {
      this.localStorageService.clear('idToken');
      this.router.navigate(['/login']);
    })
  );

  @Effect()
  resetPasswordInit$: Observable<Action> = this.actions$.pipe(
    ofType<ResetPasswordInit>(AuthActionTypes.ResetPasswordInit),
    map(action => action.payload),
    exhaustMap((payload: ResetPasswordInitPayload) =>
      this.authService.resetPasswordInit(payload).pipe(
        map(() => new ResetPasswordInitSuccess()),
        catchError(e => of(new ResetPasswordInitFailure(e.error.error)))
      )
    )
  );

  @Effect()
  resetPasswordFinish$: Observable<Action> = this.actions$.pipe(
    ofType<ResetPasswordFinish>(AuthActionTypes.ResetPasswordFinish),
    map(action => action.payload),
    exhaustMap((payload: ResetPasswordFinishPayload) =>
      this.authService.resetPasswordFinish(payload).pipe(
        map(() => new ResetPasswordFinishSuccess()),
        catchError(e => of(new ResetPasswordFinishFailure(e.error.error)))
      )
    )
  );

  @Effect({ dispatch: false })
  resetPasswordFinishSuccess$: Observable<any> = this.actions$.pipe(
    ofType(AuthActionTypes.ResetPasswordFinishSuccess),
    tap(() => this.router.navigate(['/login']))
  );

  // Should be the last effect
  @Effect()
  initialLogin$: Observable<Action> = defer(() => {
    return of(
      new InitialLogin({
        idToken: this.localStorageService.retrieve('idToken'),
        currentUser: this.localStorageService.retrieve('currentUser')
      })
    );
  });

  constructor(
    private actions$: Actions,
    private router: Router,
    private authService: AuthService,
    private localStorageService: LocalStorageService
  ) {}
}
