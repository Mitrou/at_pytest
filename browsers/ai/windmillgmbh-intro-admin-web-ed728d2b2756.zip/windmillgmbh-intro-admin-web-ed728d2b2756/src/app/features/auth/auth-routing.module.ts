import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './containers/login-page/login-page.component';
import { ResetPasswordPageComponent } from './containers/reset-password-page/reset-password-page.component';

const routes: Routes = [
  {path: 'login', component: LoginPageComponent},
  {path: 'reset-password', component: ResetPasswordPageComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AuthRoutingModule {
}
