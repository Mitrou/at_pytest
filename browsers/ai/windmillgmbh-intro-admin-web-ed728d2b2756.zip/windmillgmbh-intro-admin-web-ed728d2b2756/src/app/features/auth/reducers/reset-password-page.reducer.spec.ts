import { reducer } from './reset-password-page.reducer';
import * as fromResetPasswordPage from './reset-password-page.reducer';

import {
  ResetPasswordInit,
  ResetPasswordInitSuccess,
  ResetPasswordInitFailure,
  ResetPasswordFinish,
  ResetPasswordFinishSuccess,
  ResetPasswordFinishFailure,
} from '../actions/auth.actions';

import {
  user,
  resetPasswordInitPayload,
  resetPasswordFinishPayload,
} from '@shared/mocks';

describe('ResetPasswordPageReducer', () => {
  describe('undefined action', () => {
    it('should return the default state', () => {
      const action = {} as any;

      const result = reducer(undefined, action);

      expect(result).toMatchSnapshot();
    });
  });

  describe('RESET_PASSWORD_INIT', () => {
    it('should make pending to true and error to null', () => {
      const createAction = new ResetPasswordInit(resetPasswordInitPayload);

      const result = reducer(fromResetPasswordPage.initialState, createAction);

      expect(result).toMatchSnapshot();
    });
  });

  describe('RESET_PASSWORD_INIT_SUCCESS', () => {
    it('should have no error and no pending state', () => {
      const createAction = new ResetPasswordInitSuccess({user});

      const result = reducer(fromResetPasswordPage.initialState, createAction);

      expect(result).toMatchSnapshot();
    });
  });

  describe('RESET_PASSWORD_INIT_FAILURE', () => {
    it('should have an error and no pending state', () => {
      const error = 'resetPassword failed';
      const createAction = new ResetPasswordInitFailure(error);

      const result = reducer(fromResetPasswordPage.initialState, createAction);

      expect(result).toMatchSnapshot();
    });
  });

  describe('RESET_PASSWORD_FINISH', () => {
    it('should make pending to true and error to null', () => {
      const createAction = new ResetPasswordFinish(resetPasswordFinishPayload);

      const result = reducer(fromResetPasswordPage.initialState, createAction);

      expect(result).toMatchSnapshot();
    });
  });

  describe('RESET_PASSWORD_FINISH_SUCCESS', () => {
    it('should set initial state', () => {
      const createAction = new ResetPasswordFinishSuccess({user});

      const result = reducer(fromResetPasswordPage.initialState, createAction);

      expect(result).toMatchSnapshot();
    });
  });

  describe('RESET_PASSWORD_FINISH_FAILURE', () => {
    it('should have an error and no pending state', () => {
      const error = 'resetPassword failed';
      const createAction = new ResetPasswordFinishFailure(error);

      const result = reducer(fromResetPasswordPage.initialState, createAction);

      expect(result).toMatchSnapshot();
    });
  });
});
