import { Action } from '@ngrx/store';

import {
  LoginPayload,
  LoginSuccessPayload,
  ResetPasswordInitPayload,
  ResetPasswordFinishPayload
} from '../models/auth';
import { User } from '@shared/models/user';

export enum AuthActionTypes {
  Login = '[Auth] Login',
  InitialLogin = '[Auth] Initial Login',
  LoginSuccess = '[Auth] Login Success',
  LoginFailure = '[Auth] Login Failure',
  LoginRedirect = '[Auth] Login Redirect',
  Logout = '[Auth] Logout',
  ResetPasswordInit = '[Auth] Reset Password Init',
  ResetPasswordInitSuccess = '[Auth] Reset Password Init Success',
  ResetPasswordInitFailure = '[Auth] Reset Password Init Failure',
  ResetPasswordFinish = '[Auth] Reset Password Finish',
  ResetPasswordFinishSuccess = '[Auth] Reset Password Finish Success',
  ResetPasswordFinishFailure = '[Auth] Reset Password Finish Failure',
  GetCurrentUserInit = '[Auth] Get Current User Init',
  GetCurrentUserSuccess = '[Auth] Get Current User Success',
  GetCurrentUserFailure = '[Auth] Get Current User Failure'
}

export class Login implements Action {
  readonly type = AuthActionTypes.Login;

  constructor(public payload: LoginPayload) {}
}

export class InitialLogin implements Action {
  readonly type = AuthActionTypes.InitialLogin;

  constructor(public payload: { idToken: string; currentUser: User }) {}
}

export class LoginSuccess implements Action {
  readonly type = AuthActionTypes.LoginSuccess;

  constructor(public payload: LoginSuccessPayload) {}
}

export class LoginFailure implements Action {
  readonly type = AuthActionTypes.LoginFailure;

  constructor(public payload: string) {}
}

export class LoginRedirect implements Action {
  readonly type = AuthActionTypes.LoginRedirect;
}

export class Logout implements Action {
  readonly type = AuthActionTypes.Logout;
}

export class ResetPasswordInit implements Action {
  readonly type = AuthActionTypes.ResetPasswordInit;

  constructor(public payload: ResetPasswordInitPayload) {}
}

export class ResetPasswordInitSuccess implements Action {
  readonly type = AuthActionTypes.ResetPasswordInitSuccess;

  constructor() {}
}

export class ResetPasswordInitFailure implements Action {
  readonly type = AuthActionTypes.ResetPasswordInitFailure;

  constructor(public payload: string) {}
}

export class ResetPasswordFinish implements Action {
  readonly type = AuthActionTypes.ResetPasswordFinish;

  constructor(public payload: ResetPasswordFinishPayload) {}
}

export class ResetPasswordFinishSuccess implements Action {
  readonly type = AuthActionTypes.ResetPasswordFinishSuccess;

  constructor() {}
}

export class ResetPasswordFinishFailure implements Action {
  readonly type = AuthActionTypes.ResetPasswordFinishFailure;

  constructor(public payload: string) {}
}

export class GetCurrentUserInit implements Action {
  readonly type = AuthActionTypes.GetCurrentUserInit;

  constructor() {}
}

export class GetCurrentUserSuccess implements Action {
  readonly type = AuthActionTypes.GetCurrentUserSuccess;

  constructor(public payload: User) {}
}

export class GetCurrentUserFailure implements Action {
  readonly type = AuthActionTypes.GetCurrentUserFailure;

  constructor(public payload: string) {}
}

export type AuthActionsUnion =
  | Login
  | InitialLogin
  | LoginSuccess
  | LoginFailure
  | LoginRedirect
  | Logout
  | ResetPasswordInit
  | ResetPasswordInitSuccess
  | ResetPasswordInitFailure
  | ResetPasswordFinish
  | ResetPasswordFinishSuccess
  | ResetPasswordFinishFailure
  | GetCurrentUserInit
  | GetCurrentUserSuccess
  | GetCurrentUserFailure;
