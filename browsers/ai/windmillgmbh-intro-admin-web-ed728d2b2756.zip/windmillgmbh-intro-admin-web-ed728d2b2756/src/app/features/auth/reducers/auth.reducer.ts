import produce from 'immer';

import { AuthActionsUnion, AuthActionTypes } from '../actions/auth.actions';

export interface State {
  loggedIn: boolean;
}

export const initialState: State = {
  loggedIn: false
};

export function reducer(state = initialState, action: AuthActionsUnion): State {
  return produce(state, draft => {
    switch (action.type) {
      case AuthActionTypes.InitialLogin: {
        draft.loggedIn = Boolean(action.payload.idToken);
        return;
      }

      case AuthActionTypes.LoginSuccess: {
        draft.loggedIn = true;
        return;
      }

      case AuthActionTypes.Logout: {
        return initialState;
      }
    }
  });
}

export const getLoggedIn = (state: State) => state.loggedIn;
