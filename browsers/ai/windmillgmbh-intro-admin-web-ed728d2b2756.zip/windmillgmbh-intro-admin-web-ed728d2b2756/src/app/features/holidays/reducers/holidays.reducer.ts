import { HolidaysActions, HolidaysActionTypes } from '../actions/holidays.actions';
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { Holiday } from '../models/holiday.model';


export interface HolidaysState extends EntityState<Holiday> {
  isLoading: boolean;
  error: any;

  count: number; // count
  offset: number; // offset
  limit: number; // limit

  selectedHolidayId: number | null;
}

export const holidayEntityAdapter: EntityAdapter<Holiday> = createEntityAdapter<Holiday>({
  selectId: (model: Holiday) => model.id
});


export const initialState: HolidaysState = holidayEntityAdapter.getInitialState(
  {
    isLoading: false,
    error: null,

    count: 0,
    offset: 0,
    limit: 10,

    selectedHolidayId: null
  }
);


export function reducer(state = initialState, action: HolidaysActions): HolidaysState {
  switch (action.type) {

    case HolidaysActionTypes.LoadHolidays: {
      return {
        ...state,
        isLoading: true,
        error: null,

        offset: action.pageInfo.offset,
        limit: action.pageInfo.limit
      };
    }

    case HolidaysActionTypes.DeleteHoliday: {
      return {
        ...state,
        isLoading: true,
        error: null,
      };
    }

    case HolidaysActionTypes.LoadHolidaysSuccess: {
      return holidayEntityAdapter.addAll(action.payload.data, {
        ...state,
        isLoading: false,
        error: null,
        count: action.payload.count
      });
    }

    case HolidaysActionTypes.LoadHolidaysFailure: {
      return {
        ...state,
        isLoading: false,
        error: action.payload,
        count: 0,
        offset: 0
      };
    }

    case HolidaysActionTypes.AddHolidaySuccess:
    case HolidaysActionTypes.LoadHolidaySuccess: {
      return holidayEntityAdapter.addOne(action.payload, state);
    }

    case HolidaysActionTypes.UpdateHolidaySuccess: {
      return holidayEntityAdapter.upsertOne(action.payload, state);
    }

    case HolidaysActionTypes.DeleteHolidaySuccess: {
      return holidayEntityAdapter.removeOne(action.payload, state);
    }


    case HolidaysActionTypes.SelectHoliday: {
      return {
        ...state,
        selectedHolidayId: action.payload
      };
    }

    default:
      return state;
  }
}

export const getIsLoading = (state: HolidaysState): boolean => state.isLoading;
export const getError = (state: HolidaysState): any => state.error;

export const getCount = (state: HolidaysState): any => state.count;
export const getOffset = (state: HolidaysState): any => state.offset;
export const getLimit = (state: HolidaysState): any => state.limit;

export const getSelectedHolidayId = (state: HolidaysState) => state.selectedHolidayId;
