import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HolidaysRoutingModule } from './holidays-routing.module';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { CoreModule } from '../../core/core.module';
import { SharedModule } from '@shared/shared.module';

import { HolidaysPageComponent } from './containers/holidays-page/holidays-page.component';
import { HolidaysListComponent } from './components/holidays-list/holidays-list.component';
import { HolidayAddPanelComponent } from './containers/holiday-add-panel/holiday-add-panel.component';
import { HolidayUpdatePanelComponent } from './containers/holiday-update-panel/holiday-update-panel.component';
import { HolidayFormComponent } from './components/holiday-form/holiday-form.component';

import { HolidaysEffects } from './effects/holidays.effects';
import { reducer } from './reducers/holidays.reducer';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { holidaysReducers } from './reducers';


export const COMPONENTS = [
  HolidaysPageComponent,
  HolidaysListComponent,
  HolidayAddPanelComponent,
  HolidayUpdatePanelComponent,
  HolidayFormComponent
];


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HolidaysRoutingModule,

    StoreModule.forFeature('holidays', holidaysReducers),
    EffectsModule.forFeature([HolidaysEffects]),

    CoreModule,
    SharedModule
  ],
  declarations: COMPONENTS,
  exports: COMPONENTS
})
export class HolidaysModule {
}
