import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Holiday } from '../../models/holiday.model';



@Component({
  selector: 'wml-holiday-form',
  templateUrl: './holiday-form.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HolidayFormComponent {
  @Input() holidayId: string | null = null;

  @Input()
  set holiday(holiday: Holiday | undefined) {
    if (holiday) {
      this.form.patchValue({
        id: holiday.id,
        occasion: holiday.occasion,
        holidayDate: new Date(holiday.holidayDate),
        universities: holiday.universities,
      });
    }
  }

  @Input()
  set pending(isPending: boolean) {
    this.isPending = isPending;

    if (isPending) {
      this.form.disable();
    } else {
      this.form.enable();
    }
  }

  @Input() error: string | null;

  @Output() submitted = new EventEmitter<Holiday>();

  isPending: boolean;

  form: FormGroup = new FormGroup({
    id: new FormControl(''),
    occasion: new FormControl('', Validators.required),
    holidayDate: new FormControl('', Validators.required),
    universities: new FormControl(''),
  });

  constructor() {
  }

  submit() {
    if (this.form.valid) {
      this.submitted.emit(this.form.value);
    }
  }
}
