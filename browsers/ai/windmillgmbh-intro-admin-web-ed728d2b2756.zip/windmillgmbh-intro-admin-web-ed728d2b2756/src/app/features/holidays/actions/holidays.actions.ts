import { Action } from '@ngrx/store';
import { Filters } from '../../../core/types/filters';
import { Holiday } from '../models/holiday.model';


export enum HolidaysActionTypes {
  LoadHolidays = '[Holidays] Load List',
  LoadHolidaysSuccess = '[Holidays] Load List Success',
  LoadHolidaysFailure = '[Holidays] Load List Failure',

  AddHoliday = '[Holidays] Add Holiday',
  AddHolidaySuccess = '[Holidays] Add Holiday Success',
  AddHolidayFailure = '[Holidays] Add Holiday Failure',

  SelectHoliday = '[Holidays] Select Holiday',

  DeleteHoliday = '[Holidays] Delete Holiday',
  DeleteHolidaySuccess = '[Holidays] Delete Holiday Success',
  DeleteHolidayFailure = '[Holidays] Delete Holiday Failure',

  LoadHoliday = '[Holidays] Load Holiday',
  LoadHolidaySuccess = '[Holidays] Load Holiday Success',
  LoadHolidayFailure = '[Holidays] Load Holiday Failure',

  UpdateHoliday = '[Holidays] Update Holiday',
  UpdateHolidaySuccess = '[Holidays] Update Holiday Success',
  UpdateHolidayFailure = '[Holidays] Update Holiday Failure',

  NavigateToUpdateHolidayPage = '[Holiday] Navigate To Update',
}

////////////

export class LoadHolidays implements Action {
  readonly type = HolidaysActionTypes.LoadHolidays;

  constructor(
    public pageInfo = { offset: 0, limit: 10 },
    public sortInfo = { prop: 'id', dir: 'asc' },
    public filters: Filters = null) {
  }
}

export class LoadHolidaysSuccess implements Action {
  readonly type = HolidaysActionTypes.LoadHolidaysSuccess;

  constructor(public payload: any) {
  }
}

export class LoadHolidaysFailure implements Action {
  readonly type = HolidaysActionTypes.LoadHolidaysFailure;

  constructor(public payload: any) {
  }
}

export class AddHoliday implements Action {
  readonly type = HolidaysActionTypes.AddHoliday;

  constructor(public payload: Holiday) {
  }
}

export class AddHolidaySuccess implements Action {
  readonly type = HolidaysActionTypes.AddHolidaySuccess;

  constructor(public payload: Holiday) {
  }
}

export class AddHolidayFailure implements Action {
  readonly type = HolidaysActionTypes.AddHolidayFailure;

  constructor(public payload: string) {
  }
}

export class SelectHoliday implements Action {
  readonly type = HolidaysActionTypes.SelectHoliday;

  constructor(public payload: number) {
  }
}

export class LoadHoliday implements Action {
  readonly type = HolidaysActionTypes.LoadHoliday;
}

export class LoadHolidaySuccess implements Action {
  readonly type = HolidaysActionTypes.LoadHolidaySuccess;

  constructor(public payload: Holiday) {
  }
}

export class LoadHolidayFailure implements Action {
  readonly type = HolidaysActionTypes.LoadHolidayFailure;

  constructor(public payload: string) {
  }
}

export class UpdateHoliday implements Action {
  readonly type = HolidaysActionTypes.UpdateHoliday;

  constructor(public payload: Holiday) {
  }
}

export class UpdateHolidaySuccess implements Action {
  readonly type = HolidaysActionTypes.UpdateHolidaySuccess;

  constructor(public payload: Holiday) {
  }
}

export class UpdateHolidayFailure implements Action {
  readonly type = HolidaysActionTypes.UpdateHolidayFailure;

  constructor(public payload: string) {
  }
}

export class NavigateToUpdateHolidayPage implements Action {
  readonly type = HolidaysActionTypes.NavigateToUpdateHolidayPage;

  constructor(public payload: number) {
  }
}

export class DeleteHoliday implements Action {
  readonly type = HolidaysActionTypes.DeleteHoliday;

  constructor(public payload: number) {
  }
}

export class DeleteHolidaySuccess implements Action {
  readonly type = HolidaysActionTypes.DeleteHolidaySuccess;
  constructor(public payload: number) {
  }
}

export class DeleteHolidayFailure implements Action {
  readonly type = HolidaysActionTypes.DeleteHolidayFailure;

  constructor(public payload: string) {
  }
}

////////////

export type HolidaysActions =
  | LoadHolidays
  | LoadHolidaysSuccess
  | LoadHolidaysFailure
  | AddHoliday
  | AddHolidaySuccess
  | AddHolidayFailure
  | SelectHoliday
  | LoadHoliday
  | LoadHolidaySuccess
  | LoadHolidayFailure
  | UpdateHoliday
  | UpdateHolidaySuccess
  | UpdateHolidayFailure
  | NavigateToUpdateHolidayPage
  | DeleteHoliday
  | DeleteHolidaySuccess
  | DeleteHolidayFailure;
