import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';
import * as fromHolidays from '../../reducers/index';
import { Holiday } from '../../models/holiday.model';
import { AddHoliday } from '../../actions/holidays.actions';


@Component({
  selector: 'wml-holiday-add-panel',
  templateUrl: './holiday-add-panel.component.html'
})
export class HolidayAddPanelComponent {
  pending$ = this.store.pipe(select(fromHolidays.getHolidayUpdatePanelPending));
  error$ = this.store.pipe(select(fromHolidays.getHolidayUpdatePanelError));

  constructor(private store: Store<fromHolidays.HolidaysMainState>) {
  }

  onSubmit($event: Holiday) {
    this.store.dispatch(new AddHoliday($event));
  }
}
