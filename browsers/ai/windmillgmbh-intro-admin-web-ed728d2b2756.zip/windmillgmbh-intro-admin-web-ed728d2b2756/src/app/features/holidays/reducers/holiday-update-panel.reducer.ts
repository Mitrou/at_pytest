import produce from 'immer';

import { HolidaysActionTypes, HolidaysActions } from '../actions/holidays.actions';

export interface State {
  error: string | null;
  pending: boolean;
}

export const initialState: State = {
  error: null,
  pending: false,
};

export function reducer(state = initialState, action: HolidaysActions): State {
  return produce(state, (draft) => {
    switch (action.type) {
      case HolidaysActionTypes.LoadHoliday:
      case HolidaysActionTypes.UpdateHoliday: {
        draft.error = null;
        draft.pending = true;
        return;
      }

      case HolidaysActionTypes.LoadHolidaySuccess:
      case HolidaysActionTypes.UpdateHolidaySuccess: {
        draft.error = null;
        draft.pending = false;
        return;
      }

      case HolidaysActionTypes.LoadHolidayFailure:
      case HolidaysActionTypes.UpdateHolidayFailure: {
        draft.error = action.payload;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
