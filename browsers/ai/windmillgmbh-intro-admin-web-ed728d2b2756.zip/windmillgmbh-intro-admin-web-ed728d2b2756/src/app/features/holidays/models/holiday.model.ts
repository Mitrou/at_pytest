export class Holiday {
  id: number;
  occasion: string;
  holidayDate: string;
  universities: string;

  constructor(raw) {
    this.id = raw.id;
    this.occasion = raw.occasion;
    this.holidayDate = raw.holidayDate;
    this.universities = raw.universities;
  }
}
