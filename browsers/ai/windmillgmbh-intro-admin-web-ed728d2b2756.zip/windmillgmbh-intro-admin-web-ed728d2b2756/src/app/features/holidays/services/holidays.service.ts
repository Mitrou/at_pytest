import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Holiday } from '../models/holiday.model';
import { map } from 'rxjs/operators';
import { Filters } from '../../../core/types/filters';
import { BaseService } from '@shared/services/base.service';
import { LoadListSuccessPayload } from '@shared/models/list';


@Injectable({
  providedIn: 'root'
})
export class HolidaysService extends BaseService {

  getHolidays({ offset, limit }, { prop, dir }, filters: Filters): Observable<LoadListSuccessPayload<Holiday>> {
    return this.gridRequest<Holiday>(`/api/holiday`, offset + 1, limit, prop, dir, filters)
      .pipe(
        map(response => ({
          ...response,
          data: response.data.map(holiday => new Holiday(holiday))
        }))
      );
  }

  loadHoliday(id: number): Observable<Holiday> {
    return this.http.get<Holiday>(`/api/holiday/${id}`);
  }

  addHoliday(payload: Holiday): Observable<Holiday> {
    return this.http.post<Holiday>('/api/holiday', payload);
  }

  updateHoliday(payload: Holiday): Observable<Holiday> {
    return this.http.put<Holiday>(`/api/holiday/${payload.id}`, payload);
  }

  deleteHoliday(id: number) {
    return this.http.delete(`/api/holiday/${id}`);
  }
}
