import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromHolidays from '../../reducers/index';
import { Holiday } from '../../models/holiday.model';
import { Observable } from 'rxjs';
import { HolidaysMainState } from '../../reducers';
import * as fromRoot from '../../../../reducers';


@Component({
  selector: 'wml-holidays-page',
  templateUrl: './holidays-page.component.html'
})
export class HolidaysPageComponent {
  drawerOpened$: Observable<boolean>;

  holidays$: Observable<Holiday[]>;
  holidaysIsLoading$: Observable<boolean>;

  holidaysCount$: Observable<number>;
  holidaysOffset$: Observable<number>;
  holidaysLimit$: Observable<number>;

  constructor(private store: Store<HolidaysMainState>) {
    this.drawerOpened$ = this.store.pipe(select(fromRoot.getDrawerOpened));

    this.holidays$ = store.pipe(select(fromHolidays.getAllHolidays));
    this.holidaysIsLoading$ = store.pipe(select(fromHolidays.getHolidaysIsLoading));

    this.holidaysCount$ = store.pipe(select(fromHolidays.getHolidaysCount));
    this.holidaysOffset$ = store.pipe(select(fromHolidays.getHolidaysOffset));
    this.holidaysLimit$ = store.pipe(select(fromHolidays.getHolidaysLimit));
  }
}
