import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { Holiday } from '../../models/holiday.model';
import { ColumnFilterType, ColumnType, GridAction, GridOptions } from '@shared/components/grid/grid.configs';
import { Store } from '@ngrx/store';
import { HolidaysMainState } from '../../reducers';
import * as HolidaysActions from '../../actions/holidays.actions';


@Component({
  selector: 'wml-holidays-list',
  templateUrl: './holidays-list.component.html',
  styleUrls: ['./holidays-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HolidaysListComponent {
  @Input() count: number;
  @Input() offset: number;
  @Input() limit: number;

  @Input() holidays: Holiday[] = [];

  @Input() loading = true;

  @Input() drawerOpened = false;

  private gridState = null;

  options: GridOptions = {
    actions: [GridAction.Edit, GridAction.Delete],
    columns: [
      {
        prop: 'occasion',
        columnType: ColumnType.Text,

        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        prop: 'holidayDate',
        columnType: ColumnType.Date,

        filterable: false,
        dateFormat: 'MMM d'
      },
      {
        prop: 'universities',
        columnType: ColumnType.Text,
        hideOnDrawerOpened: true,

        filterable: true,
        filterType: ColumnFilterType.SelectMultiple,
        filterData: [
          { id: 0, title: 'All' },
          { id: 1, title: 'University1' },
          { id: 2, title: 'University2' },
          { id: 3, title: 'University3' }
        ]
      }
    ]
  };

  constructor(private store: Store<HolidaysMainState>) {
  }

  reloadGrid(event = null) {
    if (event !== null) {
      this.gridState = event;
    }

    this.store.dispatch(new HolidaysActions.LoadHolidays(
      this.gridState.pageInfo,
      this.gridState.sortInfo,
      this.gridState.filters)
    );
  }

  onItemSelected(item) {
    this.store.dispatch(new HolidaysActions.NavigateToUpdateHolidayPage(item.id));
  }

  onItemEdit(item) {
    this.store.dispatch(new HolidaysActions.NavigateToUpdateHolidayPage(item.id));
  }

  onItemDelete(item) {
    this.store.dispatch(new HolidaysActions.DeleteHoliday(item.id));

    this.reloadGrid();
  }
}
