import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { select, Store } from '@ngrx/store';

import { Observable, of } from 'rxjs';
import { map, switchMap, take, tap } from 'rxjs/operators';

import * as fromHolidays from '../reducers';
import { LoadHoliday, SelectHoliday } from '../actions/holidays.actions';


@Injectable({
  providedIn: 'root',
})
export class HolidayInStoreGuard implements CanActivate {
  constructor(
    private store: Store<fromHolidays.HolidaysMainState>,
  ) {
  }

  hasDepartmentInStore(id: number): Observable<boolean> {
    return this.store.pipe(
      select(fromHolidays.getHolidayEntities),
      map(entities => !!entities[id]),
      take(1)
    );
  }

  hasDepartment(id: number): Observable<boolean> {
    return this.hasDepartmentInStore(id).pipe(
      tap(() => this.store.dispatch(new SelectHoliday(id))),
      tap((inStore) => {
        if (!inStore) {
          this.store.dispatch(new LoadHoliday());
        }
      }),
      switchMap(() => {
        return of(true);
      })
    );
  }

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.hasDepartment(Number(route.params['holidayId']));
  }
}
