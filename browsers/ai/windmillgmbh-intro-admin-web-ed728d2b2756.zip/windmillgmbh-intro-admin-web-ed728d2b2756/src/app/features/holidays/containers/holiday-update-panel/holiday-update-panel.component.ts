import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromRoot from '../../../../reducers';
import * as fromHolidays from '../../reducers/index';

import { map } from 'rxjs/operators';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';
import { Holiday } from '../../models/holiday.model';
import { UpdateHoliday } from '../../actions/holidays.actions';


@Component({
  selector: 'wml-holiday-update-panel',
  templateUrl: './holiday-update-panel.component.html'
})
export class HolidayUpdatePanelComponent {
  holidayId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.holidayId)
  );

  holiday$ = this.store.pipe(select(fromHolidays.getSelectedHoliday));
  pending$ = this.store.pipe(select(fromHolidays.getHolidayUpdatePanelPending));
  error$ = this.store.pipe(select(fromHolidays.getHolidayUpdatePanelError));

  constructor(private store: Store<fromHolidays.HolidaysMainState>) {
  }

  onSubmit($event: Holiday) {
    this.store.dispatch(new UpdateHoliday($event));
  }
}
