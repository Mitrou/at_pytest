import * as fromHolidays from './holidays.reducer';
import { getCount, getIsLoading, getLimit, getOffset, holidayEntityAdapter } from './holidays.reducer';
import * as fromRoot from '../../../reducers';
import { ActionReducerMap, createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromHolidayUpdatePanel from './holiday-update-panel.reducer';


export interface HolidaysMainState {
  holidays: fromHolidays.HolidaysState;
  holidayUpdatePanel: fromHolidayUpdatePanel.State;
}

export interface State extends fromRoot.State {
  holidays: HolidaysMainState;
}

export const holidaysReducers: ActionReducerMap<HolidaysMainState> = {
  holidays: fromHolidays.reducer,
  holidayUpdatePanel: fromHolidayUpdatePanel.reducer
};

export const selectHolidaysState = createFeatureSelector<State, HolidaysMainState>('holidays');

export const getHolidayEntitiesState = createSelector(
  selectHolidaysState,
  state => state.holidays
);

export const {
  selectEntities: getHolidayEntities,
  selectAll: getAllHolidays
} = holidayEntityAdapter.getSelectors(getHolidayEntitiesState);


export const getHolidaysIsLoading = createSelector(
  getHolidayEntitiesState,
  getIsLoading
);

export const getHolidaysCount = createSelector(
  getHolidayEntitiesState,
  getCount
);
export const getHolidaysOffset = createSelector(
  getHolidayEntitiesState,
  getOffset
);
export const getHolidaysLimit = createSelector(
  getHolidayEntitiesState,
  getLimit
);
export const getSelectedHolidayId = createSelector(
  getHolidayEntitiesState,
  fromHolidays.getSelectedHolidayId
);


export const getSelectedHoliday = createSelector(
  getHolidayEntities,
  getSelectedHolidayId,
  (entities, selectedId) => {
    return selectedId !== null && entities[selectedId];
  }
);


// departmentUpdatePanel selectors
export const selectHolidayUpdatePanelState = createSelector(
  selectHolidaysState,
  (state: HolidaysMainState) => state.holidayUpdatePanel
);
export const getHolidayUpdatePanelError = createSelector(
  selectHolidayUpdatePanelState,
  fromHolidayUpdatePanel.getError
);
export const getHolidayUpdatePanelPending = createSelector(
  selectHolidayUpdatePanelState,
  fromHolidayUpdatePanel.getPending
);
