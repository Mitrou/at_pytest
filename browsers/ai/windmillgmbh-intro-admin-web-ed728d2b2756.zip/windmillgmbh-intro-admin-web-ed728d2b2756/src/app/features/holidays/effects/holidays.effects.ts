import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import {
  AddHoliday, AddHolidayFailure, AddHolidaySuccess, DeleteHoliday, DeleteHolidayFailure, DeleteHolidaySuccess,
  HolidaysActionTypes, LoadHoliday, LoadHolidayFailure,
  LoadHolidays,
  LoadHolidaysFailure,
  LoadHolidaysSuccess, LoadHolidaySuccess,
  NavigateToUpdateHolidayPage, UpdateHoliday, UpdateHolidayFailure, UpdateHolidaySuccess
} from '../actions/holidays.actions';
import { HolidaysService } from '../services/holidays.service';
import { Observable, of, of as observableOf } from 'rxjs';
import { Action, select, Store } from '@ngrx/store';
import { catchError, exhaustMap, map, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { HolidaysMainState } from '../reducers';
import * as fromHolidays from '../reducers';

import * as fromRoot from '../../../reducers';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';
import { Router } from '@angular/router';
import { Holiday } from '../models/holiday.model';


@Injectable()
export class HolidaysEffects {

  @Effect()
  loadHolidaysEffect$: Observable<Action> = this.actions$.pipe(
    ofType<LoadHolidays>(
      HolidaysActionTypes.LoadHolidays
    ),
    switchMap(({pageInfo, sortInfo, filters}) =>
      this.holidayService
        .getHolidays(pageInfo, sortInfo, filters)
        .pipe(
          map(holidays => new LoadHolidaysSuccess(holidays)),
          catchError(error => observableOf(new LoadHolidaysFailure(error)))
        )
    )
  );

  @Effect()
  addHoliday$: Observable<Action> = this.actions$.pipe(
    ofType<AddHoliday>(HolidaysActionTypes.AddHoliday),
    map((action) => action.payload),
    exhaustMap((holiday: Holiday) =>
      this.holidayService.addHoliday(holiday)
        .pipe(
          map((payload: Holiday) => new AddHolidaySuccess(payload)),
          catchError((e) => of(new AddHolidayFailure(e.error.error)))
        )
    )
  );

  @Effect()
  deleteHoliday$: Observable<Action> = this.actions$.pipe(
    ofType<DeleteHoliday>(HolidaysActionTypes.DeleteHoliday),
    map((action) => action.payload),
    exhaustMap((id: number) =>
      this.holidayService.deleteHoliday(id)
        .pipe(
          map(() => new DeleteHolidaySuccess(id)),
          catchError((e) => of(new DeleteHolidayFailure(e.error.error)))
        )
    )
  );

  @Effect()
  loadHoliday$: Observable<Action> = this.actions$.pipe(
    ofType<LoadHoliday>(HolidaysActionTypes.LoadHoliday),
    withLatestFrom(
      this.store.pipe(select(fromHolidays.getSelectedHolidayId)),
      (action, id: number) => id
    ),
    switchMap((id) =>
      this.holidayService.loadHoliday(id)
        .pipe(
          map((payload: Holiday) => new LoadHolidaySuccess(payload)),
          catchError((e) => of(new LoadHolidayFailure(e.error.error)))
        )
    )
  );

  @Effect({dispatch: false})
  loadHolidayFailure$: Observable<any> = this.actions$.pipe(
    ofType<LoadHolidayFailure>(HolidaysActionTypes.LoadHolidayFailure),
    tap(() => {
      this.router.navigate(['/404']);
    })
  );

  @Effect()
  updateHoliday$: Observable<Action> = this.actions$.pipe(
    ofType<UpdateHoliday>(HolidaysActionTypes.UpdateHoliday),
    map((action) => action.payload),
    exhaustMap((holiday: Holiday) =>
      this.holidayService.updateHoliday(holiday)
        .pipe(
          map((payload: Holiday) => new UpdateHolidaySuccess(payload)),
          catchError((e) => of(new UpdateHolidayFailure(e.error.error)))
        )
    )
  );

  @Effect({dispatch: false})
  navigateToHolidaysPage$: Observable<any> = this.actions$.pipe(
    ofType(
      HolidaysActionTypes.AddHolidaySuccess,
      HolidaysActionTypes.UpdateHolidaySuccess
    ),
    withLatestFrom(
      this.store.pipe(select(fromRoot.getRouterSerializedState)),
      (action, routerState: RouterStateUrl) => routerState.params.universityId
    ),
    tap((universityId) => {
      this.router.navigate(['/holidays']);
    })
  );

  @Effect({dispatch: false})
  navigateToUpdateHolidayPage$: Observable<any> = this.actions$.pipe(
    ofType<NavigateToUpdateHolidayPage>(HolidaysActionTypes.NavigateToUpdateHolidayPage),
    withLatestFrom(
      this.store.pipe(select(fromRoot.getRouterSerializedState)),
      (action: NavigateToUpdateHolidayPage, routerState: RouterStateUrl) => ({
        holidayId: action.payload
      })
    ),
    tap(({holidayId}) => {
      this.router.navigate(['/holidays', holidayId, 'update']);
    })
  );

  constructor(
    private store: Store<HolidaysMainState>,
    private router: Router,
    private actions$: Actions,
    private holidayService: HolidaysService) {
  }
}
