import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HolidaysPageComponent } from './containers/holidays-page/holidays-page.component';
import { OpenDrawerGuard } from '../../core/services/open-drawer-guard.service';
import { CloseDrawerGuard } from '../../core/services/close-drawer-guard.service';
import { HolidayUpdatePanelComponent } from './containers/holiday-update-panel/holiday-update-panel.component';
import { HolidayInStoreGuard } from './services/holiday-in-store.guard';
import { HolidayAddPanelComponent } from './containers/holiday-add-panel/holiday-add-panel.component';


const routes: Routes = [
  {
    path: '',
    component: HolidaysPageComponent,
    children: [
      {
        path: 'add',
        component: HolidayAddPanelComponent,
        canActivate: [OpenDrawerGuard],
        canDeactivate: [CloseDrawerGuard]
      },
      {
        path: ':holidayId/update',
        component: HolidayUpdatePanelComponent,
        canActivate: [HolidayInStoreGuard, OpenDrawerGuard],
        canDeactivate: [CloseDrawerGuard]
      }
    ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HolidaysRoutingModule {
}
