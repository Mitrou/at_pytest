export interface QuickActions {
  possibleMatches: number;
  pendingFeedback: number;
  meetingCount: number;
  userCount: number;
}
