import produce from 'immer';
import { TopUsers } from '../models/top-users';

import {
  DashboardActionsUnion,
  DashboardActionTypes
} from '../actions/dashboard.actions';

export interface State {
  pending: boolean;
  error: string;
  topUsers: TopUsers;
}

export const initialState: State = {
  pending: false,
  error: null,
  topUsers: null
};

export function reducer(
  state: State = initialState,
  action: DashboardActionsUnion
): State {
  return produce(state, draft => {
    switch (action.type) {
      case DashboardActionTypes.GetTopUsersInit: {
        draft.error = null;
        draft.topUsers = null;
        draft.pending = true;
        return;
      }

      case DashboardActionTypes.GetTopUsersSuccess: {
        draft.error = null;
        draft.topUsers = action.payload;
        draft.pending = false;
        return;
      }

      case DashboardActionTypes.GetTopUsersFailure: {
        draft.error = action.payload;
        draft.topUsers = null;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getTopUsers = (state: State) => state.topUsers;
