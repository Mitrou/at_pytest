import produce from 'immer';
import { QuickActions } from '../models/quick-actions';

import {
  DashboardActionsUnion,
  DashboardActionTypes
} from '../actions/dashboard.actions';

export interface State {
  pending: boolean;
  error: string;
  quickStats: QuickActions;
}

export const initialState: State = {
  pending: false,
  error: null,
  quickStats: null
};

export function reducer(
  state: State = initialState,
  action: DashboardActionsUnion
): State {
  return produce(state, draft => {
    switch (action.type) {
      case DashboardActionTypes.GetQuickActionsInit: {
        draft.error = null;
        draft.quickStats = null;
        draft.pending = true;
        return;
      }

      case DashboardActionTypes.GetQuickActionsSuccess: {
        draft.error = null;
        draft.quickStats = action.payload;
        draft.pending = false;
        return;
      }

      case DashboardActionTypes.GetQuickActionsFailure: {
        draft.error = action.payload;
        draft.quickStats = null;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getQuickStats = (state: State) => state.quickStats;
