import { Component, OnInit } from '@angular/core';
import { TopInterests } from '../models/top-interests';
import { TopUsers } from '../models/top-users';
import { Observable } from 'rxjs';

import * as fromDashboard from '../reducers/index';
import * as DashboardActions from '../actions/dashboard.actions';

import { Store } from '@ngrx/store';

@Component({
  selector: 'wml-top-data',
  templateUrl: './top-data.component.html'
})
export class TopDataComponent implements OnInit {
  topInterests$: Observable<TopInterests>;
  pendingTopInterests$: Observable<boolean>;
  topUsers$: Observable<TopUsers>;
  pendingTopUsers$: Observable<boolean>;

  constructor(private store: Store<fromDashboard.State>) {
    // get top interests related data from store
    this.topInterests$ = this.store.select(
      fromDashboard.getTopInterestsValueState
    );

    this.pendingTopInterests$ = this.store.select(
      fromDashboard.getTopInterestsPendingState
    );

    // get top users related data from store
    this.topUsers$ = this.store.select(
      fromDashboard.getTopUsersValueState
    );

    this.pendingTopUsers$ = this.store.select(
      fromDashboard.getTopUsersPendingState
    );
   }

  ngOnInit() {
    this.store.dispatch(new DashboardActions.GetTopInterestsInit());
    this.store.dispatch(new DashboardActions.GetTopUsersInit());
  }

}
