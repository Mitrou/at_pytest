import { Component, OnInit } from '@angular/core';
import {
  StructuredUserStatistics
} from '../models/user-statistics';
import {
  MeetingStatistics,
  StructuredMeetingStatistics
} from '../models/meeting-statistics';

import { Store } from '@ngrx/store';

import * as fromDashboard from '../reducers/index';
import * as DashboardActions from '../actions/dashboard.actions';
import { Observable } from 'rxjs';


@Component({
  selector: 'wml-statistics',
  templateUrl: './statistics.component.html'
})
export class StatisticsComponent implements OnInit {
  userStats$: Observable<StructuredUserStatistics>;
  pendingUserStats$: Observable<boolean>;
  userStatsPeriod$: Observable<string>;

  meetingStatsStructured$: Observable<StructuredMeetingStatistics>;
  meetingStats$: Observable<MeetingStatistics>;
  pendingMeetingStats$: Observable<boolean>;
  meetingStatsPeriod$: Observable<string>;

  constructor(private store: Store<fromDashboard.State>) {
    // get user statistics related data from store
    this.userStatsPeriod$ = this.store.select(
      fromDashboard.getUserStatisticsPeriod
    );

    this.userStats$ = this.store.select(
      fromDashboard.getDashboardUserStatistics
    );

    this.pendingUserStats$ = this.store.select(
      fromDashboard.getUserStatisticsPendingState
    );

    // get meeting statistics related data from store
    this.meetingStatsPeriod$ = this.store.select(
      fromDashboard.getMeetingStatisticsPeriodState
    );

    this.meetingStats$ = this.store.select(
      fromDashboard.getMeetingStatisticsValueState
    );

    this.meetingStatsStructured$ = this.store.select(
      fromDashboard.getDashboardMeetingStatistics
    );

    this.pendingMeetingStats$ = this.store.select(
      fromDashboard.getMeetingStatisticsPendingState
    );
  }

  ngOnInit() {
    this.store.dispatch(
      new DashboardActions.GetUserStatisticsInit({ period: '3 Months' })
    );

    this.store.dispatch(
      new DashboardActions.GetMeetingStatisticsInit({ period: '3 Months' })
    );
  }

  onPeriodSelected(period: string) {
    this.store.dispatch(
      new DashboardActions.GetUserStatisticsInit({ period: period })
    );
  }

  onMeetingPeriodSelected(period: string) {
    this.store.dispatch(
      new DashboardActions.GetMeetingStatisticsInit({ period: period })
    );
  }
}
