import {
  Component,
  ChangeDetectionStrategy,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { HeaderStats } from '../../../models/user-statistics';

@Component({
  selector: 'wml-chart-header',
  templateUrl: './chart-header.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChartHeaderComponent {
  @Input() pending: boolean;
  @Input() stats: HeaderStats;
  @Input() selectOptions: string[];

  @Input() statsPeriod: string;

  @Output() selectValue = new EventEmitter<any>();
}
