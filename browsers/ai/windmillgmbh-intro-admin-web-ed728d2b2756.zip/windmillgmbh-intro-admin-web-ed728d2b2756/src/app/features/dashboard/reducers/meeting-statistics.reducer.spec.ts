import { reducer } from './meeting-statistics.reducer';
import * as fromMeetingStats from './meeting-statistics.reducer';

import {
  GetMeetingStatisticsInit,
  GetMeetingStatisticsSuccess,
  GetMeetingStatisticsFailure
} from '../actions/dashboard.actions';

import { MeetingStatistics } from '../models/meeting-statistics';
import {
  meetingStatsRequest,
  getMeetingStatisticsError,
  meetingStats
} from '../../../shared/mocks/meeting-statistics';

describe('GetMeetingStatisticsReducer', () => {
  describe('null action', () => {
    it('should return the default state', () => {
      const action = {} as any;

      const result = reducer(null, action);

      /**
       * Snapshot tests are a quick way to validate
       * the state produced by a reducer since
       * its plain JavaScript object. These snapshots
       * are used to validate against the current state
       * if the functionality of the reducer ever changes.
       */
      expect(result).toMatchSnapshot();
    });
  });

  describe('[ Dashboard ] Get Meeting Statistics Init', () => {
    it('should change pending to true in meetingStatistics state', () => {
      const createAction = new GetMeetingStatisticsInit(meetingStatsRequest);

      const result = reducer(fromMeetingStats.initialState, createAction);

      expect(result).toEqual({
        ...fromMeetingStats.initialState,
        pending: true,
        requestedPeriod: meetingStatsRequest.period
      });
    });
  });

  describe('[Dashboard] Get Meeting Statistics Success', () => {
    it('should toggle meetingStatistics state and meetingStatistics should be defined', () => {
      const action = new GetMeetingStatisticsSuccess(
        meetingStats as MeetingStatistics
      );
      const result = reducer(fromMeetingStats.initialState, action);

      expect(result).toEqual({
        ...fromMeetingStats.initialState,
        meetingStatistics: meetingStats,
        pending: false
      });
    });
  });

  describe('[Dashboard] Get Meeting Statistics Failure', () => {
    it('should toggle meetingStatistics state and meetingStatictics should be null', () => {
      const action = new GetMeetingStatisticsFailure(getMeetingStatisticsError);
      const result = reducer(fromMeetingStats.initialState, action);

      expect(result).toEqual({
        ...fromMeetingStats.initialState,
        meetingStatistics: null,
        error: getMeetingStatisticsError,
        pending: false
      });
    });
  });
});
