export interface TopUser {
    firstName: string;
    lastName: string;
    email: string;
    participation: string;
    type: string;
    getTogethers: number;
    percentage: number;
  }

export interface TopUsers {
    totalUsers: number;
    topUsers: TopUser[];
  }
