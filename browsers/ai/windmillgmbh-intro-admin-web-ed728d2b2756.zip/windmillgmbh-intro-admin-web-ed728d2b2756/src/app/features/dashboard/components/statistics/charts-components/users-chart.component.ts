import {
  Component,
  Input,
  ChangeDetectionStrategy,
  EventEmitter,
  Output
} from '@angular/core';
import {
  StructuredUserStatistics,
  LineChartData,
  HeaderStats
} from '../../../models/user-statistics';

@Component({
  selector: 'wml-users-chart',
  templateUrl: './users-chart.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UsersChartComponent {
  @Input() pending: boolean;
  @Input() userStatsPeriod: string;
  @Input()
  set userStats(userStatistics: StructuredUserStatistics) {
    this.userStatistics = userStatistics;

    if (userStatistics) {
      this.lineChartData[0].data = this.userStatistics.stats.data;
      this.lineChartLabels = this.userStatistics.stats.labels;

      this.headerStats = {
        total: this.userStatistics.totalUsers,
        new: this.userStatistics.newUsers,
        trend: this.userStatistics.trend
      } as HeaderStats;
    }
  }

  @Output() selectPeriod = new EventEmitter<any>();
  readonly periods: string[] = ['1 Year', '6 Months', '3 Months', 'Month'];

  userStatistics: StructuredUserStatistics;
  headerStats: HeaderStats;

  // lineChart
  public lineChartData: Array<LineChartData> = [
    { data: [], label: 'User Statistics' }
  ];

  public lineChartLabels: Array<string> = [];
  public lineChartOptions: any = {
    responsive: true
  };
  public lineChartColors: Array<any> = [
    {
      // grey
      backgroundColor: 'rgba(67, 160, 71, 0.6)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ];
  public lineChartLegend = true;
  public lineChartType = 'line';

  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

  onPeriodSelected(period: string) {
    this.selectPeriod.emit(period);
  }
}
