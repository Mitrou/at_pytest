import produce from 'immer';
import {
  UserStatistics,
  UserStatisticsRequest
} from '../models/user-statistics';

import {
  DashboardActionsUnion,
  DashboardActionTypes
} from '../actions/dashboard.actions';

export interface State {
  pending: boolean;
  error: string;
  userStatistics: UserStatistics;
  requestedPeriod: string;
}

export const initialState: State = {
  pending: false,
  error: null,
  userStatistics: null,
  requestedPeriod: null
};

export function reducer(
  state: State = initialState,
  action: DashboardActionsUnion
): State {
  return produce(state, draft => {
    switch (action.type) {
      case DashboardActionTypes.LoadDashboards: {
        return initialState;
      }

      case DashboardActionTypes.GetUserStatisticsInit: {
        draft.error = null;
        draft.userStatistics = null;
        draft.pending = true;
        draft.requestedPeriod = action.payload.period;
        return;
      }

      case DashboardActionTypes.GetUserStatisticsSuccess: {
        draft.error = null;
        draft.userStatistics = action.payload;
        draft.pending = false;
        return;
      }

      case DashboardActionTypes.GetUserStatisticsFailure: {
        draft.error = action.payload;
        draft.userStatistics = null;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getUserStatistics = (state: State) => state.userStatistics;
export const getRequestedPeriod = (state: State) => state.requestedPeriod;
