import { Action } from '@ngrx/store';
import { QuickActions } from '../models/quick-actions';
import { TopInterests } from '../models/top-interests';
import { TopUsers } from '../models/top-users';
import {
  UserStatistics,
  UserStatisticsRequest
} from '../models/user-statistics';
import {
  MeetingStatistics,
  MeetingStatisticsRequest
} from '../models/meeting-statistics';

export enum DashboardActionTypes {
  LoadDashboards = '[Dashboard] Load Dashboards',
  GetUserStatisticsInit = '[Dashboard] Get User Statistics Init',
  GetUserStatisticsSuccess = '[Dashboard] Get User Statistics Success',
  GetUserStatisticsFailure = '[Dashboard] Get User Statistics Failure',
  GetMeetingStatisticsInit = '[Dashboard] Get Meeting Statistics Init',
  GetMeetingStatisticsSuccess = '[Dashboard] Get Meeting Statistics Success',
  GetMeetingStatisticsFailure = '[Dashboard] Get Meeting Statistics Failure',
  GetQuickActionsInit = '[Dashboard] Get Quick Actions Init',
  GetQuickActionsSuccess = '[Dashboard] Get Quick Actions Success',
  GetQuickActionsFailure = '[Dashboard] Get Quick Actions Failure',
  GetTopInterestsInit = '[Dashboard] Get Top Interests Init',
  GetTopInterestsSuccess = '[Dashboard] Get Top Interests Success',
  GetTopInterestsFailure = '[Dashboard] Get Top Interests Failure',
  GetTopUsersInit = '[Dashboard] Get Top Users Init',
  GetTopUsersSuccess = '[Dashboard] Get Top Users Success',
  GetTopUsersFailure = '[Dashboard] Get Top Users Failure'
}

export class LoadDashboards implements Action {
  readonly type = DashboardActionTypes.LoadDashboards;
}

// user statistics actions
export class GetUserStatisticsInit implements Action {
  readonly type = DashboardActionTypes.GetUserStatisticsInit;
  constructor(public payload: UserStatisticsRequest) {}
}

export class GetUserStatisticsSuccess implements Action {
  readonly type = DashboardActionTypes.GetUserStatisticsSuccess;

  constructor(public payload: UserStatistics) {}
}

export class GetUserStatisticsFailure implements Action {
  readonly type = DashboardActionTypes.GetUserStatisticsFailure;

  constructor(public payload: string) {}
}

// meeting statistics actions
export class GetMeetingStatisticsInit implements Action {
  readonly type = DashboardActionTypes.GetMeetingStatisticsInit;
  constructor(public payload: MeetingStatisticsRequest) {}
}

export class GetMeetingStatisticsSuccess implements Action {
  readonly type = DashboardActionTypes.GetMeetingStatisticsSuccess;

  constructor(public payload: MeetingStatistics) {}
}

export class GetMeetingStatisticsFailure implements Action {
  readonly type = DashboardActionTypes.GetMeetingStatisticsFailure;

  constructor(public payload: string) {}
}

// quick-actions actions
export class GetQuickActionsInit implements Action {
  readonly type = DashboardActionTypes.GetQuickActionsInit;
  constructor() {}
}

export class GetQuickActionsSuccess implements Action {
  readonly type = DashboardActionTypes.GetQuickActionsSuccess;
  constructor(public payload: QuickActions) {}
}

export class GetQuickActionsFailure implements Action {
  readonly type = DashboardActionTypes.GetQuickActionsFailure;
  constructor(public payload: string) {}
}

// top-interests actions
export class GetTopInterestsInit implements Action {
  readonly type = DashboardActionTypes.GetTopInterestsInit;
  constructor() {}
}

export class GetTopInterestsSuccess implements Action {
  readonly type = DashboardActionTypes.GetTopInterestsSuccess;
  constructor(public payload: TopInterests) {}
}

export class GetTopInterestsFailure implements Action {
  readonly type = DashboardActionTypes.GetTopInterestsFailure;
  constructor(public payload: string) {}
}

// top-users actions
export class GetTopUsersInit implements Action {
  readonly type = DashboardActionTypes.GetTopUsersInit;
  constructor() {}
}

export class GetTopUsersSuccess implements Action {
  readonly type = DashboardActionTypes.GetTopUsersSuccess;
  constructor(public payload: TopUsers) {}
}

export class GetTopUsersFailure implements Action {
  readonly type = DashboardActionTypes.GetTopUsersFailure;
  constructor(public payload: string) {}
}


export type DashboardActionsUnion =
  | LoadDashboards
  | GetUserStatisticsInit
  | GetUserStatisticsSuccess
  | GetUserStatisticsFailure
  | GetMeetingStatisticsInit
  | GetMeetingStatisticsSuccess
  | GetMeetingStatisticsFailure
  | GetQuickActionsInit
  | GetQuickActionsSuccess
  | GetQuickActionsFailure
  | GetTopInterestsInit
  | GetTopInterestsSuccess
  | GetTopInterestsFailure
  | GetTopUsersInit
  | GetTopUsersSuccess
  | GetTopUsersFailure;


