import { Component, OnInit, Input, ChangeDetectionStrategy} from '@angular/core';
import { TopInterests } from '../../../models/top-interests';

@Component({
  selector: 'wml-top-interests',
  templateUrl: './top-interests.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TopInterestsComponent implements OnInit {
  @Input() topInterests: TopInterests;
  @Input() pendingTopInterests: boolean;

  constructor() { }

  ngOnInit() { }

}
