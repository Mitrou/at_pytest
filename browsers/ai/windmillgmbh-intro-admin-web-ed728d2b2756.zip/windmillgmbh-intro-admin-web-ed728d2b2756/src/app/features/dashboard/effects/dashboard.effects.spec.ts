import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { Actions } from '@ngrx/effects';
import { provideMockActions } from '@ngrx/effects/testing';
import { cold, hot } from 'jasmine-marbles';
import { Observable, of } from 'rxjs';
import { LocalStorageService } from 'ngx-webstorage';
import {
  LoadDashboards,
  GetUserStatisticsInit,
  GetUserStatisticsSuccess,
  GetUserStatisticsFailure,
  GetMeetingStatisticsInit,
  GetMeetingStatisticsSuccess,
  GetMeetingStatisticsFailure,
  GetQuickActionsInit,
  GetQuickActionsSuccess,
  GetQuickActionsFailure,
  GetTopInterestsInit,
  GetTopInterestsSuccess,
  GetTopInterestsFailure,
  GetTopUsersInit,
  GetTopUsersSuccess,
  GetTopUsersFailure
} from '../actions/dashboard.actions';

import { DashboardEffects } from './dashboard.effects';
import { DashboardService } from '../dashboard.service';

import {
  userStats,
  userStatsRequest,
  getUserStatisticsError,
  meetingStats,
  meetingStatsRequest,
  getMeetingStatisticsError,
  quickStats,
  getQuickActionsError,
  topInterests,
  getTopInterestsError,
  topUsers,
  getTopUsersError
} from '@shared/mocks';

describe('DashboardEffects', () => {
  let effects: DashboardEffects;
  let dashboardService: any;
  let actions$: Observable<any>;
  let routerService: any;
  let localStorageService: any;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        DashboardEffects,
        provideMockActions(() => actions$),
        {
          provide: Router,
          useValue: {
            navigate: jest.fn()
          }
        },
        {
          provide: DashboardService,
          useValue: {
            getUserStatistics: jest.fn(),
            getMeetingStatistics: jest.fn(),
            getQuickActions: jest.fn(),
            getTopInterests: jest.fn(),
            getTopUsers: jest.fn()
          }
        },
        {
          provide: LocalStorageService,
          useValue: {
            store: jest.fn(),
            clear: jest.fn(),
            retrieve: jest.fn()
          }
        }
      ]
    });

    effects = TestBed.get(DashboardEffects);
    dashboardService = TestBed.get(DashboardService);
    actions$ = TestBed.get(Actions);
    routerService = TestBed.get(Router);
    localStorageService = TestBed.get(LocalStorageService);

    spyOn(routerService, 'navigate').and.callThrough();
  });

  describe('Get User Statistics flow', () => {
    it(
      'dashboard.GetUserStatisticsInit and dashboard.GetUserStatisticsSuccess actions' +
        'if dashboard.getUserStatistics succeeds',
      () => {
        const action = new GetUserStatisticsInit(userStatsRequest);
        const completion = new GetUserStatisticsSuccess(userStats);

        actions$ = hot('-a---', { a: action });
        const response = cold('-a|', { a: userStats });
        const expected = cold('--b', { b: completion });

        dashboardService.getUserStatistics.mockReturnValue(response);
        expect(effects.getUserStatistics$).toBeObservable(expected);
      }
    );

    it('should save userStatistics from GetUserStatisticsSuccess action payload to local storage', () => {
      const action = new GetUserStatisticsSuccess(userStats);

      actions$ = of(action);
      effects.getUserStatisticsSuccess$.subscribe();

      expect(localStorageService.store).toHaveBeenCalledWith(
        'userStatistics',
        userStats
      );
    });

    it('should return a new dashboard.GetUserStatisticsFailure if the dashboard.service throws', () => {
      const error = { error: { error: getUserStatisticsError } };
      const action = new GetUserStatisticsInit(userStatsRequest);
      const completion = new GetUserStatisticsFailure(error.error.error);

      actions$ = hot('-a---', { a: action });
      const response = cold('-#', {}, error);
      const expected = cold('--b', { b: completion });
      dashboardService.getUserStatistics.mockReturnValue(response);

      expect(effects.getUserStatistics$).toBeObservable(expected);
    });
  });

  describe('Get Meeting Statistics flow', () => {
    it(
      'dashboard.GetMeetingStatisticsInit and dashboard.GetMeetingStatisticsSuccess actions' +
        'if dashboard.getMeetingStatistics succeeds',
      () => {
        const action = new GetMeetingStatisticsInit(meetingStatsRequest);
        const completion = new GetMeetingStatisticsSuccess(meetingStats);

        actions$ = hot('-a---', { a: action });
        const response = cold('-a|', { a: meetingStats });
        const expected = cold('--b', { b: completion });

        dashboardService.getMeetingStatistics.mockReturnValue(response);
        expect(effects.getMeetingStatistics$).toBeObservable(expected);
      }
    );

    it('should save meetingStatistics from GetMeetingStatisticsSuccess action payload to local storage', () => {
      const action = new GetMeetingStatisticsSuccess(meetingStats);

      actions$ = of(action);
      effects.getMeetingStatisticsSuccess$.subscribe();

      expect(localStorageService.store).toHaveBeenCalledWith(
        'meetingStatistics',
        meetingStats
      );
    });

    it('should return a new dashboard.GetMeetingStatisticsFailure if the dashboard.service throws', () => {
      const error = { error: { error: getMeetingStatisticsError } };
      const action = new GetMeetingStatisticsInit(meetingStatsRequest);
      const completion = new GetMeetingStatisticsFailure(error.error.error);

      actions$ = hot('-a---', { a: action });
      const response = cold('-#', {}, error);
      const expected = cold('--b', { b: completion });
      dashboardService.getMeetingStatistics.mockReturnValue(response);

      expect(effects.getMeetingStatistics$).toBeObservable(expected);
    });
  });

  describe('Get Quick Actions flow', () => {
    it(
      'dashboard.GetQuickActionsInit and dashboard.GetQuickActionsSuccess actions' +
        'if dashboard.getQuickActions succeeds',
      () => {
        const action = new GetQuickActionsInit();
        const completion = new GetQuickActionsSuccess(quickStats);

        actions$ = hot('-a---', { a: action });
        const response = cold('-a|', { a: quickStats });
        const expected = cold('--b', { b: completion });

        dashboardService.getQuickActions.mockReturnValue(response);
        expect(effects.getQuickActions$).toBeObservable(expected);
      }
    );

    it('should save quickActions from GetQuickActionsSuccess action payload to local storage', () => {
      const action = new GetQuickActionsSuccess(quickStats);

      actions$ = of(action);
      effects.getQuickActionsSuccess$.subscribe();

      expect(localStorageService.store).toHaveBeenCalledWith('quickActions', quickStats);
    });

    it('should return a new dashboard.GetQuickActionsFailure if the dashboard.service throws', () => {
      const error = { error: { error: getQuickActionsError } };
      const action = new GetQuickActionsInit();
      const completion = new GetQuickActionsFailure(error.error.error);

      actions$ = hot('-a---', { a: action });
      const response = cold('-#', {}, error);
      const expected = cold('--b', { b: completion });
      dashboardService.getQuickActions.mockReturnValue(response);

      expect(effects.getQuickActions$).toBeObservable(expected);
    });
  });

  describe('Get Top Interests flow', () => {
    it(
      'dashboard.GetTopInterestsInit and dashboard.GetTopInterestsSuccess actions' +
        'if dashboard.getTopInterests succeeds',
      () => {
        const action = new GetTopInterestsInit();
        const completion = new GetTopInterestsSuccess(topInterests);

        actions$ = hot('-a---', { a: action });
        const response = cold('-a|', { a: topInterests });
        const expected = cold('--b', { b: completion });

        dashboardService.getTopInterests.mockReturnValue(response);
        expect(effects.getTopInterests$).toBeObservable(expected);
      }
    );

    it('should return a new dashboard.GetTopInterestsFailure if the dashboard.service throws', () => {
      const error = { error: { error: getTopInterestsError } };
      const action = new GetTopInterestsInit();
      const completion = new GetTopInterestsFailure(error.error.error);

      actions$ = hot('-a---', { a: action });
      const response = cold('-#', {}, error);
      const expected = cold('--b', { b: completion });
      dashboardService.getTopInterests.mockReturnValue(response);

      expect(effects.getTopInterests$).toBeObservable(expected);
    });
  });

  describe('Get Top Users flow', () => {
    it(
      'dashboard.GetTopUsersInit and dashboard.GetTopUsersSuccess actions' +
        'if dashboard.getTopUsers succeeds',
      () => {
        const action = new GetTopUsersInit();
        const completion = new GetTopUsersSuccess(topUsers);

        actions$ = hot('-a---', { a: action });
        const response = cold('-a|', { a: topUsers });
        const expected = cold('--b', { b: completion });

        dashboardService.getTopUsers.mockReturnValue(response);
        expect(effects.getTopUsers$).toBeObservable(expected);
      }
    );

    it('should return a new dashboard.GetTopUsersFailure if the dashboard.service throws', () => {
      const error = { error: { error: getTopUsersError } };
      const action = new GetTopUsersInit();
      const completion = new GetTopUsersFailure(error.error.error);

      actions$ = hot('-a---', { a: action });
      const response = cold('-#', {}, error);
      const expected = cold('--b', { b: completion });
      dashboardService.getTopUsers.mockReturnValue(response);

      expect(effects.getTopUsers$).toBeObservable(expected);
    });
  });
});
