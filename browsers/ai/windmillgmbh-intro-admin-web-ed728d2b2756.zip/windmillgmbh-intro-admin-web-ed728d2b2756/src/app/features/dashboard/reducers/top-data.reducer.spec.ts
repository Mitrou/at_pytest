import { reducer as interestsReducer } from './top-interests.reducer';
import { reducer as usersReducer } from './top-users.reducer';

import * as fromTopInterests from './top-interests.reducer';
import * as fromTopUsers from './top-users.reducer';

import {
    GetTopInterestsInit,
    GetTopInterestsSuccess,
    GetTopInterestsFailure,
    GetTopUsersInit,
    GetTopUsersSuccess,
    GetTopUsersFailure
} from '../actions/dashboard.actions';

import { TopInterests } from '../models/top-interests';
import { TopUsers } from '../models/top-users';
import {
  topInterests,
  getTopInterestsError,
  topUsers,
  getTopUsersError,
} from '../../../shared/mocks';

describe('GetTopInterestsReducer and GetTopUsersReducer', () => {
  describe('null action', () => {
    it('should return the default state', () => {
      const action = {} as any;

      const result = interestsReducer(null, action);

      /**
       * Snapshot tests are a quick way to validate
       * the state produced by a reducer since
       * its plain JavaScript object. These snapshots
       * are used to validate against the current state
       * if the functionality of the reducer ever changes.
       */
      expect(result).toMatchSnapshot();
    });
  });

  describe('[ Dashboard ] Get Top Interests Init', () => {
    it('should change pending to true in TopInterests state', () => {
      const createAction = new GetTopInterestsInit();

      const result = interestsReducer(fromTopInterests.initialState, createAction);

      expect(result).toEqual({
        ...fromTopInterests.initialState,
        pending: true
      });
    });
  });

  describe('[Dashboard] Get Top Interests Success', () => {
    it('should toggle TopInterests state and topInterests should be defined', () => {
      const action = new GetTopInterestsSuccess(topInterests as TopInterests);
      const result = interestsReducer(fromTopInterests.initialState, action);

      expect(result).toEqual({
        ...fromTopInterests.initialState,
        topInterests: topInterests,
        pending: false
      });
    });
  });

  describe('[Dashboard] Get Top Interests Failure', () => {
    it('should toggle TopInterests state and topInterests should be null', () => {
      const action = new GetTopInterestsFailure(getTopInterestsError);
      const result = interestsReducer(fromTopInterests.initialState, action);

      expect(result).toEqual({
        ...fromTopInterests.initialState,
        topInterests: null,
        error: getTopInterestsError,
        pending: false
      });
    });
  });

  describe('null action', () => {
    it('should return the default state', () => {
      const action = {} as any;

      const result = usersReducer(null, action);

      /**
       * Snapshot tests are a quick way to validate
       * the state produced by a reducer since
       * its plain JavaScript object. These snapshots
       * are used to validate against the current state
       * if the functionality of the reducer ever changes.
       */
      expect(result).toMatchSnapshot();
    });
  });

  describe('[ Dashboard ] Get Top Users Init', () => {
    it('should change pending to true in TopUsers state', () => {
      const createAction = new GetTopUsersInit();

      const result = usersReducer(fromTopUsers.initialState, createAction);

      expect(result).toEqual({
        ...fromTopUsers.initialState,
        pending: true
      });
    });
  });

  describe('[Dashboard] Get Top Users Success', () => {
    it('should toggle TopUsers state and topUsers should be defined', () => {
      const action = new GetTopUsersSuccess(topUsers as TopUsers);
      const result = usersReducer(fromTopUsers.initialState, action);

      expect(result).toEqual({
        ...fromTopUsers.initialState,
        topUsers: topUsers,
        pending: false
      });
    });
  });

  describe('[Dashboard] Get Top Users Failure', () => {
    it('should toggle TopUsers state and topUsers should be null', () => {
      const action = new GetTopUsersFailure(getTopUsersError);
      const result = usersReducer(fromTopUsers.initialState, action);

      expect(result).toEqual({
        ...fromTopUsers.initialState,
        topUsers: null,
        error: getTopUsersError,
        pending: false
      });
    });
  });
});
