import produce from 'immer';
import { MeetingStatistics } from '../models/meeting-statistics';

import {
  DashboardActionsUnion,
  DashboardActionTypes
} from '../actions/dashboard.actions';

export interface State {
  pending: boolean;
  error: string;
  meetingStatistics: MeetingStatistics;
  requestedPeriod: string;
}

export const initialState: State = {
  pending: false,
  error: null,
  meetingStatistics: null,
  requestedPeriod: null
};

export function reducer(
  state: State = initialState,
  action: DashboardActionsUnion
): State {
  return produce(state, draft => {
    switch (action.type) {
      case DashboardActionTypes.LoadDashboards: {
        return initialState;
      }

      case DashboardActionTypes.GetMeetingStatisticsInit: {
        draft.error = null;
        draft.meetingStatistics = null;
        draft.pending = true;
        draft.requestedPeriod = action.payload.period;
        return;
      }

      case DashboardActionTypes.GetMeetingStatisticsSuccess: {
        draft.error = null;
        draft.meetingStatistics = action.payload;
        draft.pending = false;
        return;
      }

      case DashboardActionTypes.GetMeetingStatisticsFailure: {
        draft.error = action.payload;
        draft.meetingStatistics = null;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getMeetingStatistics = (state: State) => state.meetingStatistics;
export const getRequestedPeriod = (state: State) => state.requestedPeriod;
