import { reducer } from './quick-actions.reducer';
import * as fromQuickActions from './quick-actions.reducer';

import {
  GetQuickActionsInit,
  GetQuickActionsSuccess,
  GetQuickActionsFailure
} from '../actions/dashboard.actions';

import { QuickActions } from '../models/quick-actions';
import { quickStats, getQuickActionsError } from '../../../shared/mocks';

describe('GetQuickActionsReducer', () => {
  describe('null action', () => {
    it('should return the default state', () => {
      const action = {} as any;

      const result = reducer(null, action);

      /**
       * Snapshot tests are a quick way to validate
       * the state produced by a reducer since
       * its plain JavaScript object. These snapshots
       * are used to validate against the current state
       * if the functionality of the reducer ever changes.
       */
      expect(result).toMatchSnapshot();
    });
  });

  describe('[ Dashboard ] Get Quick Actions Init', () => {
    it('should change pending to true in quickActions state', () => {
      const createAction = new GetQuickActionsInit();

      const result = reducer(fromQuickActions.initialState, createAction);

      expect(result).toEqual({
        ...fromQuickActions.initialState,
        pending: true
      });
    });
  });

  describe('[Dashboard] Get Quick Actions Success', () => {
    it('should toggle quickActions state and quickStats should be defined', () => {
      const action = new GetQuickActionsSuccess(quickStats as QuickActions);
      const result = reducer(fromQuickActions.initialState, action);

      expect(result).toEqual({
        ...fromQuickActions.initialState,
        quickStats: quickStats,
        pending: false
      });
    });
  });

  describe('[Dashboard] Get Quick Actions Failure', () => {
    it('should toggle quickActions state and quickStats should be null', () => {
      const action = new GetQuickActionsFailure(getQuickActionsError);
      const result = reducer(fromQuickActions.initialState, action);

      expect(result).toEqual({
        ...fromQuickActions.initialState,
        quickStats: null,
        error: getQuickActionsError,
        pending: false
      });
    });
  });
});
