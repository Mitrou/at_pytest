import produce from 'immer';

import { DashboardActionsUnion, DashboardActionTypes } from '../actions/dashboard.actions';

export interface State {

}

export const initialState: State = {};

export function reducer(state: State = initialState, action: DashboardActionsUnion): State {
  return produce(state, (draft) => {
    switch (action.type) {
      case DashboardActionTypes.LoadDashboards: {
        return initialState;
      }
    }
  });
}
