import { reducer } from './user-statistics.reducer';
import * as fromUserStats from './user-statistics.reducer';

import {
  GetUserStatisticsInit,
  GetUserStatisticsSuccess,
  GetUserStatisticsFailure
} from '../actions/dashboard.actions';

import { UserStatistics } from '../models/user-statistics';
import {
  userStatsRequest,
  userStats,
  getUserStatisticsError
} from '../../../shared/mocks/user-statistics';

describe('GetUserStatisticsReducer', () => {
  describe('null action', () => {
    it('should return the default state', () => {
      const action = {} as any;

      const result = reducer(null, action);

      /**
       * Snapshot tests are a quick way to validate
       * the state produced by a reducer since
       * its plain JavaScript object. These snapshots
       * are used to validate against the current state
       * if the functionality of the reducer ever changes.
       */
      expect(result).toMatchSnapshot();
    });
  });

  describe('[ Dashboard ] Get User Statistics Init', () => {
    it('should change pending to true in userStatistics state', () => {
      const createAction = new GetUserStatisticsInit(userStatsRequest);

      const result = reducer(fromUserStats.initialState, createAction);

      expect(result).toEqual({
        ...fromUserStats.initialState,
        pending: true,
        requestedPeriod: userStatsRequest.period
      });
    });
  });

  describe('[Dashboard] Get User Statistics Success', () => {
    it('should toggle userStatistics state and userStatictics should be defined', () => {
      const action = new GetUserStatisticsSuccess(userStats as UserStatistics);
      const result = reducer(fromUserStats.initialState, action);

      expect(result).toEqual({
        ...fromUserStats.initialState,
        userStatistics: userStats,
        pending: false
      });
    });
  });

  describe('[Dashboard] Get User Statistics Failure', () => {
    it('should toggle userStatistics state and userStatictics should be null', () => {
      const action = new GetUserStatisticsFailure(getUserStatisticsError);
      const result = reducer(fromUserStats.initialState, action);

      expect(result).toEqual({
        ...fromUserStats.initialState,
        userStatistics: null,
        error: getUserStatisticsError,
        pending: false
      });
    });
  });
});
