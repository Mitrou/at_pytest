import { Component, OnInit, Input } from '@angular/core';
import { TopUsers } from '../../../models/top-users';

@Component({
  selector: 'wml-top-users',
  templateUrl: './top-users.component.html'
})
export class TopUsersComponent implements OnInit {
  @Input() topUsers: TopUsers;
  @Input() pending: boolean;

  constructor() { }

  ngOnInit() { }

}
