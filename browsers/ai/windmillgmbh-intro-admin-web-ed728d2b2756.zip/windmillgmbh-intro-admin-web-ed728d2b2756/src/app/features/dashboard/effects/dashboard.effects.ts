import { Injectable } from '@angular/core';

import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';

import { Observable, of } from 'rxjs';
import { exhaustMap, map, tap, catchError } from 'rxjs/operators';

import {
  DashboardActionTypes,
  LoadDashboards,
  GetUserStatisticsInit,
  GetUserStatisticsSuccess,
  GetUserStatisticsFailure,
  GetMeetingStatisticsInit,
  GetMeetingStatisticsSuccess,
  GetMeetingStatisticsFailure,
  GetQuickActionsInit,
  GetQuickActionsSuccess,
  GetQuickActionsFailure,
  GetTopInterestsInit,
  GetTopInterestsSuccess,
  GetTopInterestsFailure,
  GetTopUsersInit,
  GetTopUsersSuccess,
  GetTopUsersFailure
} from '../actions/dashboard.actions';

import { LocalStorageService } from 'ngx-webstorage';
import { DashboardService } from '../dashboard.service';

import { QuickActions } from '../models/quick-actions';
import {
  UserStatistics,
  UserStatisticsRequest
} from '../models/user-statistics';

import {
  MeetingStatistics,
  MeetingStatisticsRequest
} from '../models/meeting-statistics';
import { TopInterests } from '../models/top-interests';
import { TopUsers } from '../models/top-users';

@Injectable()
export class DashboardEffects {
  @Effect()
  effect$ = this.actions$.pipe(ofType(DashboardActionTypes.LoadDashboards));

  @Effect()
  getUserStatistics$: Observable<Action> = this.actions$.pipe(
    ofType<GetUserStatisticsInit>(DashboardActionTypes.GetUserStatisticsInit),
    map(action => action.payload),
    exhaustMap((request: UserStatisticsRequest) =>
      this.dashboardService.getUserStatistics(request).pipe(
        map(
          (response: UserStatistics) => new GetUserStatisticsSuccess(response)
        ),
        catchError(e => of(new GetUserStatisticsFailure(e.error.error)))
      )
    )
  );

  @Effect({ dispatch: false })
  getUserStatisticsSuccess$: Observable<any> = this.actions$.pipe(
    ofType<GetUserStatisticsSuccess>(
      DashboardActionTypes.GetUserStatisticsSuccess
    ),
    map(action => action.payload),
    tap((payload: UserStatistics) => {
      this.localStorageService.store('userStatistics', payload);
    })
  );

  @Effect()
  getMeetingStatistics$: Observable<Action> = this.actions$.pipe(
    ofType<GetMeetingStatisticsInit>(
      DashboardActionTypes.GetMeetingStatisticsInit
    ),
    map(action => action.payload),
    exhaustMap((request: MeetingStatisticsRequest) =>
      this.dashboardService.getMeetingStatistics(request).pipe(
        map(
          (response: MeetingStatistics) =>
            new GetMeetingStatisticsSuccess(response)
        ),
        catchError(e => of(new GetMeetingStatisticsFailure(e.error.error)))
      )
    )
  );

  @Effect({ dispatch: false })
  getMeetingStatisticsSuccess$: Observable<any> = this.actions$.pipe(
    ofType<GetMeetingStatisticsSuccess>(
      DashboardActionTypes.GetMeetingStatisticsSuccess
    ),
    map(action => action.payload),
    tap((payload: MeetingStatistics) => {
      this.localStorageService.store('meetingStatistics', payload);
    })
  );

  @Effect()
  getQuickActions$: Observable<Action> = this.actions$.pipe(
    ofType<GetQuickActionsInit>(
        DashboardActionTypes.GetQuickActionsInit
    ),
    exhaustMap(() =>
      this.dashboardService.getQuickActions().pipe(
        map(
          (response: QuickActions) =>
            new GetQuickActionsSuccess(response)
        ),
        catchError(e => of(new GetQuickActionsFailure(e.error.error)))
      )
    )
  );

  @Effect({ dispatch: false })
  getQuickActionsSuccess$: Observable<any> = this.actions$.pipe(
    ofType<GetQuickActionsSuccess>(
        DashboardActionTypes.GetQuickActionsSuccess
    ),
    map(action => action.payload),
    tap((payload: QuickActions) => {
      this.localStorageService.store('quickActions', payload);
    })
  );

  // Top interests effects
  @Effect()
  getTopInterests$: Observable<Action> = this.actions$.pipe(
    ofType<GetTopInterestsInit>(
        DashboardActionTypes.GetTopInterestsInit
    ),
    exhaustMap(() =>
      this.dashboardService.getTopInterests().pipe(
        map(
          (response: TopInterests) =>
            new GetTopInterestsSuccess(response)
        ),
        catchError(e => of(new GetTopInterestsFailure(e.error.error)))
      )
    )
  );

  // Top Users effects
  @Effect()
  getTopUsers$: Observable<Action> = this.actions$.pipe(
    ofType<GetTopUsersInit>(
        DashboardActionTypes.GetTopUsersInit
    ),
    exhaustMap(() =>
      this.dashboardService.getTopUsers().pipe(
        map(
          (response: TopUsers) =>
            new GetTopUsersSuccess(response)
        ),
        catchError(e => of(new GetTopUsersFailure(e.error.error)))
      )
    )
  );

  constructor(
    private actions$: Actions,
    private dashboardService: DashboardService,
    private localStorageService: LocalStorageService
  ) {}
}
