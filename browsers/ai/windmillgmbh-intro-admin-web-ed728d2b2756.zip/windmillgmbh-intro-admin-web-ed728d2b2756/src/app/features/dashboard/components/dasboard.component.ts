import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { QuickActions } from '../models/quick-actions';

@Component({
  selector: 'wml-dashboard',
  templateUrl: './dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent {
  @Input() quickActionsStats: QuickActions;
  @Input() pendingQuickActions: boolean;
}
