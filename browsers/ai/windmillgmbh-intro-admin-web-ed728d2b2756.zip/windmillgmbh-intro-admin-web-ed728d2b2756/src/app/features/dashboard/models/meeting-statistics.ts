export interface MeetingStats {
  status: string;
  count: number;
  percentage: number;
}

export interface MeetingStatisticsStats {
  counts: number[];
  percentages: number[];
  statuses: string[];
}

export interface MeetingStatistics {
  totalMeetings: number;
  newMeetings: number;
  trend: number;
  stats: MeetingStats[];
}

export interface MeetingStatisticsRequest {
  period: string;
}

export interface StructuredMeetingStatistics {
  totalMeetings: number;
  newMeetings: number;
  trend: number;
  stats: MeetingStatisticsStats;
}

export interface DonaughtChartData {
  count: number[];
  percentage: number[];
  status: string[];
}

export interface HeaderStats {
  total: number;
  new: number;
  trend: number;
}
