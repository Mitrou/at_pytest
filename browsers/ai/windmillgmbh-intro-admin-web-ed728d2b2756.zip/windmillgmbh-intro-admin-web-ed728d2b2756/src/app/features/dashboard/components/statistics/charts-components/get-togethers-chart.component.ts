import { Component, Input, Output, EventEmitter } from '@angular/core';
import {
  StructuredMeetingStatistics,
  HeaderStats
} from '../../../models/meeting-statistics';

@Component({
  selector: 'wml-get-togethers-chart',
  templateUrl: './get-togethers-chart.component.html'
})
export class GetTogethersChartComponent {
  @Input() pending: boolean;
  @Input() meetingStatsPeriod: string;
  @Input() meetingStats;
  @Input()
  set structMeetingStats(meetingStatistics: StructuredMeetingStatistics) {
    this.meetingStatistics = meetingStatistics;

    if (meetingStatistics) {
      this.doughnutChartData = meetingStatistics.stats.counts;

      this.doughnutChartLabels = meetingStatistics.stats.statuses;

      this.headerStats = {
        total: this.meetingStatistics.totalMeetings,
        new: this.meetingStatistics.newMeetings,
        trend: this.meetingStatistics.trend
      } as HeaderStats;
    }
  }
  meetingStatistics: StructuredMeetingStatistics;

  @Output() selectPeriod = new EventEmitter<any>();
  headerStats: HeaderStats;
  readonly periods: string[] = ['1 Year', '6 Months', '3 Months', 'Month'];
  // Doughnut
  doughnutChartLabels: string[];
  doughnutChartData: number[];
  public doughnutChartType = 'doughnut';

  public doughnutChartColors: Array<any> = [
    {
      // grey
      // backgroundColor: 'rgba(148,159,177,0.2)',
      // borderColor: 'rgba(148,159,177,1)',
      // borderWidth: 0,
      // hoverBackgroundColor: 'rgba(148,159,177,1)',
      // hoverBorderColor: '#fff',
      // hoverBorderWidth: 0;
    }
  ];

  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

  onPeriodSelected(period: string) {
    this.selectPeriod.emit(period);
  }
}
