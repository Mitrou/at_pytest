import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { reducers } from './reducers';
import { DashboardEffects } from './effects/dashboard.effects';
import { DashboardRoutingModule } from './dashboard-routing.module';

import { CoreModule } from '../../core/core.module';
import { SharedModule } from '@shared/shared.module';
import { DashboardPageComponent } from './containers/dashboard-page.component';
import { DashboardComponent } from './components/dasboard.component';
import { StatisticsComponent } from './containers/statistics.component';
import { UsersChartComponent } from './components/statistics/charts-components/users-chart.component';
import { ChartHeaderComponent } from './components/statistics/charts-components/chart-header.component';
import { GetTogethersChartComponent } from './components/statistics/charts-components/get-togethers-chart.component';
import { TopInterestsComponent } from './components/top-data/top-interests/top-interests.component';
import { TopDataComponent } from './containers/top-data.component';
import { QuickActionsComponent } from './components/quick-actions.component';
import { TopUsersComponent } from './components/top-data/top-users/top-users.component';


export const COMPONENTS = [
  DashboardPageComponent,
  DashboardComponent,
  StatisticsComponent,
  UsersChartComponent,
  GetTogethersChartComponent,
  ChartHeaderComponent,
  TopInterestsComponent,
  TopUsersComponent,
  TopDataComponent,
  QuickActionsComponent
];

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,

    /**
     * StoreModule.forFeature is used for composing state
     * from feature modules. These modules can be loaded
     * eagerly or lazily and will be dynamically added to
     * the existing state.
     */
    StoreModule.forFeature('dashboard', reducers),

    /**
     * Effects.forFeature is used to dashboard effects
     * from feature modules. Effects can be loaded
     * eagerly or lazily and will be started immediately.
     *
     * All Effects will only be instantiated once regardless of
     * whether they are registered once or multiple times.
     */
    EffectsModule.forFeature([DashboardEffects]),

    CoreModule,
    SharedModule
  ],
  declarations: COMPONENTS,
  exports: COMPONENTS
})
export class DashboardModule {}
