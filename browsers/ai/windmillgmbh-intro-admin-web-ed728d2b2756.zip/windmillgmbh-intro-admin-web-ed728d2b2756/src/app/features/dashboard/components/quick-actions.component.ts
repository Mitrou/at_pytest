import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { QuickActions } from '../models/quick-actions';

@Component({
  selector: 'wml-quick-actions',
  templateUrl: './quick-actions.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QuickActionsComponent {
  @Input() quickStats: QuickActions;
  @Input() pending: boolean;

  sectionsInfo = [
    {
      statsDescription: 'possibleMatches',
      quickStatsKey: 'possibleMatches',
      buttonText: 'Match Users'
    },
    {
      statsDescription: 'pendingFeedback',
      quickStatsKey: 'pendingFeedback',
      buttonText: 'Send Reminder'
    }
  ];
}
