import {
  createSelector,
  createFeatureSelector,
  ActionReducerMap
} from '@ngrx/store';

import * as fromRoot from '../../../reducers/index';
import * as fromDashboard from './dashboard.reducer';
import * as fromUserStatistics from './user-statistics.reducer';
import * as fromMeetingStatistics from './meeting-statistics.reducer';
import * as fromQuickActions from './quick-actions.reducer';
import * as fromTopInterests from './top-interests.reducer';
import * as fromTopUsers from './top-users.reducer';

import {
  StructuredMeetingStatistics,
  MeetingStatisticsStats
} from '../models/meeting-statistics';
import {
  UserStatisticsLabelsData,
  StructuredUserStatistics
} from '../models/user-statistics';

export interface DashboardState {
  dashboard: fromDashboard.State;
  userStatistics: fromUserStatistics.State;
  meetingStatistics: fromMeetingStatistics.State;
  quickActions: fromQuickActions.State;
  topInterests: fromTopInterests.State;
  topUsers: fromTopUsers.State;
}

export interface State extends fromRoot.State {
  dashboard: DashboardState;
}

export const reducers: ActionReducerMap<DashboardState> = {
  dashboard: fromDashboard.reducer,
  userStatistics: fromUserStatistics.reducer,
  meetingStatistics: fromMeetingStatistics.reducer,
  quickActions: fromQuickActions.reducer,
  topInterests: fromTopInterests.reducer,
  topUsers: fromTopUsers.reducer
};

export const getDashboardState = createFeatureSelector<DashboardState>(
  'dashboard'
);

// export const getDashboardPropState = createSelector(
//   getDashboardState,
//   state => state.prop
// );

// User Statistics selectors
export const getUserStatisticsState = createSelector(
  getDashboardState,
  (state: DashboardState) => state.userStatistics
);

export const getUserStatisticsPendingState = createSelector(
  getUserStatisticsState,
  state => state.pending
);

export const getUserStatisticsValueState = createSelector(
  getUserStatisticsState,
  state => state.userStatistics
);

export const getUserStatisticsPeriod = createSelector(
  getUserStatisticsState,
  state => state.requestedPeriod
);

export const getDashboardUserStatistics = createSelector(
  getUserStatisticsValueState,
  state => {
    if (!state) {
      return undefined;
    }
    const stats = state.stats;

    const statsLabels: string[] = [];
    const statsData: number[] = [];

    stats.forEach(item => {
      statsLabels.push(item.key);
      statsData.push(item.value);
    });

    const structuredStats = {
      labels: statsLabels,
      data: statsData
    } as UserStatisticsLabelsData;

    const structuredUserStatistics = {
      totalUsers: state.totalUsers,
      newUsers: state.newUsers,
      trend: state.trend,
      stats: structuredStats
    } as StructuredUserStatistics;

    return structuredUserStatistics;
  }
);

// Meeting Statistics selectors
export const getMeetingStatisticsState = createSelector(
  getDashboardState,
  (state: DashboardState) => state.meetingStatistics
);

export const getMeetingStatisticsPendingState = createSelector(
  getMeetingStatisticsState,
  state => state.pending
);

export const getMeetingStatisticsValueState = createSelector(
  getMeetingStatisticsState,
  state => state.meetingStatistics
);

export const getMeetingStatisticsPeriodState = createSelector(
  getMeetingStatisticsState,
  state => state.requestedPeriod
);

export const getDashboardMeetingStatistics = createSelector(
  getMeetingStatisticsValueState,
  state => {
    if (!state) {
      return undefined;
    }
    const stats = state.stats;

    const statsCounts: number[] = [];
    const statsPercentage: number[] = [];
    const statsStatus: string[] = [];

    stats.forEach(item => {
      statsCounts.push(item.count);
      statsPercentage.push(item.percentage);
      statsStatus.push(item.status);
    });

    const structuredStats = {
      counts: statsCounts,
      percentages: statsPercentage,
      statuses: statsStatus
    } as MeetingStatisticsStats;

    const structuredUserStatistics = {
      totalMeetings: state.totalMeetings,
      newMeetings: state.newMeetings,
      trend: state.trend,
      stats: structuredStats
    } as StructuredMeetingStatistics;

    return structuredUserStatistics;
  }
);

// Quick Actions selectors
export const getQuickActionsState = createSelector(
  getDashboardState,
  (state: DashboardState) => state.quickActions
);

export const getQuickActionsStatsState = createSelector(
  getQuickActionsState,
  state => state.quickStats
);

export const getQuickActionsPendingState = createSelector(
  getQuickActionsState,
  state => state.pending
);

// Top Interests selectors
export const getTopInterestsState = createSelector(
  getDashboardState,
  (state: DashboardState) => state.topInterests
);

export const getTopInterestsValueState = createSelector(
  getTopInterestsState,
  state => state.topInterests
);

export const getTopInterestsPendingState = createSelector(
  getTopInterestsState,
  state => state.pending
);

// Top Users selectors
export const getTopUsersState = createSelector(
  getDashboardState,
  (state: DashboardState) => state.topUsers
);

export const getTopUsersValueState = createSelector(
  getTopUsersState,
  state => state.topUsers
);

export const getTopUsersPendingState = createSelector(
  getTopUsersState,
  state => state.pending
);
