export interface Interest {
  name: string;
  userCount: number;
  trend: number;
  percentage: number;
}

export interface TopInterests {
  totalUsers: number;
  topInterest: Interest[];
}
