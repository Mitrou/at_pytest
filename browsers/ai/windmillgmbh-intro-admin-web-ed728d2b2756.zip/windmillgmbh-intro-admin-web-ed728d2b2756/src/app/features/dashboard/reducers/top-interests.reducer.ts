import produce from 'immer';
import { TopInterests } from '../models/top-interests';

import {
  DashboardActionsUnion,
  DashboardActionTypes
} from '../actions/dashboard.actions';

export interface State {
  pending: boolean;
  error: string;
  topInterests: TopInterests;
}

export const initialState: State = {
  pending: false,
  error: null,
  topInterests: null
};

export function reducer(
  state: State = initialState,
  action: DashboardActionsUnion
): State {
  return produce(state, draft => {
    switch (action.type) {
      case DashboardActionTypes.GetTopInterestsInit: {
        draft.error = null;
        draft.topInterests = null;
        draft.pending = true;
        return;
      }

      case DashboardActionTypes.GetTopInterestsSuccess: {
        draft.error = null;
        draft.topInterests = action.payload;
        draft.pending = false;
        return;
      }

      case DashboardActionTypes.GetTopInterestsFailure: {
        draft.error = action.payload;
        draft.topInterests = null;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
export const getTopInterests = (state: State) => state.topInterests;
