import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  UserStatistics,
  UserStatisticsRequest
} from './models/user-statistics';
import {
  MeetingStatistics,
  MeetingStatisticsRequest
} from './models/meeting-statistics';
import { TopInterests } from './models/top-interests';
import { QuickActions } from './models/quick-actions';
import { TopUsers } from './models/top-users';

import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  constructor(protected http: HttpClient) {}

  getUserStatistics(periodInfo: UserStatisticsRequest): Observable<any> {
    return this.http
      .get<UserStatistics>(`/api/user/statistics`, {
        observe: 'response',
        params: {
          _period: periodInfo.period.toString().toUpperCase()
        }
      })
      .pipe(
        map(response => {
          return response.body;
        })
      );
  }

  getMeetingStatistics(periodInfo: MeetingStatisticsRequest): Observable<any> {
    return this.http
      .get<MeetingStatistics>(`/api/meeting/statistics`, {
        observe: 'response',
        params: {
          _period: periodInfo.period.toString().toUpperCase()
        }
      })
      .pipe(
        map(response => {
          return response.body;
        })
      );
  }

  getTopInterests(): Observable<any> {
    return this.http.get<TopInterests>('/api/user/top-interests');
  }

  getTopUsers(): Observable<any> {
    return this.http.get<TopUsers>('/api/user/top-users');
  }

  getQuickActions(): Observable<any> {
    return this.http.get<QuickActions>('/api/meeting/quick-stats');
  }
}
