import { Component, OnInit } from '@angular/core';

import { QuickActions } from '../models/quick-actions';
import { Observable } from 'rxjs';

import { Store } from '@ngrx/store';

import * as fromDashboard from '../reducers/index';
import * as DashboardActions from '../actions/dashboard.actions';



@Component({
  selector: 'wml-dashboard-page',
  templateUrl: './dashboard-page.component.html'
})
export class DashboardPageComponent implements OnInit {
  quickActionsStats$: Observable<QuickActions>;
  pendingQuickActions$: Observable<boolean>;

  constructor(private store: Store<fromDashboard.State>) {
    // get quick actions related data from store
    this.quickActionsStats$ = this.store.select(
      fromDashboard.getQuickActionsStatsState
    );

    this.pendingQuickActions$ = this.store.select(
      fromDashboard.getQuickActionsPendingState
    );
  }

  ngOnInit() {
    this.store.dispatch(new DashboardActions.GetQuickActionsInit());
  }
}

