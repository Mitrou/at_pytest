export interface TimeStatictic {
  key: string;
  value: number;
}

export interface UserStatisticsLabelsData {
  labels: string[];
  data: number[];
}

export interface UserStatistics {
  totalUsers: number;
  newUsers: number;
  trend: number;
  stats: TimeStatictic[];
}

export interface UserStatisticsRequest {
  period: string;
}

export interface StructuredUserStatistics {
  totalUsers: number;
  newUsers: number;
  trend: number;
  stats: UserStatisticsLabelsData;
}

export interface LineChartData {
  data: number[];
  label: string;
}

export interface HeaderStats {
  total: number;
  new: number;
  trend: number;
}
