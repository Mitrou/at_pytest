import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import {
  AddMeetingSpot,
  AddMeetingSpotFailure,
  AddMeetingSpotSuccess,

  DeleteMeetingSpot,
  DeleteMeetingSpotFailure,
  DeleteMeetingSpotSuccess,

  MeetingSpotsActionTypes,
  LoadMeetingSpot,
  LoadMeetingSpotFailure,
  LoadMeetingSpotSuccess,

  LoadMeetingSpots,
  LoadMeetingSpotsFailure,
  LoadMeetingSpotsSuccess,

  NavigateToUpdateMeetingSpotPage,

  UpdateMeetingSpot,
  UpdateMeetingSpotFailure,
  UpdateMeetingSpotSuccess

} from '../actions/meeting-spots.actions';

import { MeetingSpotsService } from '../services/meeting-spots.service';
import { Observable, of, of as observableOf } from 'rxjs';
import { Action, select, Store } from '@ngrx/store';
import { catchError, exhaustMap, map, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { MeetingSpotsMainState } from '../reducers';
import * as fromMeetingSpots from '../reducers';

import * as fromRoot from '../../../reducers';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';
import { Router } from '@angular/router';
import { MeetingSpot } from '../models/meeting-spots';


@Injectable()
export class MeetingSpotsEffects {


  @Effect()
  loadMeetingSpotsEffect$: Observable<Action> = this.actions$.pipe(
    ofType<LoadMeetingSpots>(
      MeetingSpotsActionTypes.LoadMeetingSpots
    ),
    switchMap(({pageInfo, sortInfo, filters}) =>
      this.meetingSpotService
        .getMeetingSpots(pageInfo, sortInfo, filters)
        .pipe(
          map(meetingSpots => new LoadMeetingSpotsSuccess(meetingSpots)),
          catchError(error => observableOf(new LoadMeetingSpotsFailure(error)))
        )
    )
  );

  @Effect()
  addMeetingSpot$: Observable<Action> = this.actions$.pipe(
    ofType<AddMeetingSpot>(MeetingSpotsActionTypes.AddMeetingSpot),
    map((action) => action.payload),
    exhaustMap((meetingSpot: MeetingSpot) =>
      this.meetingSpotService.addMeetingSpot(meetingSpot)
        .pipe(
          map((payload: MeetingSpot) => new AddMeetingSpotSuccess(payload)),
          catchError((e) => of(new AddMeetingSpotFailure(e.error.error)))
        )
    )
  );

  @Effect()
  deleteMeetingSpot$: Observable<Action> = this.actions$.pipe(
    ofType<DeleteMeetingSpot>(MeetingSpotsActionTypes.DeleteMeetingSpot),
    map((action) => action.payload),
    exhaustMap((id: number) =>
      this.meetingSpotService.deleteMeetingSpot(id)
        .pipe(
          map(() => new DeleteMeetingSpotSuccess(id)),
          catchError((e) => of(new DeleteMeetingSpotFailure(e.error.error)))
        )
    )
  );

  @Effect()
  loadMeetingSpot$: Observable<Action> = this.actions$.pipe(
    ofType<LoadMeetingSpot>(MeetingSpotsActionTypes.LoadMeetingSpot),
    withLatestFrom(
      this.store.pipe(select(fromMeetingSpots.getSelectedMeetingSpotsId)),
      (action, id: number) => id
    ),
    switchMap((id) =>
      this.meetingSpotService.loadMeetingSpot(id)
        .pipe(
          map((payload: MeetingSpot) => new LoadMeetingSpotSuccess(payload)),
          catchError((e) => of(new LoadMeetingSpotFailure(e.error.error)))
        )
    )
  );

  @Effect({dispatch: false})
  loadMeetingSpotFailure$: Observable<any> = this.actions$.pipe(
    ofType<LoadMeetingSpotFailure>(MeetingSpotsActionTypes.LoadMeetingSpotFailure),
    tap(() => {
      this.router.navigate(['/404']);
    })
  );

  @Effect()
  updateMeetingSpot$: Observable<Action> = this.actions$.pipe(
    ofType<UpdateMeetingSpot>(MeetingSpotsActionTypes.UpdateMeetingSpot),
    map((action) => action.payload),
    exhaustMap((meetingSpot: MeetingSpot) =>
      this.meetingSpotService.updateMeetingSpot(meetingSpot)
        .pipe(
          map((payload: MeetingSpot) => new UpdateMeetingSpotSuccess(payload)),
          catchError((e) => of(new UpdateMeetingSpotFailure(e.error.error)))
        )
    )
  );

  @Effect({dispatch: false})
  navigateToMeetingSpotsPage$: Observable<any> = this.actions$.pipe(
    ofType(
      MeetingSpotsActionTypes.AddMeetingSpotSuccess,
      MeetingSpotsActionTypes.UpdateMeetingSpotSuccess
    ),
    withLatestFrom(
      this.store.pipe(select(fromRoot.getRouterSerializedState)),
      (action, routerState: RouterStateUrl) => routerState.params.universityId
    ),
    tap((universityId) => {
      this.router.navigate(['/meeting-spot']);
    })
  );

  @Effect({dispatch: false})
  navigateToUpdateMeetingSpotPage$: Observable<any> = this.actions$.pipe(
    ofType<NavigateToUpdateMeetingSpotPage>(MeetingSpotsActionTypes.NavigateToUpdateMeetingSpotPage),
    withLatestFrom(
      this.store.pipe(select(fromRoot.getRouterSerializedState)),
      (action: NavigateToUpdateMeetingSpotPage, routerState: RouterStateUrl) => ({
        meetingSpotId: action.payload
      })
    ),
    tap(({meetingSpotId}) => {
      this.router.navigate(['/meeting-spot', meetingSpotId, 'update']);
    })
  );

  constructor(
    private store: Store<MeetingSpotsMainState>,
    private router: Router,
    private actions$: Actions,
    private meetingSpotService: MeetingSpotsService) {
  }
}
