import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';
import * as fromMeetingSpots from '../../reducers/index';
import { MeetingSpot } from '../../models/meeting-spots';
import { AddMeetingSpot } from '../../actions/meeting-spots.actions';


@Component({
  selector: 'wml-meeting-spot-add-panel',
  templateUrl: './meeting-spot-add-panel.component.html'
})
export class MeetingSpotAddPanelComponent {
  pending$ = this.store.pipe(select(fromMeetingSpots.getMeetingSpotUpdatePanelPending));
  error$ = this.store.pipe(select(fromMeetingSpots.getMeetingSpotUpdatePanelError));

  constructor(private store: Store<fromMeetingSpots.MeetingSpotsMainState>) {
  }

  onSubmit($event: MeetingSpot) {
    this.store.dispatch(new AddMeetingSpot($event));
  }
}
