import produce from 'immer';

import { MeetingSpotsActionTypes, MeetingSpotsActions } from '../actions/meeting-spots.actions';

export interface State {
  error: string | null;
  pending: boolean;
}

export const initialState: State = {
  error: null,
  pending: false,
};

export function reducer(state = initialState, action: MeetingSpotsActions): State {
  return produce(state, (draft) => {
    switch (action.type) {
      case MeetingSpotsActionTypes.LoadMeetingSpot:
      case MeetingSpotsActionTypes.UpdateMeetingSpot: {
        draft.error = null;
        draft.pending = true;
        return;
      }

      case MeetingSpotsActionTypes.LoadMeetingSpotSuccess:
      case MeetingSpotsActionTypes.UpdateMeetingSpotSuccess: {
        draft.error = null;
        draft.pending = false;
        return;
      }

      case MeetingSpotsActionTypes.LoadMeetingSpotFailure:
      case MeetingSpotsActionTypes.UpdateMeetingSpotFailure: {
        draft.error = action.payload;
        draft.pending = false;
        return;
      }
    }
  });
}

export const getError = (state: State) => state.error;
export const getPending = (state: State) => state.pending;
