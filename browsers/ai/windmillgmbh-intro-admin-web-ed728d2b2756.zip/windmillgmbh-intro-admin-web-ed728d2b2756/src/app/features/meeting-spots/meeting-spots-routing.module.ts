import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MeetingSpotsPageComponent } from './containers/meeting-spots-page.component';
import { OpenDrawerGuard } from '../../core/services/open-drawer-guard.service';
import { CloseDrawerGuard } from '../../core/services/close-drawer-guard.service';
import { MeetingSpotUpdatePanelComponent } from './containers/meeting-spot-update-panel/meeting-spot-update-panel.component';
import { MeetingSpotInStoreGuard } from './services/meeting-spot-in-store.guard';
import { MeetingSpotAddPanelComponent } from './containers/meeting-spot-add-panel/meeting-spot-add-panel.component';


const routes: Routes = [
  {
    path: '',
    component: MeetingSpotsPageComponent,
    children: [
      {
        path: 'add',
        component: MeetingSpotAddPanelComponent,
        canActivate: [OpenDrawerGuard],
        canDeactivate: [CloseDrawerGuard]
      },
      {
        path: ':meetingSpotId/update',
        component: MeetingSpotUpdatePanelComponent,
        canActivate: [MeetingSpotInStoreGuard, OpenDrawerGuard],
        canDeactivate: [CloseDrawerGuard]
      }
    ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MeetingSpotsRoutingModule {
}
