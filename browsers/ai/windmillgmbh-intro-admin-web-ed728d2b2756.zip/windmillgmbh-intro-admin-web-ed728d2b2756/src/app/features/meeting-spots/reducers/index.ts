import * as fromMeetingSpots from './meeting-spots.reducer';
import {
  getCount,
  getIsLoading,
  getLimit,
  getOffset,
  meetingSpotEntityAdapter,
  getSelectedMeetingSpotId,
  MeetingSpotsState
} from './meeting-spots.reducer';
import * as fromRoot from '../../../reducers/index';

import { ActionReducerMap, createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromMeetingSpotUpdatePanel from './meeting-spot-update-panel.reducer';


export interface MeetingSpotsMainState {
  meetingSpots: fromMeetingSpots.MeetingSpotsState;
  meetingSpotUpdatePanel: fromMeetingSpotUpdatePanel.State;
}

export interface State extends fromRoot.State {
  meetingSpots: MeetingSpotsMainState;
}

export const  meetingSpotsReducers: ActionReducerMap<MeetingSpotsMainState> = {
  meetingSpots: fromMeetingSpots.reducer,
  meetingSpotUpdatePanel: fromMeetingSpotUpdatePanel.reducer
};

export const selectMeetingSpotsState = createFeatureSelector<State, MeetingSpotsMainState>('meetingSpots');


export const selectMeetingSpotsEntitiesState = createSelector(
  selectMeetingSpotsState,
  state => state.meetingSpots
);

export const {
  selectEntities: getMeetingSpotEntities,
  selectAll: getAllMeetingSpots
} = meetingSpotEntityAdapter.getSelectors(selectMeetingSpotsEntitiesState);


export const getMeetingSpotsIsLoading = createSelector(
  selectMeetingSpotsEntitiesState,
  getIsLoading
);

export const getMeetingSpotsCount = createSelector(
  selectMeetingSpotsEntitiesState,
  getCount
);
export const getMeetingSpotsOffset = createSelector(
  selectMeetingSpotsEntitiesState,
  getOffset
);
export const getMeetingSpotsLimit = createSelector(
  selectMeetingSpotsEntitiesState,
  getLimit
);
export const getSelectedMeetingSpotsId = createSelector(
  selectMeetingSpotsEntitiesState,
  fromMeetingSpots.getSelectedMeetingSpotId
);


export const getSelectedMeetingSpot = createSelector(
  getMeetingSpotEntities,
  getSelectedMeetingSpotsId,
  (entities, selectedId) => {
    return selectedId !== null && entities[selectedId];
  }
);

// departmentUpdatePanel selectors
export const selectMeetingSpotUpdatePanelState = createSelector(
  selectMeetingSpotsState,
  (state: MeetingSpotsMainState) => state.meetingSpotUpdatePanel
);
export const getMeetingSpotUpdatePanelError = createSelector(
  selectMeetingSpotUpdatePanelState,
  fromMeetingSpotUpdatePanel.getError
);
export const getMeetingSpotUpdatePanelPending = createSelector(
  selectMeetingSpotUpdatePanelState,
  fromMeetingSpotUpdatePanel.getPending
);
