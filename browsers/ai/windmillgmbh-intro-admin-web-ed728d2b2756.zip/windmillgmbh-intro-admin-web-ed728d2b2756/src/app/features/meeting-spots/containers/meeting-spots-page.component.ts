import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';
import * as fromMeetingSpots from '../reducers';
import { Observable } from 'rxjs';
import { MeetingSpot } from '../models/meeting-spots';
import * as fromRoot from '../../../reducers';

@Component({
  selector: 'wml-meeting-spots-page',
  templateUrl: './meeting-spots-page.component.html'
})
export class MeetingSpotsPageComponent {
  drawerOpened$: Observable<boolean>;

  meetingSpots$: Observable<MeetingSpot[]>;
  meetingSpotsIsLoading$: Observable<boolean>;

  meetingSpotsCount$: Observable<number>;
  meetingSpotsOffset$: Observable<number>;
  meetingSpotsLimit$: Observable<number>;

  constructor(private store: Store<fromMeetingSpots.State>) {
    this.drawerOpened$ = this.store.pipe(select(fromRoot.getDrawerOpened));

    this.meetingSpots$ = store.pipe(select(fromMeetingSpots.getAllMeetingSpots));
    this.meetingSpotsIsLoading$ = store.pipe(select(fromMeetingSpots.getMeetingSpotsIsLoading));

    this.meetingSpotsCount$ = store.pipe(select(fromMeetingSpots.getMeetingSpotsCount));
    this.meetingSpotsOffset$ = store.pipe(select(fromMeetingSpots.getMeetingSpotsOffset));
    this.meetingSpotsLimit$ = store.pipe(select(fromMeetingSpots.getMeetingSpotsLimit));
  }
}

