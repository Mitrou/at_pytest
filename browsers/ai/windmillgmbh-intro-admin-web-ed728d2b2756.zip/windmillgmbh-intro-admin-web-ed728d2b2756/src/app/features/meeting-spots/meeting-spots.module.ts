import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { CoreModule } from '../../core/core.module';
import { SharedModule } from '@shared/shared.module';

import { MeetingSpotsPageComponent } from './containers/meeting-spots-page.component';
import { MeetingSpotsListComponent } from './components/meeting-spots-list/meeting-spots-list.component';
import { MeetingSpotAddPanelComponent } from './containers/meeting-spot-add-panel/meeting-spot-add-panel.component';
import { MeetingSpotUpdatePanelComponent } from './containers/meeting-spot-update-panel/meeting-spot-update-panel.component';
import { MeetingSpotFormComponent } from './components/meeting-spot-form/meeting-spot-form.component';

import { MeetingSpotsEffects } from './effects/meeting-spots.effects';
import { reducer } from './reducers/meeting-spots.reducer';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { meetingSpotsReducers } from './reducers';
import { MeetingSpotsRoutingModule } from './meeting-spots-routing.module';



export const COMPONENTS = [
  MeetingSpotsPageComponent,
  MeetingSpotsListComponent,
  MeetingSpotAddPanelComponent,
  MeetingSpotUpdatePanelComponent,
  MeetingSpotFormComponent
];


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MeetingSpotsRoutingModule,

    StoreModule.forFeature('meetingSpots', meetingSpotsReducers),
    EffectsModule.forFeature([MeetingSpotsEffects]),

    CoreModule,
    SharedModule
  ],
  declarations: COMPONENTS,
  exports: COMPONENTS
})
export class MeetingSpotsModule {
}
