export class MeetingSpot {
  id: number;
  spot: string;
  description: string;
  universityId: string;
  isActive: boolean;

  constructor(raw) {
    this.id = raw.id;
    this.spot = raw.spot;
    this.description = raw.description;
    this.universityId = raw.universityId;
    this.isActive = raw.isActive;
  }
}

export interface MeetingSpots {
  meetingSpots: MeetingSpot[];
}

export interface MeetingSpotsRequest {
  spot: string;
  description: string;
  universityId: string;
  isActive: boolean;
}
