import { MeetingSpotsActionTypes, MeetingSpotsActions } from '../actions/meeting-spots.actions';
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { MeetingSpot } from '../models/meeting-spots';


export interface MeetingSpotsState extends EntityState<MeetingSpot> {
  isLoading: boolean;
  error: any;

  count: number; // count
  offset: number; // offset
  limit: number; // limit

  selectedMeetingSpotId: number | null;
}

export const meetingSpotEntityAdapter: EntityAdapter<MeetingSpot> = createEntityAdapter<MeetingSpot>({
  selectId: (model: MeetingSpot) => model.id
});


export const initialState: MeetingSpotsState = meetingSpotEntityAdapter.getInitialState(
  {
    isLoading: false,
    error: null,

    count: 0,
    offset: 0,
    limit: 10,

    selectedMeetingSpotId: null
  }
);


export function reducer(
  state: MeetingSpotsState = initialState,
  action: MeetingSpotsActions):
  MeetingSpotsState {
  switch (action.type) {
    case MeetingSpotsActionTypes.LoadMeetingSpots: {
      return {
        ...state,
        isLoading: true,
        error: null,

        offset: action.pageInfo.offset,
        limit: action.pageInfo.limit
      };
    }

    case MeetingSpotsActionTypes.LoadMeetingSpotsSuccess: {
      return meetingSpotEntityAdapter.addAll(action.payload.data, {
        ...state,
        isLoading: false,
        error: null,
        count: action.payload.count
      });
    }

    case MeetingSpotsActionTypes.LoadMeetingSpotsFailure: {
      return {
        ...state,
        isLoading: false,
        error: action.payload,
        count: 0,
        offset: 0
      };
    }

    case MeetingSpotsActionTypes.DeleteMeetingSpot: {
      return {
        ...state,
        isLoading: true,
        error: null,
      };
    }

    case MeetingSpotsActionTypes.AddMeetingSpotSuccess:
    case MeetingSpotsActionTypes.LoadMeetingSpotSuccess: {
      return meetingSpotEntityAdapter.addOne(action.payload, state);
    }

    case MeetingSpotsActionTypes.UpdateMeetingSpotSuccess: {
      return meetingSpotEntityAdapter.upsertOne(action.payload, state);
    }

    case MeetingSpotsActionTypes.DeleteMeetingSpotSuccess: {
      return meetingSpotEntityAdapter.removeOne(action.payload, state);
    }


    case MeetingSpotsActionTypes.SelectMeetingSpot: {
      return {
        ...state,
        selectedMeetingSpotId: action.payload
      };
    }

    default:
      return state;
  }
}

export const getIsLoading = (state: MeetingSpotsState): boolean => state.isLoading;
export const getError = (state: MeetingSpotsState): any => state.error;

export const getCount = (state: MeetingSpotsState): any => state.count;
export const getOffset = (state: MeetingSpotsState): any => state.offset;
export const getLimit = (state: MeetingSpotsState): any => state.limit;

export const getSelectedMeetingSpotId = (state: MeetingSpotsState): any => state.selectedMeetingSpotId;
