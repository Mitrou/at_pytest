import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MeetingSpot } from '../../models/meeting-spots';



@Component({
  selector: 'wml-meeting-spot-form',
  templateUrl: './meeting-spot-form.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MeetingSpotFormComponent {
  @Input() meetingSpotId: string | null = null;

  @Input()
  set meetingSpot(meetingSpot: MeetingSpot | undefined) {
    if (meetingSpot) {
      this.form.patchValue({
        id: meetingSpot.id,
        spot: meetingSpot.spot,
        description: meetingSpot.description,
        universityId: meetingSpot.universityId,
        isActive: meetingSpot.isActive
      });
    }
  }

  @Input()
  set pending(isPending: boolean) {
    this.isPending = isPending;

    if (isPending) {
      this.form.disable();
    } else {
      this.form.enable();
    }
  }

  @Input() error: string | null;

  @Output() submitted = new EventEmitter<MeetingSpot>();

  isPending: boolean;

  form: FormGroup = new FormGroup({
    id: new FormControl(''),
    spot: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required),
    universityId: new FormControl('', Validators.required),
    isActive: new FormControl('', Validators.required)
  });

  constructor() {
  }

  submit() {
    if (this.form.valid) {
      this.submitted.emit(this.form.value);
    }
  }
}
