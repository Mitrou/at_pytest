import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Filters } from '../../../core/types/filters';
import { BaseService } from '@shared/services/base.service';
import { LoadListSuccessPayload } from '@shared/models/list';
import { MeetingSpot } from '../models/meeting-spots';


@Injectable({
  providedIn: 'root'
})
export class MeetingSpotsService extends BaseService {

  getMeetingSpots({ offset, limit }, { prop, dir }, filters: Filters): Observable<LoadListSuccessPayload<MeetingSpot>> {
    return this.gridRequest<MeetingSpot>(`/api/meeting-spot`, offset + 1, limit, prop, dir, filters)
      .pipe(
        map(response => ({
          ...response,
          data: response.data.map(meetingSpot => new MeetingSpot(meetingSpot))
        }))
      );
  }

  loadMeetingSpot(id: number): Observable<MeetingSpot> {
    return this.http.get<MeetingSpot>(`/api/meeting-spot/${id}`);
  }

  addMeetingSpot(payload: MeetingSpot): Observable<MeetingSpot> {
    return this.http.post<MeetingSpot>('/api/meeting-spot', payload);
  }

  updateMeetingSpot(payload: MeetingSpot): Observable<MeetingSpot> {
    return this.http.put<MeetingSpot>(`/api/meeting-spot/${payload.id}`, payload);
  }

  deleteMeetingSpot(id: number) {
    return this.http.delete(`/api/meeting-spot/${id}`);
  }
}
