import { reducer as meetingSpotsReducer } from './meeting-spots.reducer';

import * as fromMeetingSpots from './meeting-spots.reducer';

import {
  LoadMeetingSpots,
  LoadMeetingSpotsSuccess,
  LoadMeetingSpotsFailure
} from '../actions/meeting-spots.actions';

import { MeetingSpot } from '../models/meeting-spots';
import {
  meetingSpots,
  getLoadMeetingSpotsError,
  meetingSpotsRequest
} from '../../../shared/mocks';

describe('LoadMeetingSpotsReducer', () => {
  describe('null action', () => {
    it('should return the default state', () => {
      const action = {} as any;

      const result = meetingSpotsReducer(null, action);

      /**
       * Snapshot tests are a quick way to validate
       * the state produced by a reducer since
       * its plain JavaScript object. These snapshots
       * are used to validate against the current state
       * if the functionality of the reducer ever changes.
       */
      expect(result).toMatchSnapshot();
    });
  });

  describe('[ Dashboard ] Get Meeting Spots Init', () => {
    it('should change pending to true in MeetingSpots state', () => {
      const createAction = new LoadMeetingSpots(meetingSpotsRequest.pageInfo);

      const result = meetingSpotsReducer(fromMeetingSpots.initialState, createAction);

      expect(result).toEqual({
        ...fromMeetingSpots.initialState,
        isLoading: true
      });
    });
  });

  describe('[Dashboard] Get Meeting Spots Failure', () => {
    it('should toggle MeetingSpots state and meetingSpots should be null', () => {
      const action = new LoadMeetingSpotsFailure(getLoadMeetingSpotsError);
      const result = meetingSpotsReducer(fromMeetingSpots.initialState, action);

      expect(result).toEqual({
        ...fromMeetingSpots.initialState,
        error: getLoadMeetingSpotsError,
        isLoading: false
      });
    });
  });
});
