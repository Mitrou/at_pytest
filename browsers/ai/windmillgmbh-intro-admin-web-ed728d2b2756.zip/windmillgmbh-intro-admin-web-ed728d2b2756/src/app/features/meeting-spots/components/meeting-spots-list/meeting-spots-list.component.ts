
import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { ColumnFilterType, ColumnType, GridAction, GridOptions } from '@shared/components/grid/grid.configs';
import { Store } from '@ngrx/store';
import { MeetingSpotsMainState } from '../../reducers';
import * as MeetingSpotsActions from '../../actions/meeting-spots.actions';
import { MeetingSpot } from '../../models/meeting-spots';


@Component({
  selector: 'wml-meeting-spots-list',
  templateUrl: './meeting-spots-list.component.html',
  styleUrls: ['./meeting-spots-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeetingSpotsListComponent {
  @Input() count: number;
  @Input() offset: number;
  @Input() limit: number;

  @Input() meetingSpots: MeetingSpot[] = [];

  @Input() loading = true;

  @Input() drawerOpened = false;

  private gridState = null;


  options: GridOptions = {
    actions: [GridAction.Edit, GridAction.Delete],
    columns: [
      {
        prop: 'id',
        columnType: ColumnType.Text,

        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        prop: 'spot',
        columnType: ColumnType.Text,

        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        prop: 'description',
        columnType: ColumnType.Text,
        hideOnDrawerOpened: true,

        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        prop: 'universityId',
        columnType: ColumnType.Text,

        filterable: true,
        filterType: ColumnFilterType.Text
      },
      {
        prop: 'isActive',
        columnType: ColumnType.Text,

        filterable: true,
        filterType: ColumnFilterType.SelectMultiple,
        filterData: [
          { id: 0, title: 'true' },
          { id: 1, title: 'false' },
        ]
      },
    ]
  };

  constructor(private store: Store<MeetingSpotsMainState>) {
  }

  reloadGrid(event = null) {
    console.log(event);

    if (event !== null) {
      this.gridState = event;
    }

    this.store.dispatch(new MeetingSpotsActions.LoadMeetingSpots(
      this.gridState.pageInfo,
      this.gridState.sortInfo,
      this.gridState.filters)
    );
  }

  onItemSelected(item) {
    this.store.dispatch(new MeetingSpotsActions.NavigateToUpdateMeetingSpotPage(item.id));
  }

  onItemEdit(item) {
    this.store.dispatch(new MeetingSpotsActions.NavigateToUpdateMeetingSpotPage(item.id));
  }

  onItemDelete(item) {
    this.store.dispatch(new MeetingSpotsActions.DeleteMeetingSpot(item.id));

    this.reloadGrid();
  }
}
