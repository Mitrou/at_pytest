import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { select, Store } from '@ngrx/store';

import { Observable, of } from 'rxjs';
import { map, switchMap, take, tap } from 'rxjs/operators';

import * as fromMeetingSpots from '../reducers';
import { LoadMeetingSpot, SelectMeetingSpot } from '../actions/meeting-spots.actions';


@Injectable({
  providedIn: 'root',
})
export class MeetingSpotInStoreGuard implements CanActivate {
  constructor(
    private store: Store<fromMeetingSpots.MeetingSpotsMainState>,
  ) {
  }

  hasDepartmentInStore(id: number): Observable<boolean> {
    return this.store.pipe(
      select(fromMeetingSpots.getMeetingSpotEntities),
      map(entities => !!entities[id]),
      take(1)
    );
  }

  hasDepartment(id: number): Observable<boolean> {
    return this.hasDepartmentInStore(id).pipe(
      tap(() => this.store.dispatch(new SelectMeetingSpot(id))),
      tap((inStore) => {
        if (!inStore) {
          this.store.dispatch(new LoadMeetingSpot());
        }
      }),
      switchMap(() => {
        return of(true);
      })
    );
  }

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    return this.hasDepartment(Number(route.params['meetingSpotId']));
  }
}
