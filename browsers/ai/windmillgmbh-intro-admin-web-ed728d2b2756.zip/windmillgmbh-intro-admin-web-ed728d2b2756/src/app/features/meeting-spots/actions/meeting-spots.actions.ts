import { Action } from '@ngrx/store';
import { Filters } from '../../../core/types/filters';
import { MeetingSpot } from '../models/meeting-spots';


export enum MeetingSpotsActionTypes {
  LoadMeetingSpots = '[Meeting Spots] Load List',
  LoadMeetingSpotsSuccess = '[Meeting Spots] Load List Success',
  LoadMeetingSpotsFailure = '[Meeting Spots] Load List Failure',

  AddMeetingSpot = '[MeetingSpots] Add MeetingSpot',
  AddMeetingSpotSuccess = '[MeetingSpots] Add MeetingSpot Success',
  AddMeetingSpotFailure = '[MeetingSpots] Add MeetingSpot Failure',

  SelectMeetingSpot = '[MeetingSpots] Select MeetingSpot',

  DeleteMeetingSpot = '[MeetingSpots] Delete MeetingSpot',
  DeleteMeetingSpotSuccess = '[MeetingSpots] Delete MeetingSpot Success',
  DeleteMeetingSpotFailure = '[MeetingSpots] Delete MeetingSpot Failure',

  LoadMeetingSpot = '[MeetingSpots] Load MeetingSpot',
  LoadMeetingSpotSuccess = '[MeetingSpots] Load MeetingSpot Success',
  LoadMeetingSpotFailure = '[MeetingSpots] Load MeetingSpot Failure',

  UpdateMeetingSpot = '[MeetingSpots] Update MeetingSpot',
  UpdateMeetingSpotSuccess = '[MeetingSpots] Update MeetingSpot Success',
  UpdateMeetingSpotFailure = '[MeetingSpots] Update MeetingSpot Failure',

  NavigateToUpdateMeetingSpotPage = '[MeetingSpots] Navigate To Update',
}

////////////

export class LoadMeetingSpots implements Action {
  readonly type = MeetingSpotsActionTypes.LoadMeetingSpots;

  constructor(
    public pageInfo = { offset: 0, limit: 10 },
    public sortInfo = { prop: 'id', dir: 'asc' },
    public filters: Filters = null) {
  }
}

export class LoadMeetingSpotsSuccess implements Action {
  readonly type = MeetingSpotsActionTypes.LoadMeetingSpotsSuccess;

  constructor(public payload: any) {
  }
}

export class LoadMeetingSpotsFailure implements Action {
  readonly type = MeetingSpotsActionTypes.LoadMeetingSpotsFailure;

  constructor(public payload: any) {
  }
}

export class AddMeetingSpot implements Action {
  readonly type = MeetingSpotsActionTypes.AddMeetingSpot;

  constructor(public payload: MeetingSpot) {
  }
}

export class AddMeetingSpotSuccess implements Action {
  readonly type = MeetingSpotsActionTypes.AddMeetingSpotSuccess;

  constructor(public payload: MeetingSpot) {
  }
}

export class AddMeetingSpotFailure implements Action {
  readonly type = MeetingSpotsActionTypes.AddMeetingSpotFailure;

  constructor(public payload: string) {
  }
}

export class SelectMeetingSpot implements Action {
  readonly type = MeetingSpotsActionTypes.SelectMeetingSpot;

  constructor(public payload: number) {
  }
}

export class LoadMeetingSpot implements Action {
  readonly type = MeetingSpotsActionTypes.LoadMeetingSpot;
}

export class LoadMeetingSpotSuccess implements Action {
  readonly type = MeetingSpotsActionTypes.LoadMeetingSpotSuccess;

  constructor(public payload: MeetingSpot) {
  }
}

export class LoadMeetingSpotFailure implements Action {
  readonly type = MeetingSpotsActionTypes.LoadMeetingSpotFailure;

  constructor(public payload: string) {
  }
}

export class UpdateMeetingSpot implements Action {
  readonly type = MeetingSpotsActionTypes.UpdateMeetingSpot;

  constructor(public payload: MeetingSpot) {
  }
}

export class UpdateMeetingSpotSuccess implements Action {
  readonly type = MeetingSpotsActionTypes.UpdateMeetingSpotSuccess;

  constructor(public payload: MeetingSpot) {
  }
}

export class UpdateMeetingSpotFailure implements Action {
  readonly type = MeetingSpotsActionTypes.UpdateMeetingSpotFailure;

  constructor(public payload: string) {
  }
}

export class NavigateToUpdateMeetingSpotPage implements Action {
  readonly type = MeetingSpotsActionTypes.NavigateToUpdateMeetingSpotPage;

  constructor(public payload: number) {
  }
}

export class DeleteMeetingSpot implements Action {
  readonly type = MeetingSpotsActionTypes.DeleteMeetingSpot;

  constructor(public payload: number) {
  }
}

export class DeleteMeetingSpotSuccess implements Action {
  readonly type = MeetingSpotsActionTypes.DeleteMeetingSpotSuccess;
  constructor(public payload: number) {
  }
}

export class DeleteMeetingSpotFailure implements Action {
  readonly type = MeetingSpotsActionTypes.DeleteMeetingSpotFailure;

  constructor(public payload: string) {
  }
}

////////////

export type MeetingSpotsActions =
  | LoadMeetingSpots
  | LoadMeetingSpotsSuccess
  | LoadMeetingSpotsFailure
  | AddMeetingSpot
  | AddMeetingSpotSuccess
  | AddMeetingSpotFailure
  | SelectMeetingSpot
  | LoadMeetingSpot
  | LoadMeetingSpotSuccess
  | LoadMeetingSpotFailure
  | UpdateMeetingSpot
  | UpdateMeetingSpotSuccess
  | UpdateMeetingSpotFailure
  | NavigateToUpdateMeetingSpotPage
  | DeleteMeetingSpot
  | DeleteMeetingSpotSuccess
  | DeleteMeetingSpotFailure;
