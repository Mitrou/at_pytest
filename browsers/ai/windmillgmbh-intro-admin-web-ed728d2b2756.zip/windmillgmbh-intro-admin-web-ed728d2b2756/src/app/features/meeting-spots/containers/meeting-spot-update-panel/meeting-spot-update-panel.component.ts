import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';

import * as fromRoot from '../../../../reducers';
import * as fromMeetingSpots from '../../reducers/index';

import { map } from 'rxjs/operators';
import { RouterStateUrl } from '@shared/utils/custom-router-state-serializer';
import { MeetingSpot } from '../../models/meeting-spots';
import { UpdateMeetingSpot } from '../../actions/meeting-spots.actions';


@Component({
  selector: 'wml-meeting-spot-update-panel',
  templateUrl: './meeting-spot-update-panel.component.html'
})
export class MeetingSpotUpdatePanelComponent {
  meetingSpotId$ = this.store.pipe(
    select(fromRoot.getRouterSerializedState),
    map((routerState: RouterStateUrl) => routerState.params.meetingSpotId)
  );

  meetingSpot$ = this.store.pipe(select(fromMeetingSpots.getSelectedMeetingSpot));
  pending$ = this.store.pipe(select(fromMeetingSpots.getMeetingSpotUpdatePanelPending));
  error$ = this.store.pipe(select(fromMeetingSpots.getMeetingSpotUpdatePanelError));

  constructor(private store: Store<fromMeetingSpots.MeetingSpotsMainState>) {
  }

  onSubmit($event: MeetingSpot) {
    this.store.dispatch(new UpdateMeetingSpot($event));
  }
}
