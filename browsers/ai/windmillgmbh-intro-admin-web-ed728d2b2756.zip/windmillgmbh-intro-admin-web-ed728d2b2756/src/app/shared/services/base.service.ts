import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Filters, SerializedFilters } from '../../core/types/filters';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { LoadListSuccessPayload } from '@shared/models/list';


@Injectable()
export class BaseService {
  constructor(protected http: HttpClient) {
  }

  protected gridRequest<T>(url, page, pageSize, property, direction, filters): Observable<LoadListSuccessPayload<T>> {
    return this.http
      .get<T[]>(url, {
        observe: 'response',
        params: {
          _page: page,
          _limit: pageSize,
          _sort: property,
          _order: direction,
          ...this.serializeFilter(filters)
        }
      })
      .pipe(
        map(response => {
          return {
            count: Number(response.headers.get('X-Total-Count')),
            data: response.body
          };
        })
      );
  }

  protected serializeFilter(filters: Filters): SerializedFilters {
    if (filters === null) {
      return {};
    }

    const filterObj = {};

    filters.forEach((v, k) => {
      if (!['null', ''].includes(String(v))) {
        filterObj[String(k)] = v;
      }
    });

    return filterObj;
  }
}
