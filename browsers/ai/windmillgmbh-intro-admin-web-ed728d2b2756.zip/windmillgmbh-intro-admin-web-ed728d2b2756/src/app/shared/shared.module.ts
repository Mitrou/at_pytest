import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MaterialModule } from './material/material.module';
import { ComponentsModule } from './components/components.module';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ChartsModule } from 'ng2-charts/ng2-charts';
const SERVICES = [];

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    ComponentsModule,
    NgxDatatableModule,
    ChartsModule
  ],
  exports: [ MaterialModule, ComponentsModule, NgxDatatableModule, ChartsModule],
  declarations: []
})
export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: SERVICES
    };
  }
}
