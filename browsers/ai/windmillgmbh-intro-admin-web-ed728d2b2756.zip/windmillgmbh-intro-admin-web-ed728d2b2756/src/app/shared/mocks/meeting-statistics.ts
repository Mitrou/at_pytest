import {
  MeetingStatistics,
  MeetingStatisticsRequest
} from '../../features/dashboard/models/meeting-statistics';

export const meetingStats = {
  totalMeetings: 500,
  newMeetings: 150,
  trend: 1.5,
  stats: [
    {
      status: 'PLANNED',
      count: 40,
      percentage: 26.67
    },
    {
      status: 'PENDING',
      count: 20,
      percentage: 13.34
    },
    {
      status: 'CANCELED',
      count: 10,
      percentage: 6.67
    },
    {
      status: 'COMPLETED',
      count: 80,
      percentage: 53.34
    }
  ]
} as MeetingStatistics;

export const meetingStatsRequest = {
  period: '1 Year'
} as MeetingStatisticsRequest;

export const getMeetingStatisticsError = 'Could not load Meeting Statistics';
