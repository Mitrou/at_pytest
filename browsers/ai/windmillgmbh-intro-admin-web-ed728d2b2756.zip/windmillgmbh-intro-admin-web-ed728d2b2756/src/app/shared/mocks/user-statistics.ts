import {
  UserStatistics,
  UserStatisticsRequest
} from '../../features/dashboard/models/user-statistics';

export const userStats = {
  totalUsers: 1700,
  newUsers: 190,
  trend: 1.3,
  stats: [
    {
      key: 'JAN 2018',
      value: 35
    },
    {
      key: 'FEB 2018',
      value: 90
    },
    {
      key: 'MAR 2018',
      value: 200
    }
  ]
} as UserStatistics;

export const userStatsRequest = { period: 'year' } as UserStatisticsRequest;

export const getUserStatisticsError = 'Could not load User Statistics';
