import {
  User,
  SocialPresence,
  MeetingPrefrences
} from '@shared/models/user';

export const user = new User({
  id: '5bebf8f821f9e8225550f8f5',
  firstName: 'Mcfadden',
  lastName: 'Elliott',
  status: 'OFFLINE',
  participation: 'LOW',
  type: 'TEACHER',
  city: 'Crisman',
  country: 'Canada',
  email: 'mcfadden.elliott@gmail.com',
  avgReting: 1.07,
  lastActive: 1503597436,
  seniority: 'Junior',
  major: 'Geography',
  commonInterests: ['Music', 'Guitar'],
  interests: ['Food', 'Fasion', 'Basketball'],
  aspiration: 'Sailor',
  socialPresence: [
    {
      id: 0,
      type: 'facebook',
      value: 'www.facebook.com/50404/dolor'
    } as SocialPresence
  ],
  meetingPrefrences: {
    meetingWith: 'Co-ed/mixed',
    eventType: ['Get Together', 'Concert'],
    matchingFrequency: 'Every Week',
    preferredDays: ['Wednesday', 'Friday', 'Wednesday']
  } as MeetingPrefrences
});

export const getCurrentUserErrorStr = 'Invalid email or password';
