import { QuickActions } from '../../features/dashboard/models/quick-actions';

export const quickStats = {
  possibleMatches: 234,
  pendingFeedback: 156,
  meetingCount: 10,
  userCount: 17
} as QuickActions;

export const getQuickActionsError = 'Could not load Quick Actions';
