import {
  ResetPasswordInitPayload,
  ResetPasswordFinishPayload,
} from '../../features/auth/models/auth';

export const resetPasswordInitPayload = {
  mail: 'admin@intro.com'
} as ResetPasswordInitPayload;

export const resetPasswordFinishPayload = {
  key: 'key',
  newPassword: 'newPassword'
} as ResetPasswordFinishPayload;
