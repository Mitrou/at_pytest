import {
  LoginPayload,
  LoginSuccessPayload
} from '../../features/auth/models/auth';
import { user } from './user';

export const loginPayload = {
  username: 'admin@intro.com',
  password: 'admin'
} as LoginPayload;

export const loginSuccessPayload = {
  idToken: 'idToken'
} as LoginSuccessPayload;

export const initialLoginPayload = {
  idToken: 'idToken',
  currentUser: user
};
