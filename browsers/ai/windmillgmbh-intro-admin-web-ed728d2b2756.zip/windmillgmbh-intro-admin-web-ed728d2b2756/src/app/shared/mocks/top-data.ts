import { TopInterests } from '../../features/dashboard/models/top-interests';
import { TopUsers } from '../../features/dashboard/models/top-users';

export const topInterests = {
  totalUsers: 1250,
  topInterest: [
    {
      name: 'Technology',
      userCount: 850,
      trend: 30,
      percentage: 68
    },
    {
      name: 'Music',
      userCount: 400,
      trend: 25,
      percentage: 32
    }
  ]
} as TopInterests;

export const getTopInterestsError = 'Could not load Top Interests';

export const topUsers = {
  totalUsers: 1250,
  topUsers: [
    {
      firstName: 'Patrick',
      lastName: 'Stanley',
      email: 'patrick.stanley@univ.edu',
      participation: '100',
      type: 'STUDENT',
      getTogethers: 32,
      percentage: 100
    },
    {
      firstName: 'Jean',
      lastName: 'Barber',
      email: 'jean.barber@univ.edu',
      participation: 'HIGH',
      type: 'FACULTY',
      getTogethers: 5,
      percentage: 80
    }
  ]
} as TopUsers;

export const getTopUsersError = 'Could not load Top Users';
