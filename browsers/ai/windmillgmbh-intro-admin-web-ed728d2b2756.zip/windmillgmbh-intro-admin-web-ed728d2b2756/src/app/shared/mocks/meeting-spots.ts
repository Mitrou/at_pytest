import { MeetingSpots, MeetingSpotsRequest} from '../../features/meeting-spots/models/meeting-spots';

export const meetingSpots = {
    meetingSpots: [
      {
        id: 0,
        spot: 'Canteen 1',
        description: 'Canteen 1',
        universityId: '5bf6b29d8107a21f9e705f84',
        isActive: false
      },
      {
        id: 1,
        spot: 'Canteen 2',
        description: 'Canteen 2',
        universityId: '5bf6b29d8107a21f9e705f84',
        isActive: true
      }
    ]
  } as MeetingSpots;

export const meetingSpotsRequest = {
    pageInfo: { offset: 0, limit: 10 },
    sortInfo: { prop: 'id', dir: 'asc' },
    filters: null
};


export const getLoadMeetingSpotsError = 'Could not load Meeting Spots';
