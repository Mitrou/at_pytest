import { Component, Input, OnInit } from '@angular/core';

import { Status } from '@shared/models/status';

@Component({
  selector: 'wml-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.scss']
})
export class StatusComponent implements OnInit {
  @Input() status: Status;

  constructor() { }

  ngOnInit() {
  }

}
