import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MaterialModule } from '../material/material.module';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';

import { GridComponent } from './grid/grid.component';
import { GridResizeWatcherDirective } from './grid/grid.directive';
import { RatingComponent } from './rating/rating.component';
import { StatusComponent } from './status/status.component';

const COMPONENTS = [
  GridComponent,
  GridResizeWatcherDirective,
  RatingComponent,
  StatusComponent
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    NgxDatatableModule,
  ],
  declarations: COMPONENTS,
  exports: COMPONENTS
})
export class ComponentsModule {
}
