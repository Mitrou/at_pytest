import { TableColumn, SelectionType } from '@swimlane/ngx-datatable';

export enum ColumnType {
  Text, Status, Date, TimeRange, Checkbox, Rating
}

export enum ColumnFilterType {
  Text, DatePicker, Select, SelectMultiple, TimeRangePicker
}

export enum GridAction {
  Edit, Delete
}

export interface GridColumn extends TableColumn {
  columnType?: ColumnType;

  preventClicking?: boolean;
  editAction?: boolean;
  deleteAction?: boolean;
  hideOnDrawerOpened?: boolean;

  dateFormat?: string;

  filterable?: boolean;
  filterType?: ColumnFilterType;
  filterProp?: string;
  filterData?: any[];
}


export interface GridOptions {
  actions: GridAction[];
  columns: GridColumn[];
  selectionType?: SelectionType;
}
