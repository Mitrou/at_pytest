import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnChanges
} from '@angular/core';

@Component({
  selector: 'wml-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RatingComponent implements OnChanges {
  @Input() rating: number;
  @Input() possibleMax = 10;

  color: string;
  circles: string[];

  constructor() {}

  ngOnChanges() {
    this.circles = [];
    let rating = (this.rating / this.possibleMax) * 5;

    while (rating > 1) {
      this.circles.push('full');
      rating--;
    }

    if (rating  >= 0.25) {
      if (rating >= 0.8) {
        this.circles.push('full');
      } else {
        this.circles.push('half');
      }
    }

    switch (this.circles.length % 5) {
      case 0:
      case 4:
        this.color = 'green';
        break;
      case 3:
        this.color = 'orange';
        break;
      case 2:
        this.color = 'red';
        break;
      default:
        this.color = 'red';
        break;
    }

    while (this.circles.length < 5) {
      this.circles.push('empty');
    }
  }

}
