import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  Output,
  TemplateRef,
  ViewChild
} from '@angular/core';
import { MatSelectChange } from '@angular/material';

import { DatatableComponent, SelectionType } from '@swimlane/ngx-datatable';
import * as debounce from 'lodash.debounce';

import { FilterKey, Filters, FilterValue } from '../../../core/types/filters';
import {
  ColumnFilterType,
  ColumnType,
  GridAction,
  GridColumn,
  GridOptions
} from '@shared/components/grid/grid.configs';
import { LoadListPayload } from '@shared/models/list';


@Component({
  selector: 'wml-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GridComponent {
  @Input() data: any;
  @Input() loading: boolean;

  @Input() count = 0;
  @Input() offset = 0;
  @Input() limit = 10;
  @Input() onDrawerClosed: Function;

  @Input()
  set drawerOpened(opened: boolean) {
    if (!opened && this._selected && this.onDrawerClosed) {
       this.onDrawerClosed.call(this);
    }
    if (this._columns) {
      this.columns = this.buildGrid(this._columns, opened);

      // TODO: dirty hack, need to find a better way
      setTimeout(() => {
        this.table.recalculate();
        this.cdr.detectChanges();
      }, 600);
    }
  }

  @Input()
  set options(options: GridOptions) {
    if (options.actions) {
      this._actions = options.actions;
    }

    if (options.columns) {
      this._columns = options.columns;

      this.columns = this.buildGrid(this._columns);
    }

    this.selectionType = options.selectionType || SelectionType.single;
  }

  @Output() pageChanged = new EventEmitter();
  @Output() filterChanged = new EventEmitter();
  @Output() reloadGrid = new EventEmitter<LoadListPayload>();

  @Output() selectItem = new EventEmitter();
  @Output() multiSelectItem = new EventEmitter();
  @Output() editItem = new EventEmitter();
  @Output() deleteItem = new EventEmitter();

  @ViewChild(DatatableComponent) table: DatatableComponent;

  // Header Templates
  @ViewChild('headerDefaultTpl') headerDefaultTpl: TemplateRef<any>;
  @ViewChild('headerTextTpl') headerTextTpl: TemplateRef<any>;
  @ViewChild('headerSelectTpl') headerSelectTpl: TemplateRef<any>;
  @ViewChild('headerSelectMultipleTpl') headerSelectMultipleTpl: TemplateRef<any>;
  @ViewChild('headerDateRangeTpl') headerDateRangeTpl: TemplateRef<any>;

  // Cell Templates
  @ViewChild('cellDefaultTpl') cellDefaultTpl: TemplateRef<any>;
  @ViewChild('cellStatusTpl') cellStatusTpl: TemplateRef<any>;
  @ViewChild('cellTimeRangeTpl') cellTimeRangeTpl: TemplateRef<any>;
  @ViewChild('cellActionsTpl') cellActionsTpl: TemplateRef<any>;
  @ViewChild('cellArrowTpl') cellArrowTpl: TemplateRef<any>;
  @ViewChild('cellDateTpl') cellDateTpl: TemplateRef<any>;
  @ViewChild('cellCheckboxTpl') cellCheckboxTpl: TemplateRef<any>;
  @ViewChild('cellRatingTpl') cellRatingTpl: TemplateRef<any>;

  columns: GridColumn[] = [];

  pageInfo = { offset: 0, limit: 10 };
  sortInfo = { prop: 'id', dir: 'asc' };
  filters: Filters = new Map<FilterKey, FilterValue>();

  pageCountList = [10, 30, 50, 100];

  private _selected = null;

  private _actions: GridAction[];
  private _columns: GridColumn[];

  selectionType: SelectionType;

  updateGridDelayed = debounce(this.updateGrid, 800);

  constructor(public cdr: ChangeDetectorRef) {
    this.rowClass = this.rowClass.bind(this);
  }

  get from() {
    return this.offset * this.limit;
  }

  get to() {
    const to = this.offset * this.limit + this.limit;

    return to > this.count ? this.count : to;
  }

  /**
   * Returns the active class if the row is selected
   *
   * @param row
   * @returns {{selected: boolean}}
   */
  rowClass(row) {
    return {
      selected: this._selected === row
    };
  }

  /**
   * On row item click
   *
   * @param type
   * @param cellIndex
   * @param row
   * @param column
   */
  onActive({ type, row, column }) {
    if (this.selectionType === SelectionType.checkbox) {
      // console.log(arguments[0]);
    } else if (type === 'click' && !column.preventClicking) {
      this.itemClicked(row);
    }
  }

  onSelected({ selected }) {
    if (this.selectionType !== SelectionType.single) {
      this.multiSelectItem.emit(selected);
    }
  }

  itemClicked(row) {
    this._selected = row;
    this.selectItem.emit(row);

    // TODO: check if it's needed
    window.dispatchEvent(new Event('resize'));
  }

  changeFilter(event, column: any) {
    let value = null;

    if (event instanceof MatSelectChange) {
      if (!Array.isArray(event.value)) {
        value = !event.value ? [] : [event.value];
      } else {
        value = event.value;
      }

      value = value.map(val => column.filterProp ? val[column.filterProp] : val.title);
    } else {
      value = event.target.value;
    }

    this.filters.set(column.prop, value);
    this.filterChanged.emit(this.filters);

    this.pageInfo = { ...this.pageInfo, offset: 0 };

    this.updateGridDelayed();
  }

  onPaginate(pageInfo) {
    this.pageInfo = pageInfo;
    this.pageChanged.emit(pageInfo);

    this.updateGrid();
  }

  onPageCount(event: MatSelectChange) {
    this.pageInfo = { offset: 0, limit: event.value };
    this.updateGrid();
  }

  onSort(event) {
    this.sortInfo = event.sorts[0];

    this.pageInfo = { ...this.pageInfo, offset: 0 };
    this.updateGrid();
  }

  onItemDeleted(item) {
    // TODO: need to change the control to the material one
    if (confirm(`Are you sure?`)) {
      this.deleteItem.emit(item);
    }
  }

  updateGrid() {
    this.reloadGrid.emit({
      pageInfo: this.pageInfo,
      sortInfo: this.sortInfo,
      filters: this.filters
    });
  }

  private buildGrid(gridColumns: GridColumn[], hideOnDrawer = false) {
    const columns: GridColumn[] = [];

    if (hideOnDrawer) {
      gridColumns = gridColumns.filter(col => !col.hideOnDrawerOpened);
    }

    for (const opt of gridColumns) {
      const column = {
        ...opt,
        headerTemplate: this.getHeaderTemplate(opt),
        cellTemplate: this.getCellTemplate(opt)
      };

      columns.push(column);
    }

    if (this._actions.length) {
      columns.push({
        width: 110,
        canAutoResize: false,
        preventClicking: true,
        editAction: this._actions && this._actions.includes(GridAction.Edit),
        deleteAction: this._actions && this._actions.includes(GridAction.Delete),
        cellTemplate: this.cellActionsTpl
      });
    } else {
      columns.push({
        width: 50,
        canAutoResize: false,
        cellTemplate: this.cellArrowTpl
      });
    }

    return columns;
  }

  private getHeaderTemplate(opt: GridColumn) {
    if (!opt.filterable) {
      return this.headerDefaultTpl;
    }

    switch (opt.filterType) {
      case ColumnFilterType.Text: {
        return this.headerTextTpl;
      }

      case ColumnFilterType.Select: {
        return this.headerSelectTpl;
      }

      case ColumnFilterType.SelectMultiple: {
        return this.headerSelectMultipleTpl;
      }

      case ColumnFilterType.DatePicker:
        return this.headerDateRangeTpl;

      default: {
        return this.headerDefaultTpl;
      }
    }
  }

  private getCellTemplate(opt: GridColumn) {
    switch (opt.columnType) {
      case ColumnType.Status: {
        return this.cellStatusTpl;
      }

      case ColumnType.TimeRange: {
        return this.cellTimeRangeTpl;
      }

      case ColumnType.Date:
        return this.cellDateTpl;

      case ColumnType.Checkbox:
        return this.cellCheckboxTpl;

      case ColumnType.Rating:
        return this.cellRatingTpl;

      default: {
        return this.cellDefaultTpl;
      }
    }
  }
}
