import { Filters } from '../../core/types/filters';

interface PageInfo {
  offset: number;
  limit: number;
}

interface SortInfo {
  prop: string;
  dir: string;
}

export class LoadListPayload {
  public pageInfo: PageInfo = {offset: 0, limit: 10};

  public sortInfo: SortInfo = {prop: 'id', dir: 'asc'};

  public filters: Filters = null;

  constructor(params?: { pageInfo?: PageInfo, sortInfo?: SortInfo, filters?: Filters }) {
    if (params) {
      Object.assign(this, params);
    }
  }
}

export interface LoadListSuccessPayload<T> {
  count: number;
  data: T[];
}
