import { Status } from '@shared/models/status';

export interface SocialPresence {
  id: number;
  type: string;
  value: string;
}

export interface MeetingPrefrences {
  meetingWith: string;
  eventType: string[];
  matchingFrequency: string;
  preferredDays: string[];
}

export enum Participation {
  LOW = 'LOW',
  HIGH = 'HIGH',
  MEDIUM = 'MEDIUM', // might be deleted in future
  FULL = '100%',
  MODERATE = 'MODERATE'
}

export class User {
  id: number;
  firstName: string;
  lastName: string;
  name: string;
  status: Status;
  participation: string;
  type: string;
  location?: string;
  city: string;
  country: string;
  email: string;
  interests: string[];
  interestsLength: number;
  avgReting: number;
  lastActive: number;
  seniority: string;
  major: string;
  commonInterests: string[];
  aspiration: string;
  socialPresence: SocialPresence[];
  meetingPrefrences: MeetingPrefrences;

  constructor(payload: any) {
    Object.assign(this, payload);
    this.location = this.location || this.city + ', ' + this.country;
    this.name = this.firstName + ' ' + this.lastName;
    this.status = parseInt(Status[payload.status.toUpperCase()], 10);
    this.interestsLength = this.interests.length;
  }
}
