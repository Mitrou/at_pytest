import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'wml-forbidden',
  templateUrl: './forbidden-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ForbiddenPageComponent {
}
