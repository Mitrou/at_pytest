import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'wml-not-found-page',
  templateUrl: './not-found-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NotFoundPageComponent {
}
