import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { HttpRequestInterceptor } from './services/http-request-interceptor.service';
import { HttpResponseInterceptor } from './services/http-response-interceptor.service';
import { OpenDrawerGuard } from './services/open-drawer-guard.service';
import { CloseDrawerGuard } from './services/close-drawer-guard.service';

import { AppComponent } from './outlet/app.component';
import { AuthLayoutComponent } from './containers/auth-layout.component';
import { MainLayoutComponent } from './containers/main-layout.component';
import { SideNavComponent } from './components/side-nav.component';
import { TopNavComponent } from './components/top-nav.component';
import { NotFoundPageComponent } from './fallback-pages/not-found-page.component';
import { ForbiddenPageComponent } from './fallback-pages/forbidden-page.component';
import { MaterialModule } from '@shared/material/material.module';
import { SubHeaderComponent } from './components/sub-header.component';

export const COMPONENTS = [
  AppComponent,
  AuthLayoutComponent,
  MainLayoutComponent,
  SideNavComponent,
  TopNavComponent,
  SubHeaderComponent,
  NotFoundPageComponent,
  ForbiddenPageComponent
];

@NgModule({
  imports: [CommonModule, RouterModule, MaterialModule],
  declarations: COMPONENTS,
  exports: COMPONENTS
})
export class CoreModule {
  static forRoot() {
    return {
      ngModule: CoreModule,
      providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: HttpRequestInterceptor,
          multi: true
        },
        {
          provide: HTTP_INTERCEPTORS,
          useClass: HttpResponseInterceptor,
          multi: true
        },
        OpenDrawerGuard,
        CloseDrawerGuard
      ]
    };
  }
}
