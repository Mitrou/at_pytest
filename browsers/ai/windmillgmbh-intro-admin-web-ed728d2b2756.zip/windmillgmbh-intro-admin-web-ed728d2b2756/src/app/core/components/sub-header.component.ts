import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'wml-sub-header',
  templateUrl: './sub-header.component.html',
})
export class SubHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
