import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'wml-side-nav',
  templateUrl: './side-nav.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SideNavComponent {
}
