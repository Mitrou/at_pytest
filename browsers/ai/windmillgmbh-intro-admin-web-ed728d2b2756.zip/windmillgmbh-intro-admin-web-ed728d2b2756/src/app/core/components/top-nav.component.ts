import { Component, EventEmitter, Input, Output } from '@angular/core';
import { User } from '@shared/models/user';

@Component({
  selector: 'wml-top-nav',
  templateUrl: './top-nav.component.html'
})
export class TopNavComponent {
  @Input() pending: boolean;
  @Input() loggedIn: boolean;

  @Input() currentUser: User;

  @Output() logout = new EventEmitter();
}
