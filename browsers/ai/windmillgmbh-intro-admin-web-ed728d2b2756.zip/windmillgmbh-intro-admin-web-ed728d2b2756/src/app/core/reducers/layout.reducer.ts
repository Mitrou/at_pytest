import produce from 'immer';

import { LayoutActionTypes, LayoutActionsUnion } from '../actions/layout.actions';

export interface State {
  drawerOpened: boolean;
}

const initialState: State = {
  drawerOpened: false,
};

export function reducer(state: State = initialState, action: LayoutActionsUnion): State {
  return produce(state, (draft) => {
    switch (action.type) {
      case LayoutActionTypes.CloseDrawer: {
        draft.drawerOpened = false;
        return;
      }

      case LayoutActionTypes.OpenDrawer: {
        draft.drawerOpened = true;
        return;
      }
    }
  });
}

export const getDrawerOpened = (state: State) => state.drawerOpened;
