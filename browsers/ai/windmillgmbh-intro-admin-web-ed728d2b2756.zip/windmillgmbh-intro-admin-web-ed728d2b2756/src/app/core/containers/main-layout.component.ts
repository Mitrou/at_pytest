import { ChangeDetectionStrategy, Component } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { User } from '@shared/models/user';

import * as AuthActions from '../../features/auth/actions/auth.actions';
import * as fromAuth from '../../features/auth/reducers';
import * as fromRoot from '../../reducers';

@Component({
  selector: 'wml-main-layout',
  templateUrl: './main-layout.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MainLayoutComponent {
  loggedIn$: Observable<boolean>;
  drawerOpened$: Observable<boolean>;
  pending$: Observable<boolean>;
  currentUser$: Observable<User>;

  constructor(private store: Store<fromRoot.State>) {
    this.loggedIn$ = this.store.pipe(select(fromAuth.getLoggedIn));
    this.drawerOpened$ = this.store.pipe(select(fromRoot.getDrawerOpened));
    this.pending$ = this.store.pipe(select(fromAuth.getCurrentUserPending));
    this.currentUser$ = this.store.pipe(select(fromAuth.getCurrentUser));
  }

  logout() {
    this.store.dispatch(new AuthActions.Logout());
  }
}
