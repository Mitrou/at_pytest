import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'wml-app',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent {
}

