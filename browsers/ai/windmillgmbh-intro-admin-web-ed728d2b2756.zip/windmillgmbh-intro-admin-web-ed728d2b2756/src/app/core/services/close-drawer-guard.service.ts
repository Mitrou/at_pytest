import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { Store, select } from '@ngrx/store';

import * as LayoutActions from '../actions/layout.actions';
import * as fromRoot from '../../reducers';

import { Observable } from 'rxjs';
import { map, filter, take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class CloseDrawerGuard implements CanDeactivate<Observable<boolean>> {
  constructor(private store: Store<fromRoot.State>) {
  }

  canDeactivate(): Observable<boolean> {
    return this.store.pipe(
      select(fromRoot.getDrawerOpened),
      map((drawerOpened) => {
        if (drawerOpened) {
          this.store.dispatch(new LayoutActions.CloseDrawer());
          return false;
        }

        return true;
      }),
      filter((canDeactivate) => canDeactivate),
      take(1)
    );
  }
}
