import { TestBed } from '@angular/core/testing';
import { StoreModule, Store } from '@ngrx/store';
import { cold } from 'jasmine-marbles';

import * as fromRoot from '../../reducers';
import * as LayoutActions from '../actions/layout.actions';

import { CloseDrawerGuard } from './close-drawer-guard.service';

describe('Auth Guard', () => {
  let guard: CloseDrawerGuard;
  let store: Store<any>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          ...fromRoot.reducers
        }),
      ],
      providers: [CloseDrawerGuard],
    });

    store = TestBed.get(Store);
    spyOn(store, 'dispatch').and.callThrough();
    guard = TestBed.get(CloseDrawerGuard);
  });

  it('should complete with true if drawer is closed', () => {
    const expected = cold('(a|)', {a: true});

    expect(guard.canDeactivate()).toBeObservable(expected);
  });

  it('should dispatch LayoutActions.CloseDrawer action and complete with true if drawer is opened', () => {
    const action = new LayoutActions.OpenDrawer();
    store.dispatch(action);

    const expected = cold('(a|)', {a: true});

    expect(guard.canDeactivate()).toBeObservable(expected);

    expect(store.dispatch).toHaveBeenCalledWith(new LayoutActions.CloseDrawer());
  });
});
