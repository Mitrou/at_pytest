import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Store, select } from '@ngrx/store';

import * as LayoutActions from '../actions/layout.actions';
import * as fromRoot from '../../reducers';

import { Observable } from 'rxjs';
import { map, filter, take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class OpenDrawerGuard implements CanActivate {
  constructor(private store: Store<fromRoot.State>) {
  }

  canActivate(): Observable<boolean> {
    return this.store.pipe(
      select(fromRoot.getDrawerOpened),
      map((drawerOpened) => {
        if (!drawerOpened) {
          this.store.dispatch(new LayoutActions.OpenDrawer());
          return false;
        }

        return true;
      }),
      filter((canActivate) => canActivate),
      take(1)
    );
  }
}
