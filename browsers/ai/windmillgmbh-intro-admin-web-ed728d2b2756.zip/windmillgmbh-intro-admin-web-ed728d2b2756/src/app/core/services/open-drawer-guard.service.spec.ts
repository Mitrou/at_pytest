import { TestBed } from '@angular/core/testing';
import { StoreModule, Store } from '@ngrx/store';
import { cold } from 'jasmine-marbles';

import * as fromRoot from '../../reducers';
import * as LayoutActions from '../actions/layout.actions';

import { OpenDrawerGuard } from './open-drawer-guard.service';

describe('Auth Guard', () => {
  let guard: OpenDrawerGuard;
  let store: Store<any>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({
          ...fromRoot.reducers,
        }),
      ],
      providers: [OpenDrawerGuard],
    });

    store = TestBed.get(Store);
    spyOn(store, 'dispatch').and.callThrough();
    guard = TestBed.get(OpenDrawerGuard);
  });

  it('should complete with true if drawer is opened', () => {
    const action = new LayoutActions.OpenDrawer();
    store.dispatch(action);

    const expected = cold('(a|)', {a: true});

    expect(guard.canActivate()).toBeObservable(expected);
  });

  it('should dispatch LayoutActions.OpenDrawer action and complete with true if drawer is closed', () => {
    const action = new LayoutActions.CloseDrawer();
    store.dispatch(action);

    const expected = cold('(a|)', {a: true});

    expect(guard.canActivate()).toBeObservable(expected);

    expect(store.dispatch).toHaveBeenCalledWith(new LayoutActions.OpenDrawer());
  });
});
