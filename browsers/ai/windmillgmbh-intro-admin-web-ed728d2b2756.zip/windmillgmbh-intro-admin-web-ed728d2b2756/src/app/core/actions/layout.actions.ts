import { Action } from '@ngrx/store';

export enum LayoutActionTypes {
  OpenDrawer = '[Layout] Open Drawer',
  CloseDrawer = '[Layout] Close Drawer',
}

export class OpenDrawer implements Action {
  readonly type = LayoutActionTypes.OpenDrawer;
}

export class CloseDrawer implements Action {
  readonly type = LayoutActionTypes.CloseDrawer;
}

export type LayoutActionsUnion = OpenDrawer | CloseDrawer;
