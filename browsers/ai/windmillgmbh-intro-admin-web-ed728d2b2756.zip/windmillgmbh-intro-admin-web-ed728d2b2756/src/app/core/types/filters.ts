export type FilterKey = string | number;
export type FilterValue = string | number | string[] | number[];
export type Filters = Map<FilterKey, FilterValue>;

export interface FilterData {
  id: string | number;
  title: string | number;
}

export interface SerializedFilters {
  [key: string ]: FilterValue;
}
