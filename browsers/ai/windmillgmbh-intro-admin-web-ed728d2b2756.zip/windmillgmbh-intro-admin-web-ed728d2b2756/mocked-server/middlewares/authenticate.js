module.exports = function (req, res, next) {
  if (req.url === '/authenticate') {
    if (isAuthorized(req)) { // add your authorization logic here
      return next(); // continue to JSON Server router
    } else {
      return res.status(400).json({error: 'Invalid email or password'});
    }
  }

  next();
};

function isAuthorized(req) {
  return req.body.username === 'admin@intro.com' && req.body.password === 'admin';
}
