module.exports = function (req, res, next) {
  console.log(req.url);
  if (req.url === '/reset-password-finish') {
    if (isValidKey(req)) { // add your authorization logic here
      return next(); // continue to JSON Server router
    } else {
      return res.status(400).json({error: 'Invalid key'});
    }
  }

  next();
};

function isValidKey(req) {
  return req.body.key === 'key';
}
