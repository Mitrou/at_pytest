module.exports = function (req, res, next) {
  console.log(req.url);
  if (req.url === '/reset-password-init') {
    if (isValidEmail(req)) { // add your authorization logic here
      return next(); // continue to JSON Server router
    } else {
      return res.status(400).json({error: 'Invalid email'});
    }
  }

  next();
};

function isValidEmail(req) {
  return req.body.mail === 'admin@intro.com';
}
