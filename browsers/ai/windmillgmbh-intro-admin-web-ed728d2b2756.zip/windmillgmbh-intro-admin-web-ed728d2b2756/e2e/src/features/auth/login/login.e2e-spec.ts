import { browser } from 'protractor';
import { LoginPage } from './login.po';
import { loginPayload } from '../../../../../src/app/shared/mocks';

describe('Login Page', () => {
  let page: LoginPage;

  beforeEach(() => {
    page = new LoginPage();
  });

  it('should display main header', () => {
    page.navigateTo();
    expect(page.getMainHeaderText()).toEqual('Login');
  });

  it('should fail to login with incorrect credentials', async () => {
    page.login({username: 'wrong@email.com', password: 'test'});
    browser.waitForAngular();
    expect(page.getLoginError().getText()).toMatch('Invalid email or password');
  });

  it('should successfully login with correct credentials', async () => {
    page.login(loginPayload);
    browser.waitForAngular();
    expect(browser.driver.getCurrentUrl()).toBe('http://localhost:4200/#/dashboard');
  });
});
