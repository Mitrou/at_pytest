import { browser, by, element } from 'protractor';
import { LoginPayload } from '../../../../../src/app/features/auth/models/auth';

export class LoginPage {
  navigateTo() {
    return browser.get('/#/login');
  }

  getMainHeaderText() {
    return element(by.css('wml-login-page h4')).getText();
  }

  getEmailInput() {
    return element(by.id('email'));
  }

  getPasswordInput() {
    return element(by.id('password'));
  }

  getSubmitButton() {
    return element(by.id('submit'));
  }

  getLoginError() {
    return element(by.id('login-error'));
  }

  setEmail(email) {
    this.getEmailInput().clear().sendKeys(email);
  }

  setPassword(password) {
    this.getPasswordInput().clear().sendKeys(password);
  }

  submit() {
    return this.getSubmitButton().click();
  }

  login(loginPayload: LoginPayload) {
    this.setEmail(loginPayload.username);
    this.setPassword(loginPayload.password);

    return this.submit();
  }
}
