import { browser, by, element } from 'protractor';
import { ResetPasswordFinishPayload, ResetPasswordInitPayload } from '../../../../../src/app/features/auth/models/auth';

export class ResetPasswordPage {
  navigateTo() {
    return browser.get('/#/reset-password');
  }

  getMainHeaderText() {
    return element(by.css('wml-reset-password-page h4')).getText();
  }

  getSubmitInitForm() {
    return element(by.id('init-form'));
  }

  getSubmitFinishForm() {
    return element(by.id('finish-form'));
  }

  getEmailInput() {
    return element(by.id('email'));
  }

  getKeyInput() {
    return element(by.id('key'));
  }

  getNewPasswordInput() {
    return element(by.id('new-password'));
  }

  getSubmitInitFormButton() {
    return element(by.id('submit-init-form'));
  }

  getSubmitFinishFormButton() {
    return element(by.id('submit-finish-form'));
  }

  getResetPasswordInitError() {
    return element(by.id('reset-password-init-error'));
  }

  getResetPasswordFinishError() {
    return element(by.id('reset-password-finish-error'));
  }

  setEmail(email) {
    this.getEmailInput().clear().sendKeys(email);
  }

  setKey(key) {
    this.getKeyInput().clear().sendKeys(key);
  }

  setNewPassword(newPassword) {
    this.getNewPasswordInput().clear().sendKeys(newPassword);
  }

  submitInitForm() {
    return this.getSubmitInitFormButton().click();
  }

  submitFinishForm() {
    return this.getSubmitFinishFormButton().click();
  }

  resetPasswordInit(payload: ResetPasswordInitPayload) {
    this.setEmail(payload.mail);

    return this.submitInitForm();
  }

  resetPasswordFinish(payload: ResetPasswordFinishPayload) {
    this.setKey(payload.key);
    this.setNewPassword(payload.newPassword);

    return this.submitFinishForm();
  }
}
