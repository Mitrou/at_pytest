import { browser } from 'protractor';
import { ResetPasswordPage } from './reset-password.po';
import { resetPasswordInitPayload, resetPasswordFinishPayload } from '../../../../../src/app/shared/mocks';

describe('Reset Password Page', () => {
  let page: ResetPasswordPage;

  beforeEach(() => {
    page = new ResetPasswordPage();
  });

  it('should display main header', () => {
    page.navigateTo();
    expect(browser.driver.getCurrentUrl()).toBe('http://localhost:4200/#/reset-password');
    expect(page.getMainHeaderText()).toEqual('Reset Password');
  });

  it('should fail to init reset password with incorrect email', async () => {
    expect(page.getSubmitInitForm().isPresent()).toBeTruthy();
    page.resetPasswordInit({mail: 'wrong@email.com'});
    expect(page.getResetPasswordInitError().getText()).toMatch('Invalid email');
  });

  it('should successfully display reset password finish form', async () => {
    expect(page.getSubmitFinishForm().isPresent()).toBeFalsy();
    page.resetPasswordInit(resetPasswordInitPayload);
    browser.waitForAngular();
    expect(page.getSubmitFinishForm().isPresent()).toBeTruthy();
  });

  it('should fail to finish reset password with incorrect credentials', async () => {
    page.resetPasswordFinish({key: 'wrongKey', newPassword: 'newPassword'});
    expect(page.getResetPasswordFinishError().getText()).toMatch('Invalid key');
  });

  it('should successfully finish reset password form and redirect to login page', async () => {
    page.resetPasswordFinish(resetPasswordFinishPayload);
    browser.waitForAngular();
    expect(browser.driver.getCurrentUrl()).toBe('http://localhost:4200/#/login');
  });
});
